# -*- coding: utf-8 -*-
"""推理结果缓存、渲染、分类保存的核心模块。

本模块刻意和旧版视频检测 UI 解耦，只复用 AIDI / VisionFlow 的运行时能力。
核心数据流是：

    视频/图片 -> 按 FPS 抽帧 -> 内存中调用 VisionFlow 推理 -> SQLite 缓存

缓存 DB 不保存解析后的简化结果，而是保存每个激活输出节点的
`IProperty.to_binary()` 原始二进制属性。后续规则开发、重新渲染、分类保存
都从 DB 还原 VisionFlow 属性对象，因此不需要重复推理，也不丢 AIDI 输出信息。
"""

import hashlib
import json
import math
import os
import queue
import shutil
import sqlite3
import sys
import tempfile
import threading
import time
from collections import OrderedDict, deque
from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, as_completed, wait
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Dict, Iterable, List, Optional, Set, Tuple

try:
    from infer_cache.memory_pipeline import MemoryFrame, MemoryInferenceResult, MemoryOutputValue, MemoryRuleResult, output_spec_dict
except ImportError:
    from memory_pipeline import MemoryFrame, MemoryInferenceResult, MemoryOutputValue, MemoryRuleResult, output_spec_dict


try:
    from infer_cache.paths import ensure_runtime_paths
    ensure_runtime_paths()
except Exception:
    ROOT = Path(__file__).resolve().parent.parent
    if str(ROOT) not in sys.path:
        sys.path.insert(0, str(ROOT))


VIDEO_EXTS = {".mp4", ".avi", ".mov", ".mkv", ".m4v", ".mpg", ".mpeg", ".wmv"}
IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff"}
SCHEMA_VERSION = 2
LICENSE_ID = ""
LICENSE_ADDR = ""
RENDER_COLORS_BGR = [
    (255, 0, 255),
    (0, 200, 255),
    (0, 255, 0),
    (255, 128, 0),
    (255, 0, 0),
    (0, 128, 255),
    (180, 0, 255),
]

cv2 = None
np = None
vf = None
_helpers_loaded = False
_is_segmentation_tool = None
get_pred_regions = None
init_visionflow = None
open_graph = None
pick_tool_id = None
draw_text = None


def _require_runtime_deps() -> None:
    """按需导入 AIDI / VisionFlow 运行时依赖。

    这个模块里有些函数只做 DB 读取和路径处理，不一定需要 AIDI runtime。
    因此把 cv2、visionflow、旧版 helper 的导入延迟到真正需要推理、渲染、
    解析 AIDI 属性时再做，减少普通导入失败的概率。
    """
    global cv2, np, vf, _helpers_loaded
    global LICENSE_ADDR, LICENSE_ID
    global _is_segmentation_tool, get_pred_regions, init_visionflow
    global open_graph, pick_tool_id, draw_text

    if _helpers_loaded:
        return

    import cv2 as _cv2
    import numpy as _np
    import visionflow as _vf
    try:
        from infer_cache.video_detect_batch import (
            LICENSE_ADDR as _LICENSE_ADDR,
            LICENSE_ID as _LICENSE_ID,
            _is_segmentation_tool as _helper_is_segmentation_tool,
            get_pred_regions as _helper_get_pred_regions,
            init_visionflow as _helper_init_visionflow,
            open_graph as _helper_open_graph,
            pick_tool_id as _helper_pick_tool_id,
        )
        from infer_cache.unicode_draw import draw_text as _draw_text
    except ImportError:
        from video_detect_batch import (
            LICENSE_ADDR as _LICENSE_ADDR,
            LICENSE_ID as _LICENSE_ID,
            _is_segmentation_tool as _helper_is_segmentation_tool,
            get_pred_regions as _helper_get_pred_regions,
            init_visionflow as _helper_init_visionflow,
            open_graph as _helper_open_graph,
            pick_tool_id as _helper_pick_tool_id,
        )
        from unicode_draw import draw_text as _draw_text

    cv2 = _cv2
    np = _np
    vf = _vf
    LICENSE_ADDR = _LICENSE_ADDR
    LICENSE_ID = _LICENSE_ID
    _is_segmentation_tool = _helper_is_segmentation_tool
    get_pred_regions = _helper_get_pred_regions
    init_visionflow = _helper_init_visionflow
    open_graph = _helper_open_graph
    pick_tool_id = _helper_pick_tool_id
    draw_text = _draw_text
    _helpers_loaded = True


@dataclass
class OutputSpec:
    index: int
    tool_id: str
    node_id: str
    edge_type: str
    labels: List[str]
    column: str
    key_override: str = ""
    model_index: int = 0
    model_name: str = ""

    @property
    def key(self) -> str:
        if self.key_override:
            return self.key_override
        return f"{self.tool_id}/{self.node_id}"


@dataclass
class ModelRuntime:
    """单个模型的运行时上下文。

    多模型推理时，每帧会依次送入多个 runtime，所有模型输出合并写入同一帧
    的 `output_values` 表。
    """

    model_path: Path
    output_specs: List[OutputSpec]
    runtime: object
    input_tool_id: str


class PreparedInferenceContext:
    """Preloaded VisionFlow model outputs and runtime pool."""

    def __init__(
        self,
        *,
        model_paths: List[Path],
        output_specs: List[OutputSpec],
        runtime_pool: List[List[ModelRuntime]],
    ) -> None:
        self.model_paths = model_paths
        self.output_specs = output_specs
        self._runtime_pool = queue.Queue()
        for runtimes in runtime_pool:
            self._runtime_pool.put(runtimes)

    @property
    def runtime_count(self) -> int:
        return self._runtime_pool.qsize()

    def acquire_runtime(self) -> List[ModelRuntime]:
        return self._runtime_pool.get()

    def release_runtime(self, runtimes: List[ModelRuntime]) -> None:
        self._runtime_pool.put(runtimes)


@dataclass
class MediaSource:
    path: Path
    media_type: str
    output_name: str = ""


class BoundedVideoFrameProvider:
    """Read sampled source frames on demand with a small LRU cache."""

    def __init__(
        self,
        source_path: Path,
        *,
        prefix: str,
        target_fps: float,
        start_ms: float,
        end_ms: Optional[float],
        cache_size: int,
        log: Callable[[str], None],
    ) -> None:
        # [1.内存模型预加载整段视频全部帧][生产迭代02-有界流式]
        # 修改人: Shiver; 修改时间: 2026-06-22;
        # 修改逻辑: 规则、渲染和告警需要原图时从源视频顺序读取，LRU只保留固定帧数。
        self.source_path = Path(source_path)
        self.prefix = str(prefix)
        self.target_fps = float(target_fps)
        self.start_ms = float(start_ms)
        self.end_ms = end_ms
        self.cache_size = max(1, int(cache_size or 1))
        self.log = log
        self._lock = threading.Lock()
        self._cache: "OrderedDict[int, object]" = OrderedDict()
        self._iterator = None
        self._next_sample_index = 0
        self._reset_count = 0
        self._peak_cache_count = 0
        self._cache_hit_count = 0
        self._cache_miss_count = 0
        # [视频处理耗时复盘JSONL][NAS读取诊断01]
        # 修改人: Shiver; 修改时间: 2026-06-24;
        # 修改逻辑: provider 后续为规则渲染/协议图片取原图时也会重新读取 AVI，单独累计读取+解码耗时。
        self._io_stats = _new_video_io_stats(self.source_path, "provider_get_image")

    def _reset_reader(self) -> None:
        # [1.内存模型预加载整段视频全部帧][生产迭代02-有界流式]
        # 修改人: Shiver; 修改时间: 2026-06-22;
        # 修改逻辑: 向后读取导致重置时先关闭旧生成器，避免暂停的VideoCapture文件句柄累积。
        old_iterator = self._iterator
        old_closer = getattr(old_iterator, "close", None)
        if callable(old_closer):
            old_closer()
        iterator = _iter_video_frames(
            self.source_path,
            prefix=self.prefix,
            target_fps=self.target_fps,
            start_ms=self.start_ms,
            end_ms=self.end_ms,
            log=self.log,
            io_stats=self._io_stats,
        )
        self._iterator = iter(iterator)
        self._next_sample_index = 0
        self._reset_count += 1

    def _cache_image(self, sample_index: int, image) -> None:
        key = int(sample_index)
        self._cache[key] = image
        self._cache.move_to_end(key)
        while len(self._cache) > self.cache_size:
            self._cache.popitem(last=False)
        self._peak_cache_count = max(self._peak_cache_count, len(self._cache))

    def get_image(self, sample_index: int):
        target = int(sample_index)
        with self._lock:
            cached = self._cache.get(target)
            if cached is not None:
                self._cache_hit_count += 1
                self._cache.move_to_end(target)
                return cached
            self._cache_miss_count += 1
            if self._iterator is None or target < self._next_sample_index:
                self._reset_reader()
            assert self._iterator is not None
            for item in self._iterator:
                current = int(item.sample_index)
                self._next_sample_index = current + 1
                self._cache_image(current, item.image)
                if current == target:
                    return item.image
                if current > target:
                    break
        return None

    def stats(self) -> Dict[str, int]:
        with self._lock:
            return {
                "cache_limit": self.cache_size,
                "cache_current": len(self._cache),
                "cache_peak": self._peak_cache_count,
                "cache_hit_count": self._cache_hit_count,
                "cache_miss_count": self._cache_miss_count,
                "reader_resets": self._reset_count,
                "source_video_io": _finalize_video_io_stats(self._io_stats),
            }

    def close(self) -> None:
        # [1.内存模型预加载整段视频全部帧][生产迭代02-有界流式]
        # 修改人: Shiver; 修改时间: 2026-06-22;
        # 修改逻辑: 显式关闭暂停中的视频生成器，触发VideoCapture.release并清空LRU原图。
        with self._lock:
            iterator = self._iterator
            self._iterator = None
            self._cache.clear()
            closer = getattr(iterator, "close", None)
            if callable(closer):
                closer()


@dataclass
class FrameItem:
    image: object
    file_name: str
    sample_index: int
    source_frame: int
    timestamp_sec: float
    expected_count: int
    source_path: Optional[Path] = None


def collect_media_sources(input_path: Path) -> List[MediaSource]:
    if input_path.is_file():
        suffix = input_path.suffix.lower()
        if suffix in VIDEO_EXTS:
            return [MediaSource(input_path, "video")]
        if suffix in IMAGE_EXTS:
            return [MediaSource(input_path, "image")]
        return []
    if not input_path.is_dir():
        return []
    sources = []
    for path in sorted(p for p in input_path.rglob("*") if p.is_file()):
        suffix = path.suffix.lower()
        if suffix in VIDEO_EXTS:
            sources.append(MediaSource(path, "video"))
        elif suffix in IMAGE_EXTS:
            sources.append(MediaSource(path, "image"))
    return sources


def sanitize_name(text: str) -> str:
    cleaned = "".join("_" if ch in '\\/:*?"<>|' else ch for ch in str(text)).strip()
    return cleaned or "video"


def safe_column_name(index: int, tool_id: str, node_id: str) -> str:
    raw = f"{tool_id}_{node_id}"
    cleaned = "".join(ch if ch.isalnum() or ch == "_" else "_" for ch in raw)
    cleaned = cleaned.strip("_")[:60] or "output"
    digest = hashlib.sha1(f"{tool_id}/{node_id}".encode("utf-8")).hexdigest()[:8]
    return f"out_{index:02d}_{cleaned}_{digest}"


def model_alias(model_path: Path, index: int, used_aliases: Optional[Set[str]] = None) -> str:
    """生成多模型输出 key 使用的稳定模型别名。"""
    raw = sanitize_name(Path(model_path).stem)
    alias = raw[:40] or f"model_{index + 1}"
    if used_aliases is None:
        return alias
    base = alias
    suffix = 2
    while alias in used_aliases:
        alias = f"{base}_{suffix}"
        suffix += 1
    used_aliases.add(alias)
    return alias


def _label_classes(graph_obj, tool_id: str) -> List[str]:
    try:
        classes = graph_obj.get_param(vf.ToolNodeId(tool_id, "classes"))
        values = classes.get()
        return [str(value) for value in values if str(value).strip()]
    except Exception:
        return []


def inspect_model(model_path: Path, password: str = "") -> List[OutputSpec]:
    _require_runtime_deps()
    graph_obj = open_graph(str(model_path), password=password)
    specs: List[OutputSpec] = []
    for tool_id in graph_obj.tool_list():
        try:
            tool_type = str(graph_obj.tool_info(tool_id).type())
        except Exception:
            tool_type = ""
        if tool_type in {"Input", "ViewTransformer"}:
            continue
        try:
            edges = graph_obj.tool_info(tool_id).output_edges()
        except Exception:
            continue
        active_edges = []
        for edge in edges:
            try:
                if not edge.is_active():
                    continue
            except Exception:
                pass
            node_id = str(edge.id()).strip()
            edge_type = str(edge.type()).strip()
            if not node_id or not edge_type:
                continue
            if not edge_type.startswith("visionflow::props::"):
                continue
            if edge_type == "visionflow::props::ViewList":
                continue
            active_edges.append((node_id, edge_type))
        if not active_edges:
            continue
        labels = _label_classes(graph_obj, tool_id) if any("RegionList" in item[1] for item in active_edges) else []
        for node_id, edge_type in active_edges:
            idx = len(specs)
            specs.append(
                OutputSpec(
                    index=idx,
                    tool_id=str(tool_id),
                    node_id=node_id,
                    edge_type=edge_type,
                    labels=labels,
                    column=safe_column_name(idx, str(tool_id), node_id),
                )
            )
    return specs


def inspect_models(model_paths: List[Path], password: str = "") -> List[OutputSpec]:
    """读取一个或多个模型的输出节点，并合并成统一输出列表。

    单模型保持旧 key：`工具/输出`。
    多模型自动加前缀：`模型别名/工具/输出`，避免多个模型里同名输出互相覆盖。
    """
    paths = [Path(path) for path in model_paths if str(path).strip()]
    if not paths:
        raise RuntimeError("未选择模型。")
    if len(paths) == 1:
        return inspect_model(paths[0], password=password)

    specs: List[OutputSpec] = []
    used_aliases: Set[str] = set()
    for model_index, path in enumerate(paths):
        alias = model_alias(path, model_index, used_aliases)
        raw_specs = inspect_model(path, password=password)
        for raw in raw_specs:
            idx = len(specs)
            key = f"{alias}/{raw.tool_id}/{raw.node_id}"
            specs.append(
                OutputSpec(
                    index=idx,
                    tool_id=raw.tool_id,
                    node_id=raw.node_id,
                    edge_type=raw.edge_type,
                    labels=list(raw.labels),
                    column=safe_column_name(idx, alias, f"{raw.tool_id}_{raw.node_id}"),
                    key_override=key,
                    model_index=model_index,
                    model_name=alias,
                )
            )
    return specs


def _imwrite_unicode(path: Path, img) -> bool:
    _require_runtime_deps()
    ext = path.suffix or ".jpg"
    ok, buf = cv2.imencode(ext, img)
    if not ok:
        return False
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "wb") as f:
        f.write(buf.tobytes())
    return True


def _imread_unicode(path: Path):
    _require_runtime_deps()
    data = np.fromfile(str(path), dtype=np.uint8)
    if data.size == 0:
        return None
    return cv2.imdecode(data, cv2.IMREAD_COLOR)


def _safe_video_path(video_path: Path, log: Callable[[str], None]) -> Path:
    try:
        str(video_path).encode("ascii")
        return video_path
    except UnicodeEncodeError:
        pass
    temp_root = Path(tempfile.gettempdir()) / "infer_cache_ascii_video"
    temp_root.mkdir(parents=True, exist_ok=True)
    dst = temp_root / f"src_{abs(hash(str(video_path.resolve())))}{video_path.suffix.lower()}"
    try:
        if not dst.exists() or dst.stat().st_mtime < video_path.stat().st_mtime:
            shutil.copy2(video_path, dst)
            log(f"已创建 ASCII 临时视频副本：{dst}")
        return dst
    except Exception:
        return video_path


NETWORK_MOUNT_TYPES = {"cifs", "smb3", "smbfs", "nfs", "nfs4", "fuse.smbnetfs"}


def _mount_info_for_path(path: Path) -> Dict[str, object]:
    """Best-effort source storage info for NAS/CIFS diagnosis."""
    path_text = str(path)
    info: Dict[str, object] = {
        "source_is_probable_nas": path_text.startswith(("/opt/mnt/", "/mnt/nas/", "/mnt/")),
        "source_mount_type": "",
        "source_mount_point": "",
        "source_mount_source": "",
    }
    mounts_path = Path("/proc/mounts")
    if not mounts_path.exists():
        return info
    # [视频处理耗时复盘JSONL][NAS读取诊断01]
    # 修改人: Shiver; 修改时间: 2026-06-24;
    # 修改逻辑: mount 识别只做字符串归一化，不调用 Path.resolve()，避免诊断逻辑额外触发 NAS 文件系统访问。
    resolved = os.path.abspath(path_text)
    best: Tuple[int, str, str, str] = (-1, "", "", "")
    try:
        for line in mounts_path.read_text(encoding="utf-8", errors="replace").splitlines():
            parts = line.split()
            if len(parts) < 3:
                continue
            mount_source, mount_point, mount_type = parts[0], parts[1].replace("\\040", " "), parts[2]
            if resolved == mount_point or resolved.startswith(mount_point.rstrip("/") + "/"):
                score = len(mount_point)
                if score > best[0]:
                    best = (score, mount_source, mount_point, mount_type)
    except Exception:
        return info
    if best[0] >= 0:
        _score, mount_source, mount_point, mount_type = best
        info.update(
            {
                "source_mount_type": mount_type,
                "source_mount_point": mount_point,
                "source_mount_source": mount_source,
                "source_is_probable_nas": bool(
                    info["source_is_probable_nas"]
                    or mount_type.lower() in NETWORK_MOUNT_TYPES
                    or mount_source.startswith("//")
                    or ":" in mount_source
                ),
            }
        )
    return info


def _new_video_io_stats(source_path: Path, phase: str) -> Dict[str, object]:
    stats: Dict[str, object] = {
        "phase": str(phase),
        "source_path": str(source_path),
        "safe_video_path": "",
        "video_safe_path_ms": 0,
        "video_open_count": 0,
        "video_open_ms_sum": 0,
        "video_open_ms_max": 0,
        "video_metadata_ms_sum": 0,
        "video_seek_ms_sum": 0,
        "video_read_call_count": 0,
        "video_read_success_count": 0,
        "video_read_frame_count": 0,
        "video_yield_frame_count": 0,
        "video_read_decode_ms_sum": 0,
        "video_read_decode_ms_avg": 0,
        "video_read_decode_ms_max": 0,
        "video_first_frame_read_ms": 0,
        "_video_open_us_sum": 0,
        "_video_metadata_us_sum": 0,
        "_video_seek_us_sum": 0,
        "_video_read_decode_us_sum": 0,
        "_video_read_decode_us_max": 0,
    }
    stats.update(_mount_info_for_path(source_path))
    return stats


def _elapsed_us(started: float) -> int:
    return max(0, int((time.perf_counter() - started) * 1000000))


def _accumulate_us(stats: Optional[Dict[str, object]], private_sum_key: str, public_sum_ms_key: str, elapsed_us: int, *, public_max_ms_key: str = "") -> None:
    if stats is None:
        return
    total_us = int(stats.get(private_sum_key, 0) or 0) + int(elapsed_us or 0)
    stats[private_sum_key] = total_us
    stats[public_sum_ms_key] = round(total_us / 1000.0, 3)
    if public_max_ms_key:
        max_private_key = private_sum_key.replace("_sum", "_max")
        current_max = max(int(stats.get(max_private_key, 0) or 0), int(elapsed_us or 0))
        stats[max_private_key] = current_max
        stats[public_max_ms_key] = round(current_max / 1000.0, 3)


def _finalize_video_io_stats(stats: Optional[Dict[str, object]]) -> Dict[str, object]:
    if not isinstance(stats, dict):
        return {}
    call_count = int(stats.get("video_read_call_count", 0) or 0)
    if call_count > 0:
        stats["video_read_decode_ms_avg"] = round(float(stats.get("video_read_decode_ms_sum", 0) or 0) / call_count, 3)
    return {str(key): value for key, value in stats.items() if not str(key).startswith("_")}


def _video_io_trace_detail(stats: Optional[Dict[str, object]]) -> Dict[str, object]:
    clean = _finalize_video_io_stats(stats)
    if not clean:
        return {}
    return {
        "source_is_probable_nas": bool(clean.get("source_is_probable_nas")),
        "source_mount_type": str(clean.get("source_mount_type") or ""),
        "source_mount_point": str(clean.get("source_mount_point") or ""),
        "source_mount_source": str(clean.get("source_mount_source") or ""),
        "source_video_safe_path_ms": clean.get("video_safe_path_ms", 0),
        "source_video_open_count": clean.get("video_open_count", 0),
        "source_video_open_ms": clean.get("video_open_ms_sum", 0),
        "source_video_open_max_ms": clean.get("video_open_ms_max", 0),
        "source_video_metadata_ms": clean.get("video_metadata_ms_sum", 0),
        "source_video_seek_ms": clean.get("video_seek_ms_sum", 0),
        "source_video_read_call_count": clean.get("video_read_call_count", 0),
        "source_video_read_frame_count": clean.get("video_read_frame_count", 0),
        "source_video_yield_frame_count": clean.get("video_yield_frame_count", 0),
        "source_video_read_decode_ms": clean.get("video_read_decode_ms_sum", 0),
        "source_video_read_decode_avg_ms": clean.get("video_read_decode_ms_avg", 0),
        "source_video_read_decode_max_ms": clean.get("video_read_decode_ms_max", 0),
        "source_video_first_frame_read_ms": clean.get("video_first_frame_read_ms", 0),
    }


def _merge_video_io_stats(stats_list: List[Dict[str, object]], *, source_path: Path, phase: str) -> Dict[str, object]:
    """Merge multiple sequential video-read stats into one trace-compatible dict."""
    # [2#稀疏补推][生产迭代01]
    # 修改人: Shiver; 修改时间: 2026-06-25;
    # 修改逻辑: 稀疏扫描和命中补推会多次顺序读取同一个AVI，trace里必须合并统计，
    # 否则会低估2#阶段NAS/解码耗时。
    merged = _new_video_io_stats(source_path, phase)
    if not stats_list:
        return merged
    ms_sum_keys = (
        "video_safe_path_ms",
        "video_open_ms_sum",
        "video_metadata_ms_sum",
        "video_seek_ms_sum",
        "video_read_decode_ms_sum",
    )
    count_sum_keys = (
        "video_open_count",
        "video_read_call_count",
        "video_read_success_count",
        "video_read_frame_count",
        "video_yield_frame_count",
    )
    max_keys = ("video_open_ms_max", "video_read_decode_ms_max")
    merged["source_is_probable_nas"] = False
    for stats in stats_list:
        clean = _finalize_video_io_stats(stats)
        if not clean:
            continue
        for key in ms_sum_keys:
            merged[key] = round(float(merged.get(key, 0) or 0) + float(clean.get(key, 0) or 0), 3)
        for key in count_sum_keys:
            merged[key] = int(merged.get(key, 0) or 0) + int(clean.get(key, 0) or 0)
        for key in max_keys:
            merged[key] = max(float(merged.get(key, 0) or 0), float(clean.get(key, 0) or 0))
        if not str(merged.get("safe_video_path") or "") and str(clean.get("safe_video_path") or ""):
            merged["safe_video_path"] = str(clean.get("safe_video_path") or "")
        for key in ("source_mount_type", "source_mount_point", "source_mount_source"):
            if not str(merged.get(key) or "") and str(clean.get(key) or ""):
                merged[key] = str(clean.get(key) or "")
        merged["source_is_probable_nas"] = bool(merged.get("source_is_probable_nas")) or bool(clean.get("source_is_probable_nas"))
        if not float(merged.get("video_first_frame_read_ms", 0) or 0) and float(clean.get("video_first_frame_read_ms", 0) or 0):
            merged["video_first_frame_read_ms"] = clean.get("video_first_frame_read_ms", 0)
    call_count = float(merged.get("video_read_call_count", 0) or 0)
    if call_count > 0:
        merged["video_read_decode_ms_avg"] = round(float(merged.get("video_read_decode_ms_sum", 0) or 0) / call_count, 3)
    return merged


def _iter_video_frames(
    video_path: Path,
    *,
    prefix: str,
    target_fps: float,
    start_ms: float,
    end_ms: Optional[float],
    log: Callable[[str], None],
    io_stats: Optional[Dict[str, object]] = None,
) -> Iterable[FrameItem]:
    safe_started = time.perf_counter()
    safe_video_path = _safe_video_path(video_path, log)
    if io_stats is not None:
        io_stats["safe_video_path"] = str(safe_video_path)
        io_stats["video_safe_path_ms"] = round(_elapsed_us(safe_started) / 1000.0, 3)
    open_started = time.perf_counter()
    cap = cv2.VideoCapture(str(safe_video_path))
    open_us = _elapsed_us(open_started)
    if io_stats is not None:
        io_stats["video_open_count"] = int(io_stats.get("video_open_count", 0) or 0) + 1
        _accumulate_us(io_stats, "_video_open_us_sum", "video_open_ms_sum", open_us, public_max_ms_key="video_open_ms_max")
    if not cap.isOpened():
        raise RuntimeError(f"无法打开视频：{video_path}")
    try:
        metadata_started = time.perf_counter()
        src_fps, used_fps, start_frame, end_frame, expected = _sample_plan(cap, target_fps, start_ms, end_ms)
        _accumulate_us(io_stats, "_video_metadata_us_sum", "video_metadata_ms_sum", _elapsed_us(metadata_started))
        seek_started = time.perf_counter()
        cap.set(cv2.CAP_PROP_POS_FRAMES, start_frame)
        actual_start = int(cap.get(cv2.CAP_PROP_POS_FRAMES))
        _accumulate_us(io_stats, "_video_seek_us_sum", "video_seek_ms_sum", _elapsed_us(seek_started))
        if actual_start != start_frame:
            log(f"提示：实际定位到第 {actual_start} 帧（请求 {start_frame} 帧）")
            start_frame = actual_start

        step = src_fps / used_fps
        next_frame = float(start_frame)
        frame_idx = start_frame
        sample_index = 0
        while frame_idx < end_frame:
            read_started = time.perf_counter()
            ok, frame = cap.read()
            read_us = _elapsed_us(read_started)
            if io_stats is not None:
                io_stats["video_read_call_count"] = int(io_stats.get("video_read_call_count", 0) or 0) + 1
                _accumulate_us(io_stats, "_video_read_decode_us_sum", "video_read_decode_ms_sum", read_us, public_max_ms_key="video_read_decode_ms_max")
                if ok:
                    io_stats["video_read_success_count"] = int(io_stats.get("video_read_success_count", 0) or 0) + 1
                    io_stats["video_read_frame_count"] = int(io_stats.get("video_read_frame_count", 0) or 0) + 1
                    if not io_stats.get("video_first_frame_read_ms"):
                        io_stats["video_first_frame_read_ms"] = round(read_us / 1000.0, 3)
            if not ok:
                break
            if frame_idx + 1e-6 >= next_frame:
                if io_stats is not None:
                    io_stats["video_yield_frame_count"] = int(io_stats.get("video_yield_frame_count", 0) or 0) + 1
                yield FrameItem(
                    image=frame,
                    file_name=f"{prefix}_{sample_index:06d}.jpg",
                    sample_index=sample_index,
                    source_frame=frame_idx,
                    timestamp_sec=frame_idx / src_fps,
                    expected_count=expected,
                )
                sample_index += 1
                next_frame += step
            frame_idx += 1
    finally:
        cap.release()


def _iter_image_frames(image_path: Path, *, prefix: str) -> Iterable[FrameItem]:
    img = _imread_unicode(image_path)
    if img is None:
        raise RuntimeError(f"读取图片失败：{image_path}")
    yield FrameItem(
        image=img,
        file_name=f"{prefix}_000000.jpg",
        sample_index=0,
        source_frame=0,
        timestamp_sec=0.0,
        expected_count=1,
    )


def _safe_image_path(image_path: Path) -> Path:
    try:
        str(image_path).encode("ascii")
        return image_path
    except UnicodeEncodeError:
        pass
    temp_root = Path(tempfile.gettempdir()) / "infer_cache_ascii_image"
    temp_root.mkdir(parents=True, exist_ok=True)
    dst = temp_root / f"img_{abs(hash(str(image_path.resolve())))}{image_path.suffix.lower()}"
    try:
        if not dst.exists() or dst.stat().st_mtime < image_path.stat().st_mtime:
            shutil.copy2(image_path, dst)
        return dst
    except Exception:
        return image_path


def _vf_image_from_file(image_path: Path):
    _require_runtime_deps()
    data = np.fromfile(str(image_path), dtype=np.uint8)
    if data.size == 0:
        raise RuntimeError(f"读取图片失败：{image_path}")
    img = cv2.imdecode(data, cv2.IMREAD_COLOR)
    if img is None:
        raise RuntimeError(f"读取图片失败：{image_path}")
    return _vf_image_from_bgr_numpy(img)


def _vf_image_from_files(image_paths: List[Path]):
    _require_runtime_deps()
    safe_paths = [_safe_image_path(Path(path)) for path in image_paths]
    # [1.内存模型预加载整段视频全部帧][通篇审查-RGB一致性]
    # 修改人: Shiver; 修改时间: 2026-06-23;
    # 修改逻辑: 磁盘模式多图入口原先直接FromFiles，颜色语义无法与内存模式核对；
    # 统一按OpenCV BGR读取并经同一RGB边界构造Batch，确保两种存储模式输入一致。
    vf_images: List[object] = []
    for image_path in safe_paths:
        data = np.fromfile(str(image_path), dtype=np.uint8)
        image = cv2.imdecode(data, cv2.IMREAD_COLOR) if data.size > 0 else None
        if image is None:
            raise RuntimeError(f"读取多图模型输入失败：{image_path}")
        vf_images.append(_vf_image_from_bgr_numpy(image))
    return vf.img.Image.FromBatch(vf_images)


def _frame_png_path(frames_dir: Path, frame_item: FrameItem) -> Path:
    return frames_dir / frame_item.file_name


def _save_frame_png(frame_item: FrameItem, frames_dir: Path) -> str:
    out_img = _frame_png_path(frames_dir, frame_item)
    out_img.parent.mkdir(parents=True, exist_ok=True)
    if frame_item.source_path is not None:
        src = Path(frame_item.source_path)
        if src.resolve() != out_img.resolve():
            shutil.copy2(src, out_img)
    elif not _imwrite_unicode(out_img, frame_item.image):
        raise RuntimeError(f"保存推理帧 PNG 失败：{out_img}")
    return str(out_img)


def _cached_frame_ready(frame_item: FrameItem, frames_dir: Path) -> bool:
    path = _frame_png_path(frames_dir, frame_item)
    return path.exists() and path.is_file() and path.stat().st_size > 0


def _plan_video_frames(
    video_path: Path,
    *,
    prefix: str,
    target_fps: float,
    start_ms: float,
    end_ms: Optional[float],
    log: Callable[[str], None],
) -> List[FrameItem]:
    _require_runtime_deps()
    safe_video_path = _safe_video_path(video_path, log)
    cap = cv2.VideoCapture(str(safe_video_path))
    if not cap.isOpened():
        raise RuntimeError(f"无法打开视频：{video_path}")
    try:
        src_fps, used_fps, start_frame, end_frame, expected = _sample_plan(cap, target_fps, start_ms, end_ms)
        cap.set(cv2.CAP_PROP_POS_FRAMES, start_frame)
        actual_start = int(cap.get(cv2.CAP_PROP_POS_FRAMES))
        if actual_start != start_frame:
            start_frame = actual_start
        step = src_fps / used_fps
        next_frame = float(start_frame)
        frame_idx = start_frame
        sample_index = 0
        frames: List[FrameItem] = []
        while frame_idx < end_frame:
            if frame_idx + 1e-6 >= next_frame:
                frames.append(
                    FrameItem(
                        image=None,
                        file_name=f"{prefix}_{sample_index:06d}.png",
                        sample_index=sample_index,
                        source_frame=frame_idx,
                        timestamp_sec=frame_idx / src_fps,
                        expected_count=expected,
                    )
                )
                sample_index += 1
                next_frame += step
            frame_idx += 1
        return frames
    finally:
        cap.release()


def _ensure_frame_cache(
    source: MediaSource,
    *,
    prefix: str,
    frames_dir: Path,
    target_fps: float,
    start_ms: float,
    end_ms: Optional[float],
    log: Callable[[str], None],
    progress: Optional[Callable[[int, int, str], None]] = None,
    should_stop: Optional[Callable[[], bool]] = None,
) -> List[FrameItem]:
    """Ensure sampled PNG frames exist, then return frame metadata in order."""
    _require_runtime_deps()
    if source.media_type == "video":
        planned_frames = _plan_video_frames(
            source.path,
            prefix=prefix,
            target_fps=target_fps,
            start_ms=start_ms,
            end_ms=end_ms,
            log=log,
        )
        if planned_frames and all(_cached_frame_ready(frame_item, frames_dir) for frame_item in planned_frames):
            log(f"PNG 帧缓存完整，跳过视频拆帧：总帧数={len(planned_frames)}，目录={frames_dir}")
            return [
                FrameItem(
                    image=None,
                    file_name=frame_item.file_name,
                    sample_index=frame_item.sample_index,
                    source_frame=frame_item.source_frame,
                    timestamp_sec=frame_item.timestamp_sec,
                    expected_count=frame_item.expected_count,
                    source_path=_frame_png_path(frames_dir, frame_item),
                )
                for frame_item in planned_frames
            ]
        frame_iter = _iter_video_frames(
            source.path,
            prefix=prefix,
            target_fps=target_fps,
            start_ms=start_ms,
            end_ms=end_ms,
            log=log,
        )
    else:
        frame_iter = _iter_image_frames(source.path, prefix=prefix)

    frames: List[FrameItem] = []
    reused = 0
    written = 0
    for frame_item in frame_iter:
        if should_stop and should_stop():
            log("收到中止请求，停止准备 PNG 帧缓存。")
            break
        cached_path = _frame_png_path(frames_dir, frame_item)
        if _cached_frame_ready(frame_item, frames_dir):
            reused += 1
        else:
            # TODO 这里不能取消存图 会导致后续推理有问题
            _save_frame_png(frame_item, frames_dir)
            written += 1
        frames.append(
            FrameItem(
                image=None,
                file_name=frame_item.file_name,
                sample_index=frame_item.sample_index,
                source_frame=frame_item.source_frame,
                timestamp_sec=frame_item.timestamp_sec,
                expected_count=frame_item.expected_count,
                source_path=cached_path,
            )
        )
        # if progress:
        #     progress(len(frames), frame_item.expected_count, "准备 PNG 帧")
    if not frames:
        raise RuntimeError(f"没有生成可推理的 PNG 帧：{source.path}")
    log(f"PNG 帧缓存完成：总帧数={len(frames)}，复用={reused}，新写入={written}，目录={frames_dir}")
    return frames


def _open_runtime(model_path: Path, output_specs: List[OutputSpec], device_ids: List[int], allow_cpu: bool, password: str):
    _require_runtime_deps()
    init_visionflow(license_id=LICENSE_ID, license_server=LICENSE_ADDR)
    try:
        graph_obj = open_graph(str(model_path), password=password)
    except Exception:
        if not model_path.is_dir():
            raise
        copy_root = model_path.parent / f"{model_path.name}_infer_cache_copy"
        dst = copy_root / f"cache_{time.strftime('%Y%m%d_%H%M%S')}.vflow"
        copy_root.mkdir(parents=True, exist_ok=True)

        def _ignore_lock_files(_, names):
            return {name for name in names if name.upper() in {"LOCK", "~$.VFPRO.LOCK"}}

        shutil.copytree(model_path, dst, ignore=_ignore_lock_files)
        graph_obj = open_graph(str(dst), password=password)
    input_tool_id = pick_tool_id(
        graph_obj,
        preferred=["Input", "输入"],
        fallback_substr=["Input", "输入"],
    )
    if str(model_path).lower().endswith(".vflow"):
        for spec in output_specs:
            try:
                graph_obj.activate_tool_output(vf.ToolNodeId(spec.tool_id, spec.node_id))
            except Exception:
                pass

    strategy = vf.runtime.AllTools()
    if device_ids:
        strategy.options.specified_gpu_ids = device_ids
        strategy.options.allow_max_gpu_num = max(1, len(device_ids))
    if allow_cpu:
        strategy.options.allow_run_on_cpu = True
    runtime = graph_obj.create_runtime(strategy)
    return graph_obj, runtime, input_tool_id


def _open_model_runtimes(
    model_paths: List[Path],
    all_output_specs: List[OutputSpec],
    device_ids: List[int],
    allow_cpu: bool,
    password: str,
) -> List[ModelRuntime]:
    """为每个模型创建独立 runtime。

    AIDI 的一个 runtime 对应一个 graph/model。多模型推理时不能把多个模型塞进
    一个 runtime，因此这里维护多个 runtime，并在每帧上依次执行。
    """
    runtimes: List[ModelRuntime] = []
    for model_index, model_path in enumerate(model_paths):
        specs = [spec for spec in all_output_specs if spec.model_index == model_index]
        if len(model_paths) == 1:
            specs = all_output_specs
        if not specs:
            continue
        _graph_obj, runtime, input_tool_id = _open_runtime(
            model_path,
            specs,
            device_ids=device_ids,
            allow_cpu=allow_cpu,
            password=password,
        )
        runtimes.append(
            ModelRuntime(
                model_path=model_path,
                output_specs=specs,
                runtime=runtime,
                input_tool_id=input_tool_id,
            )
        )
    return runtimes


def prepare_inference_context(
    model_paths: List[Path],
    *,
    device_ids: List[int],
    allow_cpu: bool,
    password: str = "",
    runtime_workers: int = 1,
    log: Callable[[str], None] = print,
) -> PreparedInferenceContext:
    """Inspect models and preload a fixed pool of VisionFlow runtimes."""
    _require_runtime_deps()
    selected_model_paths = [Path(path) for path in model_paths if str(path).strip()]
    if not selected_model_paths:
        raise RuntimeError("未选择模型。")
    output_specs = inspect_models(selected_model_paths, password=password)
    if not output_specs:
        raise RuntimeError("模型中没有找到可缓存的输出节点")
    runtime_count = max(1, int(runtime_workers or 1))
    runtime_pool: List[List[ModelRuntime]] = []
    log(f"开始预加载 VisionFlow runtime：{runtime_count} 组，模型数：{len(selected_model_paths)}")
    for idx in range(runtime_count):
        runtimes = _open_model_runtimes(
            selected_model_paths,
            output_specs,
            device_ids=device_ids,
            allow_cpu=allow_cpu,
            password=password,
        )
        if not runtimes:
            raise RuntimeError("模型运行时初始化失败：没有可执行模型。")
        runtime_pool.append(runtimes)
        log(f"已预加载 runtime {idx + 1}/{runtime_count}")
    return PreparedInferenceContext(
        model_paths=selected_model_paths,
        output_specs=output_specs,
        runtime_pool=runtime_pool,
    )


def _execute_runtime_outputs(runtime_info: ModelRuntime, vf_img) -> List[Dict[str, object]]:
    """Run one model runtime on the provided VisionFlow image payload."""
    _require_runtime_deps()
    sample = runtime_info.runtime.create_sample()
    vf.helper.add_image_to_sample(sample, vf_img, runtime_info.input_tool_id)
    runtime_info.runtime.execute(sample)
    return _infer_frame_outputs(sample, runtime_info.output_specs)


def _vf_image_from_bgr_numpy(frame_image):
    """Convert an OpenCV BGR frame to the RGB layout required by VisionFlow."""
    _require_runtime_deps()
    if frame_image is None:
        raise RuntimeError("VisionFlow 推理输入图像为空。")
    # [1.内存模型预加载整段视频全部帧][生产迭代01-RGB]
    # 修改人: Shiver; 修改时间: 2026-06-22;
    # 修改逻辑: OpenCV VideoCapture/imdecode 输出 BGR；统一在 VisionFlow 边界转换为
    # 连续 RGB NumPy，避免模型将红蓝通道颠倒。OpenCV渲染仍保留BGR，不改变下游画图。
    rgb_image = cv2.cvtColor(frame_image, cv2.COLOR_BGR2RGB)
    return vf.img.Image.from_numpy(rgb_image)


def _execute_frame_outputs(frame_image, model_runtimes: List[ModelRuntime]) -> List[Dict[str, object]]:
    """Run all configured model runtimes on one in-memory frame.

    The caller must ensure each runtime is used by only one thread at a time.
    In the serial path this is naturally true. In the parallel path every worker
    thread lazily creates its own runtime list, so no runtime object is shared
    across threads.
    """
    _require_runtime_deps()
    vf_img = _vf_image_from_bgr_numpy(frame_image)
    outputs: List[Dict[str, object]] = []
    for runtime_info in model_runtimes:
        outputs.extend(_execute_runtime_outputs(runtime_info, vf_img))
    return outputs


def _multi_image_window_paths(frame_paths: List[Path], center_index: int, *, before: int = 2, after: int = 2) -> List[Path]:
    """Return a shifted fixed-size window around one center frame."""
    if not frame_paths:
        return []
    size = max(1, int(before) + 1 + int(after))
    n = len(frame_paths)
    if n >= size:
        start = int(center_index) - int(before)
        start = min(max(0, start), n - size)
        return list(frame_paths[start : start + size])

    out = list(frame_paths)
    while len(out) < size:
        out.append(frame_paths[-1])
    return out[:size]


def _multi_image_window_items(items: List[object], center_index: int, *, before: int = 2, after: int = 2) -> List[object]:
    """Return a shifted fixed-size in-memory window around one center item."""
    if not items:
        return []
    size = max(1, int(before) + 1 + int(after))
    n = len(items)
    if n >= size:
        start = int(center_index) - int(before)
        start = min(max(0, start), n - size)
        return list(items[start : start + size])
    out = list(items)
    while len(out) < size:
        out.append(items[-1])
    return out[:size]


def _execute_single_image_model_outputs_from_array(frame_image, runtime_info: ModelRuntime) -> List[Dict[str, object]]:
    """Run #1 single-image model on one in-memory frame."""
    _require_runtime_deps()
    return _execute_runtime_outputs(runtime_info, _vf_image_from_bgr_numpy(frame_image))


def _execute_multi_image_model_outputs_from_arrays(
    frame_images: List[object],
    center_index: int,
    runtime_info: ModelRuntime,
    *,
    before: int = 2,
    after: int = 2,
) -> List[Dict[str, object]]:
    """Run #2 multi-image model on a fixed in-memory image window."""
    _require_runtime_deps()
    window_images = _multi_image_window_items(frame_images, center_index, before=before, after=after)
    expected = max(1, int(before) + 1 + int(after))
    if len(window_images) != expected:
        raise RuntimeError(f"2#多图推理模型窗口数量异常：{len(window_images)}，期望 {expected}。")
    # [1.内存模型预加载整段视频全部帧][生产迭代01-RGB]
    # 修改人: Shiver; 修改时间: 2026-06-22;
    # 修改逻辑: 多图模型的每个 OpenCV BGR窗口帧使用同一RGB适配入口。
    vf_images = [_vf_image_from_bgr_numpy(image) for image in window_images]
    return _execute_runtime_outputs(runtime_info, vf.img.Image.FromBatch(vf_images))


def _execute_single_image_model_outputs(frame_path: Path, runtime_info: ModelRuntime) -> List[Dict[str, object]]:
    """Run #1 single-image model on one PNG frame."""
    return _execute_runtime_outputs(runtime_info, _vf_image_from_file(frame_path))


def _execute_multi_image_model_outputs(
    frame_paths: List[Path],
    center_index: int,
    runtime_info: ModelRuntime,
    *,
    before: int = 2,
    after: int = 2,
) -> List[Dict[str, object]]:
    """Run #2 multi-image model on a fixed window around one frame."""
    window_paths = _multi_image_window_paths(frame_paths, center_index, before=before, after=after)
    expected = max(1, int(before) + 1 + int(after))
    if len(window_paths) != expected:
        raise RuntimeError(f"2#多图推理模型窗口数量异常：{len(window_paths)}，期望 {expected}。")
    return _execute_runtime_outputs(runtime_info, _vf_image_from_files(window_paths))


def _save_multi_image_window_files(
    *,
    frame_paths: List[Path],
    center_index: int,
    frame_items: List[FrameItem],
    run_root: Path,
    video_name: str,
    before: int = 2,
    after: int = 2,
    model_entry_index: int = 1,
) -> List[Path]:
    """Copy #2 multi-image input window files for inspection/debugging."""
    window_paths = _multi_image_window_paths(frame_paths, center_index, before=before, after=after)
    expected = max(1, int(before) + 1 + int(after))
    if len(window_paths) != expected:
        raise RuntimeError(f"2#多图窗口保存数量异常：{len(window_paths)}，期望 {expected}。")
    center_item = frame_items[center_index]
    source_frame_text = str(center_item.source_frame if center_item.source_frame is not None else center_item.sample_index)
    out_dir = run_root / "windows" / source_frame_text / f"model_{int(model_entry_index) + 1}"
    out_dir.mkdir(parents=True, exist_ok=True)
    base = f"{sanitize_name(video_name)}_{source_frame_text}"
    saved: List[Path] = []
    for idx, src in enumerate(window_paths, start=1):
        ext = src.suffix or ".png"
        dst = out_dir / f"{base}-{idx}{ext}"
        if src.resolve() != dst.resolve():
            shutil.copy2(src, dst)
        saved.append(dst)
    return saved


def _sample_plan(cap, target_fps: float, start_ms: float, end_ms: Optional[float]):
    src_fps = cap.get(cv2.CAP_PROP_FPS) or 0.0
    if src_fps <= 0:
        raise RuntimeError("无法读取视频源 FPS")
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
    if target_fps <= 0 or target_fps > src_fps:
        target_fps = src_fps
    start_frame = int(round(max(0.0, start_ms) / 1000.0 * src_fps))
    if end_ms is None or end_ms <= 0:
        end_frame = total_frames if total_frames > 0 else 10 ** 12
    else:
        end_frame = int(round(end_ms / 1000.0 * src_fps))
    if total_frames > 0:
        end_frame = min(end_frame, total_frames)
    if start_frame >= end_frame:
        raise RuntimeError(f"起始帧({start_frame}) >= 结束帧({end_frame})，请检查时间段设置。")
    step = src_fps / target_fps
    expected = max(1, int(math.ceil((end_frame - start_frame) / step)))
    return src_fps, target_fps, start_frame, end_frame, expected


def _source_processing_info(
    source: MediaSource,
    *,
    requested_target_fps: float,
    start_ms: float,
    end_ms: Optional[float],
    log: Callable[[str], None],
) -> Dict[str, object]:
    _require_runtime_deps()
    info: Dict[str, object] = {
        "source_path": str(source.path),
        "source_name": source.path.name,
        "media_type": source.media_type,
        "requested_target_fps": requested_target_fps,
        "start_ms": start_ms,
        "end_ms": end_ms,
        "actual_sample_fps": 1.0,
        "src_fps": 0.0,
        "start_frame": 0,
        "end_frame": 1,
        "expected_frames": 1,
        "image_width": 0,
        "image_height": 0,
    }
    if source.media_type != "video":
        img = _imread_unicode(source.path)
        if img is not None:
            h, w = img.shape[:2]
            info["image_width"] = int(w)
            info["image_height"] = int(h)
        return info

    # [视频处理耗时复盘JSONL][NAS读取诊断01]
    # 修改人: Shiver; 修改时间: 2026-06-24;
    # 修改逻辑: video_prepare 单独记录 VideoCapture 打开和基础 metadata 读取耗时，用于排查 NAS/CIFS 视频打开慢。
    prepare_io_stats = _new_video_io_stats(source.path, "video_prepare")
    safe_started = time.perf_counter()
    safe_video_path = _safe_video_path(source.path, log)
    prepare_io_stats["safe_video_path"] = str(safe_video_path)
    prepare_io_stats["video_safe_path_ms"] = round(_elapsed_us(safe_started) / 1000.0, 3)
    open_started = time.perf_counter()
    cap = cv2.VideoCapture(str(safe_video_path))
    open_us = _elapsed_us(open_started)
    prepare_io_stats["video_open_count"] = 1
    _accumulate_us(prepare_io_stats, "_video_open_us_sum", "video_open_ms_sum", open_us, public_max_ms_key="video_open_ms_max")
    if not cap.isOpened():
        raise RuntimeError(f"无法打开视频：{source.path}")
    try:
        metadata_started = time.perf_counter()
        src_fps, used_fps, start_frame, end_frame, expected = _sample_plan(cap, requested_target_fps, start_ms, end_ms)
        image_width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH) or 0)
        image_height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT) or 0)
        _accumulate_us(prepare_io_stats, "_video_metadata_us_sum", "video_metadata_ms_sum", _elapsed_us(metadata_started))
        info.update(
            {
                "actual_sample_fps": used_fps,
                "src_fps": src_fps,
                "start_frame": start_frame,
                "end_frame": end_frame,
                "expected_frames": expected,
                "image_width": image_width,
                "image_height": image_height,
                "source_video_io": _finalize_video_io_stats(prepare_io_stats),
            }
        )
    finally:
        cap.release()
    return info


def _write_processing_info(run_root: Path, info: Dict[str, object]) -> None:
    path = run_root / "processing_info.json"
    path.write_text(json.dumps(info, ensure_ascii=False, indent=2), encoding="utf-8")


def _remove_existing_path(path: Path, *, log: Callable[[str], None], label: str) -> None:
    try:
        resolved = path.resolve()
    except Exception:
        resolved = path
    if len(resolved.parts) < 3:
        raise RuntimeError(f"拒绝清理危险路径：{resolved}")
    if not path.exists():
        return
    try:
        if path.is_dir():
            shutil.rmtree(path, onexc=_retry_remove_readonly)
        else:
            path.unlink()
    except PermissionError as exc:
        raise RuntimeError(f"清理{label}失败，文件可能正在被图片查看器或播放器占用：{path}") from exc
    log(f"已清空{label}：{path}")


def _retry_remove_readonly(func, path, exc_info) -> None:
    try:
        os.chmod(path, 0o700)
        func(path)
    except Exception:
        raise


def _clear_inference_output(run_root: Path, *, log: Callable[[str], None]) -> None:
    _remove_existing_path(run_root, log=log, label="旧推理输出")


def is_inference_cache_db(db_path: Path) -> bool:
    return Path(db_path).name.endswith("_infer_cache.sqlite")


def is_rule_cache_db(db_path: Path) -> bool:
    return Path(db_path).name.endswith("_infer_cache_rules.sqlite")


def _is_rule_db_path(db_path: Path) -> bool:
    return is_rule_cache_db(db_path)


def _default_render_dir(db_path: Path) -> Path:
    return db_path.parent / ("rendered_rules" if _is_rule_db_path(db_path) else "rendered")


def _render_video_path(db_path: Path) -> Path:
    if _is_rule_db_path(db_path):
        return db_path.parent / "rendered_rule_videos" / f"{db_path.stem}_rules_rendered.mp4"
    return db_path.parent / "rendered_videos" / f"{db_path.stem}_rendered.mp4"


def _safe_label_dir_name(label: str) -> str:
    text = str(label).strip() or "未命名"
    for ch in '<>:"/\\|?*':
        text = text.replace(ch, "_")
    return text[:80] or "未命名"


def _clear_render_outputs(
    db_path: Path,
    out_dir: Path,
    *,
    clear_video: bool,
    log: Callable[[str], None],
) -> None:
    _remove_existing_path(out_dir, log=log, label="旧渲染图片")
    if clear_video:
        video_path = _render_video_path(db_path)
        _remove_existing_path(video_path, log=log, label="旧渲染视频")


def _property_to_binary_b64(prop) -> str:
    if prop is None:
        return ""
    return prop.to_binary().to_base64()


def _property_class_from_type(edge_type: str):
    _require_runtime_deps()
    type_name = str(edge_type).split("::")[-1].strip()
    if type_name.endswith(">"):
        type_name = type_name.rsplit("<", 1)[-1].rstrip(">")
    cls = getattr(vf.props, type_name, None)
    if cls is not None and hasattr(cls, "from_binary"):
        return cls
    for fallback in (
        "MultiNamesPolygonRegionList",
        "PolygonWithStringMapRegionList",
        "PolygonRegionList",
        "RotateRectRegionList",
        "IDReaderRegionList",
        "GaugeRegionList",
        "RegionMatchResultList",
        "ViewList",
    ):
        if fallback in str(edge_type):
            cls = getattr(vf.props, fallback, None)
            if cls is not None and hasattr(cls, "from_binary"):
                return cls
    return None


def decode_property(edge_type: str, binary_b64: str):
    """把 DB 中保存的 Base64 二进制属性还原为 VisionFlow property 对象。"""
    _require_runtime_deps()
    if not binary_b64:
        return None
    cls = _property_class_from_type(edge_type)
    if cls is None:
        raise RuntimeError(f"暂不支持还原该输出类型：{edge_type}")
    buf = vf.Buffer.FromBase64(binary_b64)
    return cls().from_binary(buf)


def _infer_frame_outputs(sample, output_specs: List[OutputSpec]) -> List[Dict[str, object]]:
    _require_runtime_deps()
    outputs: List[Dict[str, object]] = []
    for spec in output_specs:
        record = {
            "index": spec.index,
            "tool_id": spec.tool_id,
            "node_id": spec.node_id,
            "key": spec.key,
            "column": spec.column,
            "edge_type": spec.edge_type,
            "property_type": spec.edge_type,
            "binary_b64": "",
            "error": "",
        }
        try:
            prop = sample.get(vf.ToolNodeId(spec.tool_id, spec.node_id))
            record["binary_b64"] = _property_to_binary_b64(prop)
            try:
                record["property_type"] = str(sample.property_type(vf.ToolNodeId(spec.tool_id, spec.node_id)))
            except Exception:
                pass
        except Exception as exc:
            record["error"] = str(exc)
        outputs.append(record)
    return outputs


def _connect_cache(db_path: Path) -> sqlite3.Connection:
    db_path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(db_path))
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    return conn


def _init_cache_db(
    conn: sqlite3.Connection,
    *,
    model_path: Path,
    model_paths: Optional[List[Path]] = None,
    input_path: Path,
    output_specs: List[OutputSpec],
    target_fps: float,
    start_ms: float,
    end_ms: Optional[float],
    save_frames: bool,
    processing_info: Optional[Dict[str, object]] = None,
    model_orchestration_info: Optional[Dict[str, object]] = None,
) -> None:
    conn.executescript(
        """
        DROP TABLE IF EXISTS metadata;
        DROP TABLE IF EXISTS outputs;
        DROP TABLE IF EXISTS frames;
        DROP TABLE IF EXISTS output_values;

        CREATE TABLE metadata (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL
        );
        CREATE TABLE outputs (
            output_index INTEGER PRIMARY KEY,
            tool_id TEXT NOT NULL,
            node_id TEXT NOT NULL,
            output_key TEXT NOT NULL,
            column_name TEXT NOT NULL,
            edge_type TEXT NOT NULL,
            labels_json TEXT NOT NULL
        );
        CREATE TABLE frames (
            frame_id INTEGER PRIMARY KEY,
            frame_key TEXT NOT NULL UNIQUE,
            file_name TEXT NOT NULL,
            sample_index INTEGER NOT NULL,
            source_frame INTEGER NOT NULL,
            timestamp_sec REAL NOT NULL,
            image_path TEXT NOT NULL
        );
        CREATE TABLE output_values (
            frame_id INTEGER NOT NULL,
            output_index INTEGER NOT NULL,
            output_key TEXT NOT NULL,
            property_type TEXT NOT NULL,
            binary_b64 TEXT NOT NULL,
            error TEXT NOT NULL,
            PRIMARY KEY (frame_id, output_index)
        );
        CREATE INDEX idx_output_values_output ON output_values(output_index);
        """
    )
    meta = {
        "schema_version": SCHEMA_VERSION,
        "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "model_path": str(model_path),
        "model_paths": [str(path) for path in (model_paths or [model_path])],
        "input_path": str(input_path),
        "target_fps": target_fps,
        "start_ms": start_ms,
        "end_ms": end_ms,
        "save_frames": save_frames,
        "processing_info": processing_info or {},
        "model_orchestration": model_orchestration_info or {},
        "storage": "sqlite+aidi_property_binary_base64",
    }
    conn.executemany(
        "INSERT INTO metadata(key, value) VALUES(?, ?)",
        [(key, json.dumps(value, ensure_ascii=False)) for key, value in meta.items()],
    )
    conn.executemany(
        """
        INSERT INTO outputs(output_index, tool_id, node_id, output_key, column_name, edge_type, labels_json)
        VALUES(?, ?, ?, ?, ?, ?, ?)
        """,
        [
            (
                spec.index,
                spec.tool_id,
                spec.node_id,
                spec.key,
                spec.column,
                spec.edge_type,
                json.dumps(spec.labels, ensure_ascii=False),
            )
            for spec in output_specs
        ],
    )
    conn.commit()


def _log_step_start(log: Callable[[str], None], name: str) -> float:
    start = time.perf_counter()
    log(f"开始{name}。")
    return start


def _log_step_end(log: Callable[[str], None], name: str, start: float, detail: str = "") -> None:
    elapsed = time.perf_counter() - start
    suffix = f"，{detail}" if detail else ""
    log(f"完成{name}，耗时={elapsed:.2f}s{suffix}。")


def _ensure_cache_frame_row(
    conn: sqlite3.Connection,
    *,
    prefix: str,
    frame_item: FrameItem,
    image_path: str,
) -> int:
    frame_key = f"{prefix}:{frame_item.sample_index}"
    conn.execute(
        """
        INSERT OR IGNORE INTO frames(frame_key, file_name, sample_index, source_frame, timestamp_sec, image_path)
        VALUES(?, ?, ?, ?, ?, ?)
        """,
        (
            frame_key,
            frame_item.file_name,
            frame_item.sample_index,
            frame_item.source_frame,
            frame_item.timestamp_sec,
            image_path,
        ),
    )
    row = conn.execute("SELECT frame_id FROM frames WHERE frame_key = ?", (frame_key,)).fetchone()
    if not row:
        raise RuntimeError(f"写入推理缓存帧记录失败：{frame_key}")
    return int(row[0])


def _write_output_values_to_cache(
    conn: sqlite3.Connection,
    *,
    frame_db_id: int,
    outputs: List[Dict[str, object]],
) -> None:
    conn.executemany(
        """
        INSERT OR REPLACE INTO output_values(
            frame_id, output_index, output_key, property_type, binary_b64, error
        ) VALUES(?, ?, ?, ?, ?, ?)
        """,
        [
            (
                frame_db_id,
                int(output["index"]),
                str(output["key"]),
                str(output["property_type"]),
                str(output["binary_b64"]),
                str(output["error"]),
            )
            for output in outputs
        ],
    )


def _empty_outputs_for_specs(output_specs: List[OutputSpec]) -> List[Dict[str, object]]:
    return [
        {
            "index": spec.index,
            "key": spec.key,
            "property_type": spec.edge_type,
            "binary_b64": "",
            "error": "",
        }
        for spec in output_specs
    ]


def _write_skipped_model_outputs_to_cache(
    conn: sqlite3.Connection,
    *,
    prefix: str,
    frame_items: List[FrameItem],
    frames_dir: Path,
    model_runtime: ModelRuntime,
    skipped_indices: List[int],
    log: Callable[[str], None],
) -> int:
    """Write empty output rows for frames intentionally skipped by a model stage."""
    if not skipped_indices:
        return 0
    cached_frame_paths = [_frame_png_path(frames_dir, item) for item in frame_items]
    empty_outputs = _empty_outputs_for_specs(model_runtime.output_specs)
    if not empty_outputs:
        return 0
    stage_start = _log_step_start(log, "2#空输出占位写入")
    written = 0
    for frame_index in skipped_indices:
        frame_item = frame_items[frame_index]
        frame_db_id = _ensure_cache_frame_row(
            conn,
            prefix=prefix,
            frame_item=frame_item,
            image_path=str(cached_frame_paths[frame_index]),
        )
        _write_output_values_to_cache(conn, frame_db_id=frame_db_id, outputs=empty_outputs)
        written += len(empty_outputs)
    conn.commit()
    _log_step_end(log, "2#空输出占位写入", stage_start, f"帧数={len(skipped_indices)}，输出记录={written}")
    return written


def _output_has_any_region(output: Dict[str, object]) -> bool:
    if str(output.get("error", "")):
        return False
    if "RegionList" not in str(output.get("edge_type") or output.get("property_type") or ""):
        return False
    binary_b64 = str(output.get("binary_b64", "") or "")
    if not binary_b64:
        return False
    try:
        prop = decode_property(str(output.get("edge_type") or output.get("property_type") or ""), binary_b64)
        return bool(_normalize_regions(prop))
    except Exception:
        return False


def _frame_has_target_output(outputs: List[Dict[str, object]], target_output_key: str) -> bool:
    target_key = str(target_output_key or "").strip()
    if not target_key:
        return False
    for output in outputs:
        if str(output.get("key", "")) == target_key and _output_has_any_region(output):
            return True
    return False


def _frame_has_stage2_sparse_trigger_output(outputs: List[Dict[str, object]], trigger_output_key: str) -> bool:
    """Return whether 2# sparse probe should trigger neighborhood refinement."""
    # [2#稀疏补推][生产迭代01]
    # 修改人: Shiver; 修改时间: 2026-06-25;
    # 修改逻辑: 复用现有RegionList解析能力判断2#漏滴输出是否命中；
    # trigger_output_key为空时退化为任意RegionList非空，避免配置缺失导致完全不补推。
    trigger_key = str(trigger_output_key or "").strip()
    for output in outputs:
        if trigger_key and str(output.get("key", "")) != trigger_key:
            continue
        if _output_has_any_region(output):
            return True
    return False


def _stage2_sparse_rule3_leak_hit_indices(rule_result: MemoryRuleResult, candidate_indices: Set[int]) -> Set[int]:
    """Return sampled-frame indices whose rule3 output still contains valid leak regions."""
    # [2#稀疏补推][生产迭代02-rule3触发]
    # 修改人: Shiver; 修改时间: 2026-06-25;
    # 修改逻辑: C组补推触发不直接看2#原始漏滴，而是读取 rule/cxmt_rule_3_0_arm_region_filter
    # 中经过空间过滤后仍保留的“漏滴”区域。
    candidate_set = {int(index) for index in candidate_indices}
    frame_id_to_sample_index: Dict[int, int] = {}
    for frame in rule_result.frames:
        try:
            frame_id_to_sample_index[int(frame.get("frame_id"))] = int(frame.get("sample_index"))
        except Exception:
            continue
    hit_indices: Set[int] = set()
    for value in rule_result.output_values:
        if str(value.get("output_key") or "") != "rule/cxmt_rule_3_0_arm_region_filter":
            continue
        if str(value.get("error") or ""):
            continue
        sample_index = frame_id_to_sample_index.get(int(value.get("frame_id", -1) or -1))
        if sample_index not in candidate_set:
            continue
        binary_b64 = str(value.get("binary_b64") or "")
        if not binary_b64:
            continue
        try:
            prop = decode_property(str(value.get("property_type") or ""), binary_b64)
        except Exception:
            continue
        for region in _normalize_regions(prop):
            try:
                if str(region.name()) == "漏滴":
                    hit_indices.add(int(sample_index))
                    break
            except Exception:
                continue
    return hit_indices


def _find_first_consecutive_true(values: List[bool], count: int) -> Optional[int]:
    needed = max(1, int(count or 1))
    streak = 0
    for idx, value in enumerate(values):
        streak = streak + 1 if value else 0
        if streak >= needed:
            return idx - needed + 1
    return None


def _find_last_consecutive_true(values: List[bool], count: int) -> Optional[int]:
    needed = max(1, int(count or 1))
    streak = 0
    for idx in range(len(values) - 1, -1, -1):
        streak = streak + 1 if values[idx] else 0
        if streak >= needed:
            return idx + needed - 1
    return None


def _target_interval_indices(
    frame_items: List[FrameItem],
    target_hits: List[bool],
    *,
    min_consecutive_frames: int,
    pre_expand_sec: float,
    post_expand_sec: float,
) -> Optional[List[int]]:
    if not frame_items or len(frame_items) != len(target_hits):
        return None
    start_idx = _find_first_consecutive_true(target_hits, min_consecutive_frames)
    end_idx = _find_last_consecutive_true(target_hits, min_consecutive_frames)
    if start_idx is None or end_idx is None or start_idx > end_idx:
        return None

    start_sec = max(0.0, float(frame_items[start_idx].timestamp_sec) - max(0.0, float(pre_expand_sec or 0.0)))
    end_sec = float(frame_items[end_idx].timestamp_sec) + max(0.0, float(post_expand_sec or 0.0))
    selected = [
        idx
        for idx, item in enumerate(frame_items)
        if start_sec <= float(item.timestamp_sec) <= end_sec
    ]
    return selected or None


def _run_model_inference_stage(
    *,
    conn: sqlite3.Connection,
    prefix: str,
    frame_items: List[FrameItem],
    frames_dir: Path,
    model_number: int,
    input_mode: str,
    source_idx: int,
    total_sources: int,
    infer_workers: int,
    frame_queue_size: int,
    acquire_runtime: Callable[[], List[ModelRuntime]],
    release_runtime: Callable[[List[ModelRuntime]], None],
    log: Callable[[str], None],
    progress: Optional[Callable[[int, int, str], None]] = None,
    should_stop: Optional[Callable[[], bool]] = None,
    frame_indices: Optional[List[int]] = None,
    target_output_key: str = "",
    save_multi_windows: bool = False,
    run_root: Optional[Path] = None,
    video_name: str = "",
    multi_image_before: int = 2,
    multi_image_after: int = 2,
) -> object:
    """Run one model over all prepared PNG frames and save its outputs."""
    cached_frame_paths = [_frame_png_path(frames_dir, item) for item in frame_items]
    process_indices = list(frame_indices) if frame_indices is not None else list(range(len(frame_items)))
    if input_mode not in {"single", "multi"}:
        raise ValueError(f"不支持的推理输入模式：{input_mode}")
    window_size = max(1, int(multi_image_before) + 1 + int(multi_image_after))
    mode_text = "单图 FromFile" if input_mode == "single" else f"多图 FromFiles 窗口(前{multi_image_before}+当前+后{multi_image_after}，共{window_size}张，首尾平移)"
    log(
        f"{model_number}#模型推理执行："
        f"待推理帧数={len(process_indices)}/{len(frame_items)}，输入={mode_text}，结果追加写入 SQLite。"
    )
    stage_name = f"{model_number}#模型推理"
    stage_start = _log_step_start(log, stage_name)
    processed_count = 0
    target_hits: List[bool] = [False] * len(frame_items)

    def execute_one(frame_index: int) -> Tuple[int, List[Dict[str, object]]]:
        runtimes = acquire_runtime()
        try:
            if len(runtimes) <= model_number - 1:
                raise RuntimeError(f"runtime 组中缺少 {model_number}#模型。")
            runtime_info = runtimes[model_number - 1]
            if input_mode == "single":
                outputs = _execute_single_image_model_outputs(cached_frame_paths[frame_index], runtime_info)
            else:
                outputs = _execute_multi_image_model_outputs(
                    cached_frame_paths,
                    frame_index,
                    runtime_info,
                    before=multi_image_before,
                    after=multi_image_after,
                )
            return frame_index, outputs
        finally:
            release_runtime(runtimes)

    worker_count = max(1, int(infer_workers or 1))
    max_pending = max(1, int(frame_queue_size or worker_count * 2))
    pending: Dict[object, int] = {}

    def write_result(frame_index: int, outputs: List[Dict[str, object]]) -> None:
        nonlocal processed_count
        frame_item = frame_items[frame_index]
        frame_db_id = _ensure_cache_frame_row(
            conn,
            prefix=prefix,
            frame_item=frame_item,
            image_path=str(cached_frame_paths[frame_index]),
        )
        _write_output_values_to_cache(conn, frame_db_id=frame_db_id, outputs=outputs)
        if target_output_key:
            target_hits[frame_index] = _frame_has_target_output(outputs, target_output_key)
        processed_count += 1
        if processed_count % 20 == 0:
            conn.commit()
        # if progress:
        #     progress(processed_count, max(1, len(process_indices)), f"{model_number}#模型推理 {source_idx}/{total_sources}")
        # if processed_count % 50 == 0:
        #     log(f"{model_number}#模型已推理 {processed_count} 帧...")

    with ThreadPoolExecutor(max_workers=worker_count) as executor:
        def finish_completed(done_items) -> None:
            for future in done_items:
                frame_index, outputs = future.result()
                pending.pop(future, None)
                write_result(frame_index, outputs)

        for frame_index in process_indices:
            if should_stop and should_stop():
                log(f"收到中止请求，停止 {model_number}#模型推理。")
                break
            if input_mode == "multi" and save_multi_windows:
                if run_root is None:
                    raise RuntimeError("保存 2#多图窗口需要 run_root。")
                _save_multi_image_window_files(
                    frame_paths=cached_frame_paths,
                    center_index=frame_index,
                    frame_items=frame_items,
                    run_root=run_root,
                    video_name=video_name or prefix,
                    before=multi_image_before,
                    after=multi_image_after,
                    model_entry_index=1,
                )
            future = executor.submit(execute_one, frame_index)
            pending[future] = frame_index
            if len(pending) >= max_pending:
                done, _not_done = wait(pending.keys(), return_when=FIRST_COMPLETED)
                finish_completed(done)
        while pending:
            done, _not_done = wait(pending.keys(), return_when=FIRST_COMPLETED)
            finish_completed(done)

    conn.commit()
    elapsed = time.perf_counter() - stage_start
    fps_text = f"{(processed_count / elapsed):.2f} FPS" if elapsed > 0 and processed_count > 0 else "N/A"
    _log_step_end(log, stage_name, stage_start, f"帧数={processed_count}/{len(process_indices)}，速度={fps_text}")
    if input_mode == "multi" and save_multi_windows and run_root is not None:
        log(f"2#多图窗口已保存：{run_root / 'windows'}")
    return target_hits if target_output_key else processed_count


def run_inference_cache(
    *,
    input_path: Path,
    model_path: Path,
    model_paths: Optional[List[Path]] = None,
    output_root: Path,
    target_fps: float,
    start_ms: float,
    end_ms: Optional[float],
    save_frames: bool,
    device_ids: List[int],
    allow_cpu: bool,
    parallel_infer: bool = False,
    infer_workers: int = 1,
    password: str = "",
    log: Callable[[str], None] = print,
    progress: Optional[Callable[[int, int, str], None]] = None,
    should_stop: Optional[Callable[[], bool]] = None,
) -> List[Path]:
    """执行模型推理并生成推理缓存 DB。

    输入可以是单个视频、单张图片，也可以是包含视频/图片的文件夹。
    每个输入源会生成一个独立输出目录和一个 `*_infer_cache.sqlite`。
    """
    _require_runtime_deps()
    sources = collect_media_sources(input_path)
    if not sources:
        raise RuntimeError(f"没有找到可处理的视频或图片：{input_path}")

    selected_model_paths = [Path(path) for path in (model_paths or [model_path]) if str(path).strip()]
    if not selected_model_paths:
        raise RuntimeError("未选择模型。")
    model_path = selected_model_paths[0]

    output_specs = inspect_models(selected_model_paths, password=password)
    if not output_specs:
        raise RuntimeError("模型中没有找到可缓存的输出节点")

    worker_count = max(1, int(infer_workers or 1))
    use_parallel_infer = bool(parallel_infer) and worker_count > 1
    model_runtimes: List[ModelRuntime] = []
    if use_parallel_infer:
        log(f"模型数：{len(selected_model_paths)}，模型输出数：{len(output_specs)}")
        log(f"并行推理已启用：{worker_count} 线程；每个线程独立加载 runtime，主线程统一写 DB。")
        for idx, path in enumerate(selected_model_paths, 1):
            log(f"  [{idx}] {path}")
    else:
        model_runtimes = _open_model_runtimes(
            selected_model_paths,
            output_specs,
            device_ids=device_ids,
            allow_cpu=allow_cpu,
            password=password,
        )
        if not model_runtimes:
            raise RuntimeError("模型运行时初始化失败：没有可执行模型。")
        log(f"模型数：{len(model_runtimes)}，模型输出数：{len(output_specs)}")
        for idx, runtime_info in enumerate(model_runtimes, 1):
            log(f"  [{idx}] {runtime_info.model_path}")

    output_root.mkdir(parents=True, exist_ok=True)
    written_dbs: List[Path] = []
    worker_state = threading.local()
    worker_load_lock = threading.Lock()

    def parallel_frame_outputs(frame_image):
        runtimes = getattr(worker_state, "model_runtimes", None)
        if runtimes is None:
            # VisionFlow 初始化和模型加载阶段不一定适合并发进入；这里仅串行
            # 加载每个线程自己的 runtime，加载完成后的 execute 才并行。
            with worker_load_lock:
                runtimes = _open_model_runtimes(
                    selected_model_paths,
                    output_specs,
                    device_ids=device_ids,
                    allow_cpu=allow_cpu,
                    password=password,
                )
            if not runtimes:
                raise RuntimeError("并行推理 worker 初始化失败：没有可执行模型。")
            worker_state.model_runtimes = runtimes
        return _execute_frame_outputs(frame_image, runtimes)

    executor = ThreadPoolExecutor(max_workers=worker_count) if use_parallel_infer else None

    total_sources = len(sources)
    used_prefixes: Dict[str, int] = {}
    try:
        for source_idx, source in enumerate(sources, 1):
            if should_stop and should_stop():
                break
            source_path = source.path
            base_prefix = sanitize_name(source_path.stem)
            count = used_prefixes.get(base_prefix, 0)
            used_prefixes[base_prefix] = count + 1
            if count:
                digest = hashlib.sha1(str(source_path).encode("utf-8")).hexdigest()[:8]
                prefix = f"{base_prefix}_{digest}"
            else:
                prefix = base_prefix
            run_root = output_root / prefix
            frames_dir = run_root / "frames"
            db_path = run_root / f"{prefix}_infer_cache.sqlite"
            _clear_inference_output(run_root, log=log)
            run_root.mkdir(parents=True, exist_ok=True)
            processing_info = _source_processing_info(
                source,
                requested_target_fps=target_fps,
                start_ms=start_ms,
                end_ms=end_ms,
                log=log,
            )
            _write_processing_info(run_root, processing_info)

            conn = _connect_cache(db_path)
            _init_cache_db(
                conn,
                model_path=model_path,
                model_paths=selected_model_paths,
                input_path=input_path,
                output_specs=output_specs,
                target_fps=target_fps,
                start_ms=start_ms,
                end_ms=end_ms,
                save_frames=save_frames,
                processing_info=processing_info,
            )

            log(f"[{source_idx}/{total_sources}] 开始推理 {source.media_type}：{source_path.name}")
            log(
                "处理信息："
                f"源 FPS={float(processing_info.get('src_fps') or 0):.3f}，"
                f"实际拆帧 FPS={float(processing_info.get('actual_sample_fps') or 1):.3f}，"
                f"预计帧数={int(processing_info.get('expected_frames') or 1)}"
            )

            def write_frame_result(frame_item: FrameItem, image_path: str, outputs: List[Dict[str, object]]) -> None:
                cur = conn.execute(
                    """
                    INSERT INTO frames(frame_key, file_name, sample_index, source_frame, timestamp_sec, image_path)
                    VALUES(?, ?, ?, ?, ?, ?)
                    """,
                    (
                        f"{prefix}:{frame_item.sample_index}",
                        frame_item.file_name,
                        frame_item.sample_index,
                        frame_item.source_frame,
                        frame_item.timestamp_sec,
                        image_path,
                    ),
                )
                frame_db_id = int(cur.lastrowid)
                conn.executemany(
                    """
                    INSERT INTO output_values(
                        frame_id, output_index, output_key, property_type, binary_b64, error
                    ) VALUES(?, ?, ?, ?, ?, ?)
                    """,
                    [
                        (
                            frame_db_id,
                            int(output["index"]),
                            str(output["key"]),
                            str(output["property_type"]),
                            str(output["binary_b64"]),
                            str(output["error"]),
                        )
                        for output in outputs
                    ],
                )

            try:
                if source.media_type == "video":
                    frame_iter = _iter_video_frames(
                        source_path,
                        prefix=prefix,
                        target_fps=target_fps,
                        start_ms=start_ms,
                        end_ms=end_ms,
                        log=log,
                    )
                else:
                    frame_iter = _iter_image_frames(source_path, prefix=prefix)

                processed_count = 0
                if use_parallel_infer and executor is not None:
                    pending: Dict[object, tuple] = {}
                    max_pending = max(1, worker_count * 2)

                    def finish_completed(done_items) -> None:
                        nonlocal processed_count
                        for future in done_items:
                            frame_item, image_path = pending.pop(future)
                            outputs = future.result()
                            write_frame_result(frame_item, image_path, outputs)
                            processed_count += 1
                            if processed_count % 20 == 0:
                                conn.commit()
                            if progress:
                                progress(processed_count, frame_item.expected_count, f"并行推理 {source_idx}/{total_sources}")
                            if processed_count % 50 == 0:
                                log(f"已推理 {processed_count} 帧...")

                    for frame_item in frame_iter:
                        if should_stop and should_stop():
                            log("收到中止请求，停止提交新的推理帧。")
                            break
                        image_path = ""
                        if save_frames:
                            out_img = frames_dir / frame_item.file_name
                            if _imwrite_unicode(out_img, frame_item.image):
                                image_path = str(out_img)
                        future = executor.submit(parallel_frame_outputs, frame_item.image)
                        pending[future] = (frame_item, image_path)
                        if len(pending) >= max_pending:
                            done, _not_done = wait(pending.keys(), return_when=FIRST_COMPLETED)
                            finish_completed(done)
                    while pending:
                        done, _not_done = wait(pending.keys(), return_when=FIRST_COMPLETED)
                        finish_completed(done)
                    conn.commit()
                else:
                    for frame_item in frame_iter:
                        if should_stop and should_stop():
                            log("收到中止请求，停止推理。")
                            break
                        image_path = ""
                        if save_frames:
                            out_img = frames_dir / frame_item.file_name
                            if _imwrite_unicode(out_img, frame_item.image):
                                image_path = str(out_img)

                        outputs = _execute_frame_outputs(frame_item.image, model_runtimes)
                        write_frame_result(frame_item, image_path, outputs)
                        processed_count += 1
                        if processed_count % 20 == 0:
                            conn.commit()
                        if progress:
                            progress(processed_count, frame_item.expected_count, f"推理 {source_idx}/{total_sources}")
                        if processed_count % 50 == 0:
                            log(f"已推理 {processed_count} 帧...")
                    conn.commit()
            finally:
                conn.close()
            log(f"推理缓存 DB：{db_path}")
            written_dbs.append(db_path)
    finally:
        if executor is not None:
            executor.shutdown(wait=True, cancel_futures=True)
    return written_dbs


def _run_inference_cache_prepared_orchestrated(
    *,
    sources: List[MediaSource],
    prepared_context: PreparedInferenceContext,
    output_root: Path,
    target_fps: float,
    start_ms: float,
    end_ms: Optional[float],
    save_frames: bool,
    infer_workers: int,
    frame_queue_size: int,
    video_workers: int,
    target_filter_enabled: bool,
    target_output_key: str,
    target_min_consecutive_frames: int,
    target_pre_expand_sec: float,
    target_post_expand_sec: float,
    multi_image_before_frames: int,
    multi_image_after_frames: int,
    save_multi_image_windows: bool,
    require_two_models: bool,
    log: Callable[[str], None],
    progress: Optional[Callable[[int, int, str], None]],
    should_stop: Optional[Callable[[], bool]],
) -> List[Path]:
    selected_model_paths = prepared_context.model_paths
    if require_two_models and len(selected_model_paths) != 2:
        raise RuntimeError("当前模型编排固定需要 2 个模型：1#单图推理模型 和 2#多图推理模型。")
    if len(selected_model_paths) < 2:
        raise RuntimeError("启用模型编排至少需要 2 个模型：1#单图 + 2#多图。")
    if target_filter_enabled and not str(target_output_key or "").strip():
        raise RuntimeError("已启用 1#结果筛选，但 model_orchestration_config.TARGET_OUTPUT_KEY 为空。")

    output_root.mkdir(parents=True, exist_ok=True)
    selected_model_paths = selected_model_paths[:2]
    model_path = selected_model_paths[0]
    output_specs = prepared_context.output_specs
    total_sources = len(sources)
    used_prefixes: Dict[str, int] = {}
    prefix_lock = threading.Lock()
    before = max(0, int(multi_image_before_frames or 0))
    after = max(0, int(multi_image_after_frames or 0))
    window_size = before + 1 + after
    orchestration_info = {
        "enabled": True,
        "mode": "1#single+2#multi",
        "require_two_models": bool(require_two_models),
        "single_model": str(selected_model_paths[0]),
        "multi_model": str(selected_model_paths[1]),
        "multi_image_before_frames": before,
        "multi_image_after_frames": after,
        "multi_image_window_size": window_size,
        "save_multi_image_windows": bool(save_multi_image_windows),
        "target_filter_enabled": bool(target_filter_enabled),
        "target_output_key": str(target_output_key or ""),
        "target_min_consecutive_frames": int(target_min_consecutive_frames or 1),
        "target_pre_expand_sec": float(target_pre_expand_sec or 0.0),
        "target_post_expand_sec": float(target_post_expand_sec or 0.0),
    }
    log(
        "模型编排启用：1#单图 + 2#多图，"
        f"窗口=前{before}+当前+后{after}（共{window_size}张），"
        f"1#筛选={'开启' if target_filter_enabled else '关闭'}。"
    )
    log(f"  [1#单图模型] {selected_model_paths[0]}")
    log(f"  [2#多图模型] {selected_model_paths[1]}")

    def unique_prefix(source: MediaSource) -> str:
        base_prefix = sanitize_name(source.output_name or source.path.stem)
        with prefix_lock:
            count = used_prefixes.get(base_prefix, 0)
            used_prefixes[base_prefix] = count + 1
        if count:
            digest_seed = f"{source.output_name or ''}/{source.path}"
            digest = hashlib.sha1(digest_seed.encode("utf-8")).hexdigest()[:8]
            return f"{base_prefix}_{digest}"
        return base_prefix

    def process_source(source_idx: int, source: MediaSource) -> Path:
        if should_stop and should_stop():
            raise RuntimeError("收到中止请求。")
        source_path = source.path
        video_started_monotonic = time.monotonic()
        video_started_at = time.strftime("%Y-%m-%d %H:%M:%S")
        log(f"[{source_idx}/{total_sources}] 视频开始处理：{source_path.name}，start_at={video_started_at}")
        prefix = unique_prefix(source)
        run_root = output_root / prefix
        frames_dir = run_root / "frames"
        db_path = run_root / f"{prefix}_infer_cache.sqlite"
        _clear_inference_output(run_root, log=log)
        run_root.mkdir(parents=True, exist_ok=True)
        processing_info = _source_processing_info(
            source,
            requested_target_fps=target_fps,
            start_ms=start_ms,
            end_ms=end_ms,
            log=log,
        )
        _write_processing_info(run_root, processing_info)
        conn = _connect_cache(db_path)
        try:
            _init_cache_db(
                conn,
                model_path=model_path,
                model_paths=selected_model_paths,
                input_path=source_path,
                output_specs=output_specs,
                target_fps=target_fps,
                start_ms=start_ms,
                end_ms=end_ms,
                save_frames=save_frames,
                processing_info=processing_info,
                model_orchestration_info=orchestration_info,
            )
            log(f"[{source_idx}/{total_sources}] 开始编排推理 {source.media_type}：{source_path.name}")
            log(
                "处理信息："
                f"源 FPS={float(processing_info.get('src_fps') or 0):.3f}，"
                f"实际拆帧 FPS={float(processing_info.get('actual_sample_fps') or 1):.3f}，"
                f"预计帧数={int(processing_info.get('expected_frames') or 1)}"
            )
            stage_name = f"[{source_idx}/{total_sources}] 阶段 1/3 PNG帧缓存"
            stage_start = _log_step_start(log, stage_name)
            frame_items = _ensure_frame_cache(
                source,
                prefix=prefix,
                frames_dir=frames_dir,
                target_fps=target_fps,
                start_ms=start_ms,
                end_ms=end_ms,
                log=log,
                progress=progress,
                should_stop=should_stop,
            )
            _log_step_end(log, stage_name, stage_start, f"帧数={len(frame_items)}")

            target_hits = _run_model_inference_stage(
                conn=conn,
                prefix=prefix,
                frame_items=frame_items,
                frames_dir=frames_dir,
                model_number=1,
                input_mode="single",
                source_idx=source_idx,
                total_sources=total_sources,
                infer_workers=infer_workers,
                frame_queue_size=frame_queue_size,
                acquire_runtime=prepared_context.acquire_runtime,
                release_runtime=prepared_context.release_runtime,
                log=log,
                progress=progress,
                should_stop=should_stop,
                target_output_key=str(target_output_key or "") if target_filter_enabled else "",
            )
            target_frame_indices: Optional[List[int]] = None
            if should_stop and should_stop():
                runtime_group = prepared_context.acquire_runtime()
                try:
                    _write_skipped_model_outputs_to_cache(
                        conn,
                        prefix=prefix,
                        frame_items=frame_items,
                        frames_dir=frames_dir,
                        model_runtime=runtime_group[1],
                        skipped_indices=list(range(len(frame_items))),
                        log=log,
                    )
                finally:
                    prepared_context.release_runtime(runtime_group)
                infer_elapsed_ms = int((time.monotonic() - video_started_monotonic) * 1000)
                log(f"[{source_idx}/{total_sources}] 视频推理阶段完成：{source_path.name}，infer_elapsed_ms={infer_elapsed_ms}")
                log(f"推理缓存 DB：{db_path}")
                return db_path

            if target_filter_enabled:
                hits = list(target_hits) if isinstance(target_hits, list) else []
                hit_count = sum(1 for item in hits if item)
                log(f"1#目标判定完成：命中帧={hit_count}/{len(frame_items)}，连续阈值={int(target_min_consecutive_frames or 1)}。")
                target_frame_indices = _target_interval_indices(
                    frame_items,
                    hits,
                    min_consecutive_frames=int(target_min_consecutive_frames or 1),
                    pre_expand_sec=float(target_pre_expand_sec or 0.0),
                    post_expand_sec=float(target_post_expand_sec or 0.0),
                )
                if not target_frame_indices:
                    log("未找到满足连续帧阈值的目标区间，跳过 2#多图模型推理。")
                    runtime_group = prepared_context.acquire_runtime()
                    try:
                        _write_skipped_model_outputs_to_cache(
                            conn,
                            prefix=prefix,
                            frame_items=frame_items,
                            frames_dir=frames_dir,
                            model_runtime=runtime_group[1],
                            skipped_indices=list(range(len(frame_items))),
                            log=log,
                        )
                    finally:
                        prepared_context.release_runtime(runtime_group)
                    log(f"推理缓存 DB：{db_path}")
                    return db_path
                first_item = frame_items[target_frame_indices[0]]
                last_item = frame_items[target_frame_indices[-1]]
                log(
                    "2#目标推理区间（含前后扩展）："
                    f"帧索引 {first_item.sample_index}-{last_item.sample_index}，"
                    f"时间 {first_item.timestamp_sec:.3f}s-{last_item.timestamp_sec:.3f}s，"
                    f"推理帧数={len(target_frame_indices)}/{len(frame_items)}。"
                )

            process_indices_2 = target_frame_indices if target_frame_indices is not None else list(range(len(frame_items)))
            processed_2 = _run_model_inference_stage(
                conn=conn,
                prefix=prefix,
                frame_items=frame_items,
                frames_dir=frames_dir,
                model_number=2,
                input_mode="multi",
                source_idx=source_idx,
                total_sources=total_sources,
                infer_workers=infer_workers,
                frame_queue_size=frame_queue_size,
                acquire_runtime=prepared_context.acquire_runtime,
                release_runtime=prepared_context.release_runtime,
                log=log,
                progress=progress,
                should_stop=should_stop,
                frame_indices=target_frame_indices,
                save_multi_windows=save_multi_image_windows,
                run_root=run_root,
                video_name=prefix,
                multi_image_before=before,
                multi_image_after=after,
            )
            try:
                processed_2_count = int(processed_2)
            except Exception:
                processed_2_count = len(process_indices_2)
            processed_2_set = set(process_indices_2[: max(0, min(processed_2_count, len(process_indices_2)))])
            skipped_indices: List[int] = []
            if target_filter_enabled and target_frame_indices is not None:
                skipped_indices = [idx for idx in range(len(frame_items)) if idx not in processed_2_set]
            elif should_stop and should_stop() and processed_2_count < len(process_indices_2):
                skipped_indices = [idx for idx in process_indices_2 if idx not in processed_2_set]
            if skipped_indices:
                runtime_group = prepared_context.acquire_runtime()
                try:
                    _write_skipped_model_outputs_to_cache(
                        conn,
                        prefix=prefix,
                        frame_items=frame_items,
                        frames_dir=frames_dir,
                        model_runtime=runtime_group[1],
                        skipped_indices=skipped_indices,
                        log=log,
                    )
                finally:
                    prepared_context.release_runtime(runtime_group)
            infer_elapsed_ms = int((time.monotonic() - video_started_monotonic) * 1000)
            log(f"[{source_idx}/{total_sources}] 视频推理阶段完成：{source_path.name}，infer_elapsed_ms={infer_elapsed_ms}")
            log(f"推理缓存 DB：{db_path}")
            return db_path
        finally:
            conn.close()

    video_worker_count = max(1, min(int(video_workers or 1), total_sources))
    if video_worker_count <= 1:
        return [process_source(idx, source) for idx, source in enumerate(sources, 1)]
    written: List[Path] = []
    with ThreadPoolExecutor(max_workers=video_worker_count) as executor:
        future_map = {executor.submit(process_source, idx, source): idx for idx, source in enumerate(sources, 1)}
        for future in as_completed(future_map):
            written.append(future.result())
    return written
def run_inference_memory_prepared(
    *,
    sources: List[MediaSource],
    prepared_context: PreparedInferenceContext,
    target_fps: float,
    start_ms: float,
    end_ms: Optional[float],
    infer_workers: int = 1,
    frame_queue_size: int = 4,
    video_workers: int = 1,
    orchestration_enabled: bool = False,
    require_two_models: bool = True,
    target_filter_enabled: bool = False,
    target_output_key: str = "",
    target_min_consecutive_frames: int = 3,
    target_pre_expand_sec: float = 0.0,
    target_post_expand_sec: float = 0.0,
    multi_image_before_frames: int = 2,
    multi_image_after_frames: int = 2,
    stage2_sparse_enabled: bool = False,
    stage2_sparse_stride: int = 3,
    stage2_sparse_refine_radius: int = 2,
    stage2_sparse_boundary_dense_radius: int = 10,
    stage2_sparse_trigger_output_key: str = "",
    stage2_sparse_trigger_mode: str = "model_raw",
    stage2_sparse_fallback_hit_rate: float = 0.0,
    bounded_streaming: bool = False,
    provider_cache_size: int = 16,
    diagnostic_run_id: str = "",
    log: Callable[[str], None] = print,
    progress: Optional[Callable[[int, int, str], None]] = None,
    should_stop: Optional[Callable[[], bool]] = None,
) -> List[MemoryInferenceResult]:
    """Run inference without writing intermediate frames or SQLite cache files."""
    _require_runtime_deps()
    if not sources:
        raise RuntimeError("没有找到可处理的视频或图片。")
    selected_model_paths = prepared_context.model_paths
    if orchestration_enabled:
        if require_two_models and len(selected_model_paths) != 2:
            raise RuntimeError("当前模型编排固定需要 2 个模型：1#单图推理模型 和 2#多图推理模型。")
        if len(selected_model_paths) < 2:
            raise RuntimeError("启用模型编排至少需要 2 个模型：1#单图 + 2#多图。")
        if target_filter_enabled and not str(target_output_key or "").strip():
            raise RuntimeError("已启用 1#结果筛选，但 model_orchestration_config.TARGET_OUTPUT_KEY 为空。")
    before = max(0, int(multi_image_before_frames or 0))
    after = max(0, int(multi_image_after_frames or 0))
    # [2#稀疏补推][生产迭代01]
    # 修改人: Shiver; 修改时间: 2026-06-25;
    # 修改逻辑: 统一标准化2#稀疏扫描参数，默认关闭且不影响旧全量2#路径。
    sparse_stride = max(1, int(stage2_sparse_stride or 1))
    sparse_refine_radius = max(0, int(stage2_sparse_refine_radius or 0))
    sparse_boundary_dense_radius = max(0, int(stage2_sparse_boundary_dense_radius or 0))
    sparse_trigger_output_key = str(stage2_sparse_trigger_output_key or "").strip()
    sparse_trigger_mode = str(stage2_sparse_trigger_mode or "model_raw").strip().lower()
    if sparse_trigger_mode not in {"model_raw", "rule3_filtered"}:
        sparse_trigger_mode = "model_raw"
    sparse_fallback_hit_rate = max(0.0, float(stage2_sparse_fallback_hit_rate or 0.0))
    total_sources = len(sources)
    used_prefixes: Dict[str, int] = {}
    prefix_lock = threading.Lock()

    def unique_prefix(source: MediaSource) -> str:
        base_prefix = sanitize_name(source.output_name or source.path.stem)
        with prefix_lock:
            count = used_prefixes.get(base_prefix, 0)
            used_prefixes[base_prefix] = count + 1
        if count:
            digest_seed = f"{source.output_name or ''}/{source.path}"
            digest = hashlib.sha1(digest_seed.encode("utf-8")).hexdigest()[:8]
            return f"{base_prefix}_{digest}"
        return base_prefix

    def process_source(source_idx: int, source: MediaSource) -> MemoryInferenceResult:
        if should_stop and should_stop():
            raise RuntimeError("收到中止请求。")
        source_path = source.path
        video_started_monotonic = time.monotonic()
        video_started_at = time.strftime("%Y-%m-%d %H:%M:%S")
        log(f"[{source_idx}/{total_sources}] 视频开始处理：{source_path.name}，start_at={video_started_at}")
        prefix = unique_prefix(source)
        # [视频处理耗时复盘JSONL][第一版]
        # 修改人: Shiver; 修改时间: 2026-06-24;
        # 修改逻辑: 记录单视频基础信息读取耗时，供服务层写 video_prepare 阶段 trace。
        video_prepare_started = time.monotonic()
        processing_info = _source_processing_info(
            source,
            requested_target_fps=target_fps,
            start_ms=start_ms,
            end_ms=end_ms,
            log=log,
        )
        video_prepare_ms = int((time.monotonic() - video_prepare_started) * 1000)
        metadata = {
            "schema_version": SCHEMA_VERSION,
            "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
            "model_path": str(selected_model_paths[0]),
            "model_paths": [str(path) for path in selected_model_paths],
            "input_path": str(source_path),
            "target_fps": target_fps,
            "start_ms": start_ms,
            "end_ms": end_ms,
            "save_frames": False,
            "processing_info": processing_info,
            "video_prepare_ms": video_prepare_ms,
            "model_orchestration": {
                "enabled": bool(orchestration_enabled),
                "mode": "1#single+2#multi" if orchestration_enabled else "single",
                "multi_image_before_frames": before,
                "multi_image_after_frames": after,
                "target_filter_enabled": bool(target_filter_enabled),
                "target_output_key": str(target_output_key or ""),
                # [2#稀疏补推][生产迭代01]
                # 修改人: Shiver; 修改时间: 2026-06-25;
                # 修改逻辑: 单视频metadata记录本次2#稀疏补推配置，便于从result_json/trace反查实际运行参数。
                "stage2_sparse_enabled": bool(stage2_sparse_enabled),
                "stage2_sparse_stride": sparse_stride,
                "stage2_sparse_refine_radius": sparse_refine_radius,
                "stage2_sparse_boundary_dense_radius": sparse_boundary_dense_radius,
                "stage2_sparse_trigger_output_key": sparse_trigger_output_key,
                "stage2_sparse_trigger_mode": sparse_trigger_mode,
                "stage2_sparse_fallback_hit_rate": sparse_fallback_hit_rate,
            },
            "storage": "memory+aidi_property_binary_base64",
        }
        outputs_meta = [output_spec_dict(spec) for spec in prepared_context.output_specs]
        log(f"[{source_idx}/{total_sources}] 开始内存推理 {source.media_type}：{source_path.name}")
        log(
            "处理信息："
            f"源 FPS={float(processing_info.get('src_fps') or 0):.3f}，"
            f"实际拆帧 FPS={float(processing_info.get('actual_sample_fps') or 1):.3f}，"
            f"预计帧数={int(processing_info.get('expected_frames') or 1)}"
        )
        stage1_video_io_stats = _new_video_io_stats(source_path, "stage1_stream_infer") if source.media_type == "video" else {}
        if source.media_type == "video":
            frame_iter = _iter_video_frames(
                source_path,
                prefix=prefix,
                target_fps=target_fps,
                start_ms=start_ms,
                end_ms=end_ms,
                log=log,
                io_stats=stage1_video_io_stats,
            )
        else:
            frame_iter = _iter_image_frames(source_path, prefix=prefix)
        if bounded_streaming and source.media_type == "video":
            # [1.内存模型预加载整段视频全部帧][生产迭代02-有界流式]
            # 修改人: Shiver; 修改时间: 2026-06-22;
            # 修改逻辑: 第一遍视频解码时直接提交1#模型，Future队列满后等待完成；
            # MemoryFrame只保存元数据，不保存BGR数组，内存上限由frame_queue_size控制。
            worker_count = max(1, int(infer_workers or 1))
            max_pending = max(1, int(frame_queue_size or worker_count * 2))
            output_values: List[object] = []
            frames: List[MemoryFrame] = []
            target_hits: List[bool] = []
            stage1_pending: Dict[object, int] = {}
            stage1_processed = 0
            stage1_peak_pending = 0
            # [视频处理耗时复盘JSONL][第一版]
            # 修改人: Shiver; 修改时间: 2026-06-24;
            # 修改逻辑: 细拆1#流式推理内部耗时，区分墙钟、等待、runtime累计和输出整理。
            stage1_started = time.monotonic()
            stage1_wait_ms = 0
            stage1_runtime_sum_ms = 0
            stage1_append_output_ms = 0
            # [1.内存模型预加载整段视频全部帧][通篇审查-日志关联]
            # 修改人: Shiver; 修改时间: 2026-06-23;
            # 修改逻辑: 所有STREAM日志携带run_id，现场并发时可用一条grep提取完整任务。
            diagnostic_run_text = str(diagnostic_run_id or "unknown")
            log(
                "[1.内存模型预加载整段视频全部帧][STREAM_START] "
                f"run_id={diagnostic_run_text} video={source_path.name} "
                f"queue_limit={max_pending} provider_cache_limit={max(1, int(provider_cache_size or 1))}"
            )

            def append_stream_outputs(frame_index: int, outputs: List[Dict[str, object]]) -> None:
                frame_id = frame_index + 1
                for output in outputs:
                    output_values.append(
                        MemoryOutputValue(
                            frame_id=frame_id,
                            output_index=int(output["index"]),
                            output_key=str(output["key"]),
                            property_type=str(output["property_type"]),
                            binary_b64=str(output["binary_b64"]),
                            error=str(output["error"]),
                        )
                    )

            def execute_single_stream(frame_index: int, frame_image):
                runtimes = prepared_context.acquire_runtime()
                try:
                    if not runtimes:
                        raise RuntimeError("runtime 组中缺少 1#模型。")
                    runtime_started = time.monotonic()
                    outputs = _execute_single_image_model_outputs_from_array(frame_image, runtimes[0])
                    runtime_ms = int((time.monotonic() - runtime_started) * 1000)
                    return frame_index, outputs, runtime_ms
                finally:
                    prepared_context.release_runtime(runtimes)

            with ThreadPoolExecutor(max_workers=worker_count) as executor:
                def finish_stage1(done_items) -> None:
                    nonlocal stage1_processed, stage1_runtime_sum_ms, stage1_append_output_ms
                    for future in done_items:
                        frame_index, outputs, runtime_ms = future.result()
                        stage1_pending.pop(future, None)
                        stage1_runtime_sum_ms += int(runtime_ms or 0)
                        append_started = time.monotonic()
                        append_stream_outputs(frame_index, outputs)
                        stage1_append_output_ms += int((time.monotonic() - append_started) * 1000)
                        if target_filter_enabled:
                            target_hits[frame_index] = _frame_has_target_output(outputs, str(target_output_key or ""))
                        stage1_processed += 1
                        if progress:
                            progress(stage1_processed, max(1, int(processing_info.get("expected_frames") or 1)), f"流式1#推理 {source_idx}/{total_sources}")

                for item in frame_iter:
                    if should_stop and should_stop():
                        # [1.内存模型预加载整段视频全部帧][通篇审查-中止完整性]
                        # 修改人: Shiver; 修改时间: 2026-06-23;
                        # 修改逻辑: 中止时禁止把已拆出的部分帧继续当完整视频处理，明确失败并进入统一清理。
                        raise RuntimeError("收到中止请求，终止流式1#模型推理。")
                    frame_index = len(frames)
                    frames.append(
                        MemoryFrame(
                            frame_id=frame_index + 1,
                            frame_key=f"{prefix}:{item.sample_index}",
                            file_name=item.file_name,
                            sample_index=item.sample_index,
                            source_frame=item.source_frame,
                            timestamp_sec=item.timestamp_sec,
                            image=None,
                        )
                    )
                    target_hits.append(False)
                    future = executor.submit(execute_single_stream, frame_index, item.image)
                    stage1_pending[future] = frame_index
                    stage1_peak_pending = max(stage1_peak_pending, len(stage1_pending))
                    if len(stage1_pending) >= max_pending:
                        wait_started = time.monotonic()
                        done, _not_done = wait(stage1_pending.keys(), return_when=FIRST_COMPLETED)
                        stage1_wait_ms += int((time.monotonic() - wait_started) * 1000)
                        finish_stage1(done)
                    if len(frames) % 300 == 0:
                        log(
                            "[1.内存模型预加载整段视频全部帧][STREAM_RUNNING] "
                            f"run_id={diagnostic_run_text} video={source_path.name} "
                            f"stage=1 decoded={len(frames)} processed={stage1_processed} "
                            f"pending={len(stage1_pending)} pending_peak={stage1_peak_pending} resident_raw_frames={len(stage1_pending)}"
                        )
                while stage1_pending:
                    wait_started = time.monotonic()
                    done, _not_done = wait(stage1_pending.keys(), return_when=FIRST_COMPLETED)
                    stage1_wait_ms += int((time.monotonic() - wait_started) * 1000)
                    finish_stage1(done)
            stage1_duration_ms = int((time.monotonic() - stage1_started) * 1000)

            if not frames:
                raise RuntimeError(f"没有生成可推理的流式帧：{source.path}")

            target_frame_indices: Optional[List[int]] = None
            target_select_started = time.monotonic()
            hit_count = sum(1 for item in target_hits if item)
            if orchestration_enabled and target_filter_enabled:
                log(f"1#目标判定完成：命中帧={hit_count}/{len(frames)}，连续阈值={int(target_min_consecutive_frames or 1)}。")
                target_frame_indices = _target_interval_indices(
                    frames,
                    target_hits,
                    min_consecutive_frames=int(target_min_consecutive_frames or 1),
                    pre_expand_sec=float(target_pre_expand_sec or 0.0),
                    post_expand_sec=float(target_post_expand_sec or 0.0),
                )
            target_select_ms = int((time.monotonic() - target_select_started) * 1000)

            stage2_processed_indices: Set[int] = set()
            stage2_peak_pending = 0
            stage2_decoded = 0
            stage2_target_frame_count = 0
            stage2_duration_ms = 0
            stage2_wait_ms = 0
            stage2_runtime_sum_ms = 0
            stage2_window_build_ms = 0
            stage2_append_output_ms = 0
            stage2_empty_output_fill_ms = 0
            missing_stage2_count = 0
            stage2_video_io_stats: Dict[str, object] = {}
            # [2#稀疏补推][生产迭代01]
            # 修改人: Shiver; 修改时间: 2026-06-25;
            # 修改逻辑: 统计稀疏扫描、命中补推、全量回退和额外解码成本，统一写入JSONL。
            stage2_sparse_active = False
            stage2_sparse_initial_count = 0
            stage2_sparse_hit_count = 0
            stage2_sparse_refine_count = 0
            stage2_sparse_final_count = 0
            stage2_sparse_saved_count = 0
            stage2_sparse_boundary_dense_count = 0
            stage2_sparse_fallback_full = False
            stage2_sparse_initial_decode_frames = 0
            stage2_sparse_refine_decode_frames = 0
            stage2_sparse_full_decode_frames = 0
            stage2_sparse_model_raw_hit_count = 0
            stage2_sparse_rule3_hit_count = 0
            stage2_sparse_trigger_eval_ms = 0
            stage2_sparse_trigger_fallback_model_raw = False
            stage2_sparse_trigger_error = ""
            if orchestration_enabled:
                process_indices_2 = target_frame_indices if target_filter_enabled else list(range(len(frames)))
                stage2_target_frame_count = len(process_indices_2 or [])
                stage2_started = time.monotonic()
                if process_indices_2:
                    all_indices = list(range(len(frames)))
                    normalized_process_indices_2: List[int] = []
                    seen_stage2_indices: Set[int] = set()
                    for raw_index in process_indices_2:
                        center_index = int(raw_index)
                        if center_index < 0 or center_index >= len(frames):
                            continue
                        if center_index in seen_stage2_indices:
                            continue
                        normalized_process_indices_2.append(center_index)
                        seen_stage2_indices.add(center_index)
                    process_indices_2 = normalized_process_indices_2
                    process_index_set: Set[int] = set(process_indices_2)
                    stage2_video_io_stats_list: List[Dict[str, object]] = []

                    def execute_multi_stream(center_index: int, window_images: List[object]):
                        runtimes = prepared_context.acquire_runtime()
                        try:
                            if len(runtimes) < 2:
                                raise RuntimeError("runtime 组中缺少 2#模型。")
                            runtime_started = time.monotonic()
                            outputs = _execute_multi_image_model_outputs_from_arrays(
                                window_images,
                                min(before, len(window_images) - 1),
                                runtimes[1],
                                before=before,
                                after=after,
                            )
                            runtime_ms = int((time.monotonic() - runtime_started) * 1000)
                            return center_index, outputs, runtime_ms
                        finally:
                            prepared_context.release_runtime(runtimes)

                    def run_stage2_centers(
                        center_indices: List[int],
                        *,
                        phase_text: str,
                        collect_outputs: bool = False,
                    ) -> Tuple[Set[int], int, Dict[int, List[Dict[str, object]]]]:
                        # [2#稀疏补推][生产迭代01]
                        # 修改人: Shiver; 修改时间: 2026-06-25;
                        # 修改逻辑: 抽出2#“给定中心帧集合 -> 顺序解码 -> 固定窗口推理”的通用执行器；
                        # 稀疏扫描、命中补推、全量回退都复用同一套窗口和完整性逻辑。
                        nonlocal stage2_decoded, stage2_wait_ms, stage2_runtime_sum_ms
                        nonlocal stage2_window_build_ms, stage2_append_output_ms, stage2_peak_pending
                        valid_centers: List[int] = []
                        seen_centers: Set[int] = set()
                        for raw_center in center_indices:
                            center_index = int(raw_center)
                            if center_index < 0 or center_index >= len(frames):
                                continue
                            if center_index in stage2_processed_indices:
                                continue
                            if center_index in seen_centers:
                                continue
                            valid_centers.append(center_index)
                            seen_centers.add(center_index)
                        if not valid_centers:
                            return set(), 0, {}

                        window_specs_by_end: Dict[int, List[Tuple[int, List[int]]]] = {}
                        for center_index in valid_centers:
                            window_indices = [
                                int(index)
                                for index in _multi_image_window_items(all_indices, center_index, before=before, after=after)
                            ]
                            window_specs_by_end.setdefault(max(window_indices), []).append((int(center_index), window_indices))
                        last_required_sample_index = max(window_specs_by_end)
                        stage2_pending: Dict[object, int] = {}
                        window_size = max(1, before + 1 + after)
                        frame_window = deque(maxlen=window_size)
                        phase_processed: Set[int] = set()
                        phase_outputs: Dict[int, List[Dict[str, object]]] = {}
                        phase_decoded = 0
                        phase_io_stats = _new_video_io_stats(source_path, f"stage2_stream_infer:{phase_text}")
                        stage2_video_io_stats_list.append(phase_io_stats)

                        def finish_stage2(done_items) -> None:
                            nonlocal stage2_runtime_sum_ms, stage2_append_output_ms
                            for future in done_items:
                                center_index, outputs, runtime_ms = future.result()
                                stage2_pending.pop(future, None)
                                stage2_runtime_sum_ms += int(runtime_ms or 0)
                                append_started = time.monotonic()
                                append_stream_outputs(center_index, outputs)
                                stage2_append_output_ms += int((time.monotonic() - append_started) * 1000)
                                stage2_processed_indices.add(int(center_index))
                                phase_processed.add(int(center_index))
                                if collect_outputs:
                                    phase_outputs[int(center_index)] = outputs
                                if progress:
                                    progress(len(stage2_processed_indices), max(1, len(process_indices_2)), f"流式2#推理-{phase_text} {source_idx}/{total_sources}")

                        with ThreadPoolExecutor(max_workers=worker_count) as executor:
                            second_iter = _iter_video_frames(
                                source_path,
                                prefix=prefix,
                                target_fps=target_fps,
                                start_ms=start_ms,
                                end_ms=end_ms,
                                log=log,
                                io_stats=phase_io_stats,
                            )
                            try:
                                for item in second_iter:
                                    if should_stop and should_stop():
                                        # [1.内存模型预加载整段视频全部帧][通篇审查-中止完整性]
                                        # 修改人: Shiver; 修改时间: 2026-06-23;
                                        # 修改逻辑: 2#阶段同样不允许部分目标窗口形成成功结果。
                                        raise RuntimeError("收到中止请求，终止流式2#模型推理。")
                                    sample_index = int(item.sample_index)
                                    stage2_decoded += 1
                                    phase_decoded += 1
                                    frame_window.append((sample_index, item.image))
                                    specs = window_specs_by_end.get(sample_index, [])
                                    if specs:
                                        for center_index, window_indices in specs:
                                            window_build_started = time.monotonic()
                                            current_images = {index: image for index, image in frame_window}
                                            try:
                                                window_images = [current_images[index] for index in window_indices]
                                            except KeyError as exc:
                                                raise RuntimeError(
                                                    f"2#流式窗口缺帧：phase={phase_text}, center={center_index}, "
                                                    f"window={window_indices}, available={list(current_images)}"
                                                ) from exc
                                            stage2_window_build_ms += int((time.monotonic() - window_build_started) * 1000)
                                            future = executor.submit(execute_multi_stream, center_index, window_images)
                                            stage2_pending[future] = center_index
                                            stage2_peak_pending = max(stage2_peak_pending, len(stage2_pending))
                                            if len(stage2_pending) >= max_pending:
                                                wait_started = time.monotonic()
                                                done, _not_done = wait(stage2_pending.keys(), return_when=FIRST_COMPLETED)
                                                stage2_wait_ms += int((time.monotonic() - wait_started) * 1000)
                                                finish_stage2(done)
                                    if sample_index % 300 == 0 and sample_index > 0:
                                        log(
                                            "[2#稀疏补推][STREAM_RUNNING] "
                                            f"run_id={diagnostic_run_text} video={source_path.name} "
                                            f"phase={phase_text} decoded_total={stage2_decoded} decoded_phase={phase_decoded} "
                                            f"processed={len(stage2_processed_indices)} pending={len(stage2_pending)} "
                                            f"pending_peak={stage2_peak_pending} window_frames={len(frame_window)}"
                                        )
                                    # [1.内存模型预加载整段视频全部帧][通篇审查-2#提前停止]
                                    # 修改人: Shiver; 修改时间: 2026-06-23;
                                    # 修改逻辑: 到达最后一个目标窗口后不再继续解码视频尾部；已提交Future在下方统一等待。
                                    if sample_index >= last_required_sample_index:
                                        break
                            finally:
                                # [1.内存模型预加载整段视频全部帧][通篇审查-解码器释放]
                                # 修改人: Shiver; 修改时间: 2026-06-23;
                                # 修改逻辑: for提前break或异常时立即触发VideoCapture.release，不等待函数局部变量销毁。
                                second_iter_closer = getattr(second_iter, "close", None)
                                if callable(second_iter_closer):
                                    second_iter_closer()
                            while stage2_pending:
                                wait_started = time.monotonic()
                                done, _not_done = wait(stage2_pending.keys(), return_when=FIRST_COMPLETED)
                                stage2_wait_ms += int((time.monotonic() - wait_started) * 1000)
                                finish_stage2(done)
                        return phase_processed, phase_decoded, phase_outputs

                    stage2_required_indices: Set[int] = set(process_indices_2)
                    if bool(stage2_sparse_enabled) and sparse_stride > 1 and process_indices_2:
                        stage2_sparse_active = True
                        boundary_indices: Set[int] = {
                            center_index
                            for position, center_index in enumerate(process_indices_2)
                            if position < sparse_boundary_dense_radius
                            or position >= max(0, len(process_indices_2) - sparse_boundary_dense_radius)
                        }
                        sparse_scan_indices: Set[int] = {
                            center_index
                            for position, center_index in enumerate(process_indices_2)
                            if position % sparse_stride == 0
                        }
                        sparse_initial_indices = sorted(sparse_scan_indices | boundary_indices)
                        stage2_sparse_initial_count = len(sparse_initial_indices)
                        stage2_sparse_boundary_dense_count = len(boundary_indices)
                        log(
                            "[2#稀疏补推][START] "
                            f"run_id={diagnostic_run_text} video={source_path.name} target_frames={len(process_indices_2)} "
                            f"sparse_enabled=true stride={sparse_stride} refine_radius={sparse_refine_radius} "
                            f"boundary_dense={stage2_sparse_boundary_dense_count} initial_probe={stage2_sparse_initial_count} "
                            f"trigger_mode={sparse_trigger_mode} trigger_key={sparse_trigger_output_key or 'any_region'}"
                        )
                        _probe_processed, probe_decoded, probe_outputs = run_stage2_centers(
                            sparse_initial_indices,
                            phase_text="稀疏扫描",
                            collect_outputs=True,
                        )
                        stage2_sparse_initial_decode_frames = probe_decoded
                        model_raw_hit_indices = {
                            center_index
                            for center_index, outputs in probe_outputs.items()
                            if _frame_has_stage2_sparse_trigger_output(outputs, sparse_trigger_output_key)
                        }
                        stage2_sparse_model_raw_hit_count = len(model_raw_hit_indices)
                        sparse_hit_indices = set(model_raw_hit_indices)
                        if sparse_trigger_mode == "rule3_filtered" and model_raw_hit_indices:
                            trigger_eval_started = time.monotonic()
                            try:
                                try:
                                    from infer_cache.code_infer_cache.rule_pipeline import run_rules_memory as _run_rules_memory_for_sparse
                                except ImportError:
                                    from rule_pipeline import run_rules_memory as _run_rules_memory_for_sparse
                                # [2#稀疏补推][生产迭代02-rule3触发]
                                # 修改人: Shiver; 修改时间: 2026-06-25;
                                # 修改逻辑: 构造临时内存推理结果，只包含全量1#输出和稀疏probe阶段已完成的2#输出；
                                # 自动跑 rule1->rule2->area_filter->rule3，按rule3后仍有“漏滴”的probe帧触发补推。
                                sparse_probe_result = MemoryInferenceResult(
                                    source_idx - 1,
                                    str(source_path),
                                    prefix,
                                    {
                                        **metadata,
                                        "stage2_sparse_probe_only": True,
                                        "stage2_sparse_trigger_mode": sparse_trigger_mode,
                                    },
                                    outputs_meta,
                                    frames,
                                    list(output_values),
                                    image_provider=None,
                                )
                                sparse_rule_result = _run_rules_memory_for_sparse(
                                    sparse_probe_result,
                                    rule_names=["cxmt_rule_3_0_arm_region_filter"],
                                    log=lambda text: log(f"[2#稀疏补推][RULE3_TRIGGER] {text}"),
                                    progress=None,
                                    should_stop=should_stop,
                                )
                                rule3_hit_indices = _stage2_sparse_rule3_leak_hit_indices(
                                    sparse_rule_result,
                                    set(sparse_initial_indices),
                                )
                                stage2_sparse_rule3_hit_count = len(rule3_hit_indices)
                                sparse_hit_indices = set(rule3_hit_indices)
                            except Exception as exc:
                                # [2#稀疏补推][生产迭代02-rule3触发-失败保护]
                                # 修改人: Shiver; 修改时间: 2026-06-25;
                                # 修改逻辑: rule3预判异常时不直接跳过补推，回退到model_raw触发，避免预判链路异常引入漏检。
                                stage2_sparse_trigger_fallback_model_raw = True
                                stage2_sparse_trigger_error = str(exc)
                                sparse_hit_indices = set(model_raw_hit_indices)
                                log(
                                    "[2#稀疏补推][RULE3_TRIGGER_FALLBACK] "
                                    f"run_id={diagnostic_run_text} video={source_path.name} "
                                    f"error={stage2_sparse_trigger_error}"
                                )
                            finally:
                                stage2_sparse_trigger_eval_ms = int((time.monotonic() - trigger_eval_started) * 1000)
                        stage2_sparse_hit_count = len(sparse_hit_indices)
                        refine_indices: Set[int] = set()
                        for hit_index in sparse_hit_indices:
                            for refine_index in range(hit_index - sparse_refine_radius, hit_index + sparse_refine_radius + 1):
                                if refine_index in process_index_set:
                                    refine_indices.add(refine_index)
                        remaining_refine_indices = sorted(refine_indices - stage2_processed_indices)
                        stage2_sparse_refine_count = len(remaining_refine_indices)
                        if remaining_refine_indices:
                            _refine_processed, refine_decoded, _refine_outputs = run_stage2_centers(
                                remaining_refine_indices,
                                phase_text="命中补推",
                                collect_outputs=False,
                            )
                            stage2_sparse_refine_decode_frames = refine_decoded
                        hit_rate = (float(stage2_sparse_hit_count) / float(stage2_sparse_initial_count)) if stage2_sparse_initial_count > 0 else 0.0
                        if sparse_fallback_hit_rate > 0 and hit_rate >= sparse_fallback_hit_rate:
                            stage2_sparse_fallback_full = True
                            full_remaining_indices = sorted(process_index_set - stage2_processed_indices)
                            if full_remaining_indices:
                                log(
                                    "[2#稀疏补推][FALLBACK_FULL] "
                                    f"run_id={diagnostic_run_text} video={source_path.name} "
                                    f"hit_rate={hit_rate:.4f} threshold={sparse_fallback_hit_rate:.4f} "
                                    f"remaining_full_frames={len(full_remaining_indices)}"
                                )
                                _full_processed, full_decoded, _full_outputs = run_stage2_centers(
                                    full_remaining_indices,
                                    phase_text="高命中率回退全量",
                                    collect_outputs=False,
                                )
                                stage2_sparse_full_decode_frames = full_decoded
                            stage2_required_indices = set(process_indices_2)
                        else:
                            stage2_required_indices = set(sparse_initial_indices) | refine_indices
                        stage2_sparse_final_count = len(stage2_processed_indices)
                        stage2_sparse_saved_count = max(0, len(process_indices_2) - stage2_sparse_final_count)
                        log(
                            "[2#稀疏补推][END] "
                            f"run_id={diagnostic_run_text} video={source_path.name} target_frames={len(process_indices_2)} "
                            f"initial_probe={stage2_sparse_initial_count} trigger_mode={sparse_trigger_mode} "
                            f"model_raw_hit={stage2_sparse_model_raw_hit_count} rule3_hit={stage2_sparse_rule3_hit_count} hit={stage2_sparse_hit_count} "
                            f"refine={stage2_sparse_refine_count} processed={stage2_sparse_final_count} "
                            f"saved={stage2_sparse_saved_count} fallback_full={stage2_sparse_fallback_full} "
                            f"decode_frames_total={stage2_decoded}"
                        )
                    else:
                        # [1.内存模型预加载整段视频全部帧][生产迭代02-有界流式]
                        # 修改人: Shiver; 修改时间: 2026-06-22;
                        # 修改逻辑: 目标区间确定后重新顺序解码源视频；只保留固定窗口deque，
                        # 每个2# Future持有自己的五帧窗口引用，数量继续受frame_queue_size限制。
                        _full_processed, full_decoded, _full_outputs = run_stage2_centers(
                            process_indices_2,
                            phase_text="全量2#推理",
                            collect_outputs=False,
                        )
                        stage2_sparse_full_decode_frames = full_decoded
                        stage2_required_indices = set(process_indices_2)

                    stage2_video_io_stats = _merge_video_io_stats(
                        stage2_video_io_stats_list,
                        source_path=source_path,
                        phase="stage2_stream_infer",
                    )
                    # [1.内存模型预加载整段视频全部帧][通篇审查-2#完整性]
                    # 修改人: Shiver; 修改时间: 2026-06-23;
                    # 修改逻辑: 二次解码异常少帧时禁止把应推理帧静默写成空输出，直接失败便于告警和复盘。
                    missing_stage2_indices = sorted(stage2_required_indices - stage2_processed_indices)
                    missing_stage2_count = len(missing_stage2_indices)
                    if missing_stage2_indices:
                        preview = missing_stage2_indices[:20]
                        raise RuntimeError(
                            "2#流式推理未覆盖全部目标帧："
                            f"missing_count={len(missing_stage2_indices)}, missing_preview={preview}"
                        )
                else:
                    log("未找到满足连续帧阈值的目标区间，跳过 2#多图模型推理。")

                runtime_group = prepared_context.acquire_runtime()
                try:
                    empty_outputs = _empty_outputs_for_specs(runtime_group[1].output_specs)
                finally:
                    prepared_context.release_runtime(runtime_group)
                empty_fill_started = time.monotonic()
                for frame_index in range(len(frames)):
                    if frame_index not in stage2_processed_indices:
                        append_stream_outputs(frame_index, empty_outputs)
                stage2_empty_output_fill_ms = int((time.monotonic() - empty_fill_started) * 1000)
                stage2_duration_ms = int((time.monotonic() - stage2_started) * 1000)

            provider = BoundedVideoFrameProvider(
                source_path,
                prefix=prefix,
                target_fps=target_fps,
                start_ms=start_ms,
                end_ms=end_ms,
                cache_size=max(1, int(provider_cache_size or 1)),
                log=log,
            )
            infer_elapsed_ms = int((time.monotonic() - video_started_monotonic) * 1000)
            metadata["storage"] = "memory+bounded_video_stream+aidi_property_binary_base64"
            metadata["bounded_streaming"] = {
                "enabled": True,
                "queue_limit": max_pending,
                "stage1_peak_pending": stage1_peak_pending,
                "stage2_peak_pending": stage2_peak_pending,
                "provider_cache_limit": max(1, int(provider_cache_size or 1)),
                "resident_raw_frames": 0,
                "stage2_decode_frames": stage2_decoded,
                # [视频处理耗时复盘JSONL][第一版]
                # 修改人: Shiver; 修改时间: 2026-06-24;
                # 修改逻辑: 输出1#/target/2#阶段的结构化工作量和细分耗时，供JSONL复盘分析。
                "stage1_frame_count": len(frames),
                "stage1_processed_frame_count": stage1_processed,
                "stage1_hit_count": hit_count,
                "stage2_target_frame_count": stage2_target_frame_count,
                "stage2_processed_frame_count": len(stage2_processed_indices),
                "stage2_skipped_frame_count": max(0, len(frames) - len(stage2_processed_indices)),
                "stage2_missing_count": missing_stage2_count,
                # [2#稀疏补推][生产迭代01]
                # 修改人: Shiver; 修改时间: 2026-06-25;
                # 修改逻辑: 输出2#稀疏扫描/命中补推计数，支持现场A/C对比推理量和耗时。
                "stage2_sparse_enabled": bool(stage2_sparse_active),
                "stage2_sparse_stride": sparse_stride,
                "stage2_sparse_refine_radius": sparse_refine_radius,
                "stage2_sparse_boundary_dense_radius": sparse_boundary_dense_radius,
                "stage2_sparse_trigger_output_key": sparse_trigger_output_key,
                "stage2_sparse_trigger_mode": sparse_trigger_mode,
                "stage2_sparse_fallback_hit_rate": sparse_fallback_hit_rate,
                "stage2_sparse_initial_count": stage2_sparse_initial_count,
                "stage2_sparse_model_raw_hit_count": stage2_sparse_model_raw_hit_count,
                "stage2_sparse_rule3_hit_count": stage2_sparse_rule3_hit_count,
                "stage2_sparse_hit_count": stage2_sparse_hit_count,
                "stage2_sparse_refine_count": stage2_sparse_refine_count,
                "stage2_sparse_final_count": stage2_sparse_final_count if stage2_sparse_active else len(stage2_processed_indices),
                "stage2_sparse_saved_count": stage2_sparse_saved_count if stage2_sparse_active else 0,
                "stage2_sparse_boundary_dense_count": stage2_sparse_boundary_dense_count,
                "stage2_sparse_fallback_full": bool(stage2_sparse_fallback_full),
                "stage2_sparse_trigger_eval_ms": stage2_sparse_trigger_eval_ms,
                "stage2_sparse_trigger_fallback_model_raw": bool(stage2_sparse_trigger_fallback_model_raw),
                "stage2_sparse_trigger_error": stage2_sparse_trigger_error,
            }
            metadata["trace_stage_timings_ms"] = {
                "video_prepare_ms": video_prepare_ms,
                "stage1_stream_infer_ms": stage1_duration_ms,
                "target_select_ms": target_select_ms,
                "stage2_stream_infer_ms": stage2_duration_ms,
            }
            metadata["trace_stage_timing_detail_ms"] = {
                "stage1_stream_infer": {
                    "wait_ms": stage1_wait_ms,
                    "runtime_sum_ms": stage1_runtime_sum_ms,
                    "append_output_ms": stage1_append_output_ms,
                    "decode_submit_ms": max(0, stage1_duration_ms - stage1_wait_ms),
                    **_video_io_trace_detail(stage1_video_io_stats),
                },
                "stage2_stream_infer": {
                    "wait_ms": stage2_wait_ms,
                    "runtime_sum_ms": stage2_runtime_sum_ms,
                    "window_build_ms": stage2_window_build_ms,
                    "append_output_ms": stage2_append_output_ms,
                    "empty_output_fill_ms": stage2_empty_output_fill_ms,
                    "decode_submit_ms": max(0, stage2_duration_ms - stage2_wait_ms),
                    # [2#稀疏补推][生产迭代01]
                    # 修改人: Shiver; 修改时间: 2026-06-25;
                    # 修改逻辑: 记录稀疏扫描/补推/全量回退各自解码帧数，便于区分“少推理”和“多解码”的权衡。
                    "stage2_sparse_initial_decode_frames": stage2_sparse_initial_decode_frames,
                    "stage2_sparse_refine_decode_frames": stage2_sparse_refine_decode_frames,
                    "stage2_sparse_full_decode_frames": stage2_sparse_full_decode_frames,
                    "stage2_sparse_trigger_eval_ms": stage2_sparse_trigger_eval_ms,
                    **_video_io_trace_detail(stage2_video_io_stats),
                },
            }
            metadata["video_timing"] = {"started_at": video_started_at, "infer_elapsed_ms": infer_elapsed_ms}
            log(
                "[1.内存模型预加载整段视频全部帧][STREAM_END] "
                f"run_id={diagnostic_run_text} video={source_path.name} "
                f"total_frames={len(frames)} stage1_peak_pending={stage1_peak_pending} "
                f"stage2_peak_pending={stage2_peak_pending} provider_cache_limit={provider.cache_size} "
                f"resident_raw_frames=0 infer_elapsed_ms={infer_elapsed_ms}"
            )
            return MemoryInferenceResult(
                source_idx - 1,
                str(source_path),
                prefix,
                metadata,
                outputs_meta,
                frames,
                output_values,
                image_provider=provider,
            )
        frame_items = list(frame_iter)
        if not frame_items:
            raise RuntimeError(f"没有生成可推理的内存帧：{source.path}")
        frames = [
            MemoryFrame(
                frame_id=index + 1,
                frame_key=f"{prefix}:{item.sample_index}",
                file_name=item.file_name,
                sample_index=item.sample_index,
                source_frame=item.source_frame,
                timestamp_sec=item.timestamp_sec,
                image=item.image,
            )
            for index, item in enumerate(frame_items)
        ]
        frame_images = [frame.image for frame in frames]
        output_values: List[object] = []
        worker_count = max(1, int(infer_workers or 1))
        max_pending = max(1, int(frame_queue_size or worker_count * 2))

        def append_outputs(frame_index: int, outputs: List[Dict[str, object]]) -> None:
            frame_id = frame_index + 1
            for output in outputs:
                output_values.append(
                    MemoryOutputValue(
                        frame_id=frame_id,
                        output_index=int(output["index"]),
                        output_key=str(output["key"]),
                        property_type=str(output["property_type"]),
                        binary_b64=str(output["binary_b64"]),
                        error=str(output["error"]),
                    )
                )

        def run_stage(model_number: int, input_mode: str, indices: Optional[List[int]] = None, target_key: str = "") -> object:
            process_indices = list(indices) if indices is not None else list(range(len(frame_images)))
            target_hits = [False] * len(frame_images)
            processed = 0
            log(f"{model_number}#模型内存推理执行：待推理帧数={len(process_indices)}/{len(frame_images)}，输入={input_mode}。")

            def execute_one(frame_index: int):
                runtimes = prepared_context.acquire_runtime()
                try:
                    if len(runtimes) <= model_number - 1:
                        raise RuntimeError(f"runtime 组中缺少 {model_number}#模型。")
                    runtime_info = runtimes[model_number - 1]
                    if input_mode == "single":
                        outputs = _execute_single_image_model_outputs_from_array(frame_images[frame_index], runtime_info)
                    else:
                        outputs = _execute_multi_image_model_outputs_from_arrays(
                            frame_images,
                            frame_index,
                            runtime_info,
                            before=before,
                            after=after,
                        )
                    return frame_index, outputs
                finally:
                    prepared_context.release_runtime(runtimes)

            pending: Dict[object, int] = {}
            nonlocal_output_lock = threading.Lock()
            with ThreadPoolExecutor(max_workers=worker_count) as executor:
                def finish_completed(done_items) -> None:
                    nonlocal processed
                    for future in done_items:
                        frame_index, outputs = future.result()
                        pending.pop(future, None)
                        with nonlocal_output_lock:
                            append_outputs(frame_index, outputs)
                        if target_key:
                            target_hits[frame_index] = _frame_has_target_output(outputs, target_key)
                        processed += 1
                        if progress:
                            progress(processed, max(1, len(process_indices)), f"内存推理 {source_idx}/{total_sources}")

                for frame_index in process_indices:
                    if should_stop and should_stop():
                        log(f"收到中止请求，停止 {model_number}#模型推理。")
                        break
                    future = executor.submit(execute_one, frame_index)
                    pending[future] = frame_index
                    if len(pending) >= max_pending:
                        done, _not_done = wait(pending.keys(), return_when=FIRST_COMPLETED)
                        finish_completed(done)
                while pending:
                    done, _not_done = wait(pending.keys(), return_when=FIRST_COMPLETED)
                    finish_completed(done)
            return target_hits if target_key else processed

        if orchestration_enabled:
            target_hits = run_stage(1, "single", target_key=str(target_output_key or "") if target_filter_enabled else "")
            target_frame_indices = None
            if target_filter_enabled:
                hits = list(target_hits) if isinstance(target_hits, list) else []
                hit_count = sum(1 for item in hits if item)
                log(f"1#目标判定完成：命中帧={hit_count}/{len(frame_items)}，连续阈值={int(target_min_consecutive_frames or 1)}。")
                target_frame_indices = _target_interval_indices(
                    frame_items,
                    hits,
                    min_consecutive_frames=int(target_min_consecutive_frames or 1),
                    pre_expand_sec=float(target_pre_expand_sec or 0.0),
                    post_expand_sec=float(target_post_expand_sec or 0.0),
                )
                if not target_frame_indices:
                    log("未找到满足连续帧阈值的目标区间，跳过 2#多图模型推理。")
                    runtime_group = prepared_context.acquire_runtime()
                    try:
                        empty_outputs = _empty_outputs_for_specs(runtime_group[1].output_specs)
                    finally:
                        prepared_context.release_runtime(runtime_group)
                    for idx in range(len(frame_items)):
                        append_outputs(idx, empty_outputs)
                    infer_elapsed_ms = int((time.monotonic() - video_started_monotonic) * 1000)
                    metadata["video_timing"] = {
                        "started_at": video_started_at,
                        "infer_elapsed_ms": infer_elapsed_ms,
                    }
                    log(f"[{source_idx}/{total_sources}] 视频推理阶段完成：{source_path.name}，infer_elapsed_ms={infer_elapsed_ms}")
                    log(f"内存推理完成：memory://video_{source_idx - 1}/infer")
                    return MemoryInferenceResult(source_idx - 1, str(source_path), prefix, metadata, outputs_meta, frames, output_values)
            process_indices_2 = target_frame_indices if target_frame_indices is not None else list(range(len(frame_items)))
            processed_2 = run_stage(2, "multi", indices=process_indices_2)
            processed_2_count = int(processed_2) if not isinstance(processed_2, list) else len(process_indices_2)
            processed_2_set = set(process_indices_2[: max(0, min(processed_2_count, len(process_indices_2)))])
            skipped_indices = [idx for idx in range(len(frame_items)) if target_filter_enabled and target_frame_indices is not None and idx not in processed_2_set]
            if skipped_indices:
                runtime_group = prepared_context.acquire_runtime()
                try:
                    empty_outputs = _empty_outputs_for_specs(runtime_group[1].output_specs)
                finally:
                    prepared_context.release_runtime(runtime_group)
                for idx in skipped_indices:
                    append_outputs(idx, empty_outputs)
        else:
            run_stage(1, "single")
        infer_elapsed_ms = int((time.monotonic() - video_started_monotonic) * 1000)
        metadata["video_timing"] = {
            "started_at": video_started_at,
            "infer_elapsed_ms": infer_elapsed_ms,
        }
        log(f"[{source_idx}/{total_sources}] 视频推理阶段完成：{source_path.name}，infer_elapsed_ms={infer_elapsed_ms}")
        log(f"内存推理完成：memory://video_{source_idx - 1}/infer")
        return MemoryInferenceResult(source_idx - 1, str(source_path), prefix, metadata, outputs_meta, frames, output_values)

    video_worker_count = max(1, min(int(video_workers or 1), total_sources))
    if video_worker_count <= 1:
        return [process_source(idx, source) for idx, source in enumerate(sources, 1)]
    written: Dict[int, MemoryInferenceResult] = {}
    with ThreadPoolExecutor(max_workers=video_worker_count) as executor:
        future_map = {executor.submit(process_source, idx, source): idx for idx, source in enumerate(sources, 1)}
        for future in as_completed(future_map):
            source_idx = future_map[future]
            written[source_idx] = future.result()
    return [written[idx] for idx in sorted(written)]


def run_inference_cache_prepared(
    *,
    sources: List[MediaSource],
    prepared_context: PreparedInferenceContext,
    output_root: Path,
    target_fps: float,
    start_ms: float,
    end_ms: Optional[float],
    save_frames: bool,
    infer_workers: int = 1,
    frame_queue_size: int = 4,
    video_workers: int = 1,
    orchestration_enabled: bool = False,
    require_two_models: bool = True,
    target_filter_enabled: bool = False,
    target_output_key: str = "",
    target_min_consecutive_frames: int = 3,
    target_pre_expand_sec: float = 0.0,
    target_post_expand_sec: float = 0.0,
    multi_image_before_frames: int = 2,
    multi_image_after_frames: int = 2,
    save_multi_image_windows: bool = False,
    log: Callable[[str], None] = print,
    progress: Optional[Callable[[int, int, str], None]] = None,
    should_stop: Optional[Callable[[], bool]] = None,
) -> List[Path]:
    """Run inference using a preloaded VisionFlow runtime pool."""
    _require_runtime_deps()
    if not sources:
        raise RuntimeError("没有找到可处理的视频或图片。")
    if orchestration_enabled:
        return _run_inference_cache_prepared_orchestrated(
            sources=sources,
            prepared_context=prepared_context,
            output_root=output_root,
            target_fps=target_fps,
            start_ms=start_ms,
            end_ms=end_ms,
            save_frames=save_frames,
            infer_workers=infer_workers,
            frame_queue_size=frame_queue_size,
            video_workers=video_workers,
            target_filter_enabled=target_filter_enabled,
            target_output_key=target_output_key,
            target_min_consecutive_frames=target_min_consecutive_frames,
            target_pre_expand_sec=target_pre_expand_sec,
            target_post_expand_sec=target_post_expand_sec,
            multi_image_before_frames=multi_image_before_frames,
            multi_image_after_frames=multi_image_after_frames,
            save_multi_image_windows=save_multi_image_windows,
            require_two_models=require_two_models,
            log=log,
            progress=progress,
            should_stop=should_stop,
        )
    output_root.mkdir(parents=True, exist_ok=True)
    selected_model_paths = prepared_context.model_paths
    model_path = selected_model_paths[0]
    output_specs = prepared_context.output_specs
    worker_count = max(1, int(infer_workers or 1))
    max_pending = max(1, int(frame_queue_size or worker_count * 2))
    total_sources = len(sources)
    used_prefixes: Dict[str, int] = {}
    prefix_lock = threading.Lock()

    def unique_prefix(source: MediaSource) -> str:
        base_prefix = sanitize_name(source.output_name or source.path.stem)
        with prefix_lock:
            count = used_prefixes.get(base_prefix, 0)
            used_prefixes[base_prefix] = count + 1
        if count:
            digest_seed = f"{source.output_name or ''}/{source.path}"
            digest = hashlib.sha1(digest_seed.encode("utf-8")).hexdigest()[:8]
            return f"{base_prefix}_{digest}"
        return base_prefix

    def infer_one_frame(frame_image):
        runtimes = prepared_context.acquire_runtime()
        try:
            return _execute_frame_outputs(frame_image, runtimes)
        finally:
            prepared_context.release_runtime(runtimes)

    def process_source(source_idx: int, source: MediaSource) -> Path:
        if should_stop and should_stop():
            raise RuntimeError("收到中止请求。")
        source_path = source.path
        video_started_monotonic = time.monotonic()
        video_started_at = time.strftime("%Y-%m-%d %H:%M:%S")
        log(f"[{source_idx}/{total_sources}] 视频开始处理：{source_path.name}，start_at={video_started_at}")
        prefix = unique_prefix(source)
        run_root = output_root / prefix
        frames_dir = run_root / "frames"
        db_path = run_root / f"{prefix}_infer_cache.sqlite"
        _clear_inference_output(run_root, log=log)
        run_root.mkdir(parents=True, exist_ok=True)
        processing_info = _source_processing_info(
            source,
            requested_target_fps=target_fps,
            start_ms=start_ms,
            end_ms=end_ms,
            log=log,
        )
        _write_processing_info(run_root, processing_info)
        conn = _connect_cache(db_path)
        _init_cache_db(
            conn,
            model_path=model_path,
            model_paths=selected_model_paths,
            input_path=source_path,
            output_specs=output_specs,
            target_fps=target_fps,
            start_ms=start_ms,
            end_ms=end_ms,
            save_frames=save_frames,
            processing_info=processing_info,
        )
        log(f"[{source_idx}/{total_sources}] 开始推理 {source.media_type}：{source_path.name}")
        log(
            "处理信息："
            f"源 FPS={float(processing_info.get('src_fps') or 0):.3f}，"
            f"实际拆帧 FPS={float(processing_info.get('actual_sample_fps') or 1):.3f}，"
            f"预计帧数={int(processing_info.get('expected_frames') or 1)}"
        )

        def write_frame_result(frame_item: FrameItem, image_path: str, outputs: List[Dict[str, object]]) -> None:
            cur = conn.execute(
                """
                INSERT INTO frames(frame_key, file_name, sample_index, source_frame, timestamp_sec, image_path)
                VALUES(?, ?, ?, ?, ?, ?)
                """,
                (
                    f"{prefix}:{frame_item.sample_index}",
                    frame_item.file_name,
                    frame_item.sample_index,
                    frame_item.source_frame,
                    frame_item.timestamp_sec,
                    image_path,
                ),
            )
            frame_db_id = int(cur.lastrowid)
            conn.executemany(
                """
                INSERT INTO output_values(
                    frame_id, output_index, output_key, property_type, binary_b64, error
                ) VALUES(?, ?, ?, ?, ?, ?)
                """,
                [
                    (
                        frame_db_id,
                        int(output["index"]),
                        str(output["key"]),
                        str(output["property_type"]),
                        str(output["binary_b64"]),
                        str(output["error"]),
                    )
                    for output in outputs
                ],
            )

        try:
            if source.media_type == "video":
                frame_iter = _iter_video_frames(
                    source_path,
                    prefix=prefix,
                    target_fps=target_fps,
                    start_ms=start_ms,
                    end_ms=end_ms,
                    log=log,
                )
            else:
                frame_iter = _iter_image_frames(source_path, prefix=prefix)
            processed_count = 0
            pending: Dict[object, Tuple[FrameItem, str]] = {}
            with ThreadPoolExecutor(max_workers=worker_count) as executor:
                def finish_completed(done_items) -> None:
                    nonlocal processed_count
                    for future in done_items:
                        frame_item, image_path = pending.pop(future)
                        outputs = future.result()
                        write_frame_result(frame_item, image_path, outputs)
                        processed_count += 1
                        if processed_count % 20 == 0:
                            conn.commit()
                        if progress:
                            progress(processed_count, frame_item.expected_count, f"推理 {source_idx}/{total_sources}")
                        if processed_count % 50 == 0:
                            log(f"已推理 {processed_count} 帧...")

                for frame_item in frame_iter:
                    if should_stop and should_stop():
                        log("收到中止请求，停止提交新的推理帧。")
                        break
                    image_path = ""
                    if save_frames:
                        out_img = frames_dir / frame_item.file_name
                        if _imwrite_unicode(out_img, frame_item.image):
                            image_path = str(out_img)
                    future = executor.submit(infer_one_frame, frame_item.image)
                    pending[future] = (frame_item, image_path)
                    if len(pending) >= max_pending:
                        done, _not_done = wait(pending.keys(), return_when=FIRST_COMPLETED)
                        finish_completed(done)
                while pending:
                    done, _not_done = wait(pending.keys(), return_when=FIRST_COMPLETED)
                    finish_completed(done)
            conn.commit()
        finally:
            conn.close()
        infer_elapsed_ms = int((time.monotonic() - video_started_monotonic) * 1000)
        log(f"[{source_idx}/{total_sources}] 视频推理阶段完成：{source_path.name}，infer_elapsed_ms={infer_elapsed_ms}")
        log(f"推理缓存 DB：{db_path}")
        return db_path

    video_worker_count = max(1, min(int(video_workers or 1), total_sources))
    if video_worker_count <= 1:
        return [process_source(idx, source) for idx, source in enumerate(sources, 1)]
    written: List[Path] = []
    with ThreadPoolExecutor(max_workers=video_worker_count) as executor:
        future_map = {executor.submit(process_source, idx, source): idx for idx, source in enumerate(sources, 1)}
        for future in as_completed(future_map):
            written.append(future.result())
    return written


def _read_metadata(conn: sqlite3.Connection) -> Dict[str, object]:
    meta: Dict[str, object] = {}
    for key, value in conn.execute("SELECT key, value FROM metadata"):
        try:
            meta[str(key)] = json.loads(value)
        except Exception:
            meta[str(key)] = value
    return meta


def load_cache(db_path: Path, *, load_outputs: bool = False) -> Dict[str, object]:
    """读取推理 DB 或规则 DB。

    `load_outputs=False` 只读取元数据、输出节点和帧表，速度较快；
    `load_outputs=True` 会额外读取每帧每个输出节点的二进制属性，用于规则
    运算或重新渲染。
    """
    if not db_path.exists():
        raise RuntimeError(f"缓存 DB 不存在：{db_path}")
    conn = sqlite3.connect(str(db_path))
    try:
        meta = _read_metadata(conn)
        outputs = []
        for row in conn.execute(
            """
            SELECT output_index, tool_id, node_id, output_key, column_name, edge_type, labels_json
            FROM outputs ORDER BY output_index
            """
        ):
            outputs.append(
                {
                    "index": int(row[0]),
                    "tool_id": row[1],
                    "node_id": row[2],
                    "key": row[3],
                    "column": row[4],
                    "edge_type": row[5],
                    "labels": json.loads(row[6] or "[]"),
                }
            )

        rows = []
        for row in conn.execute(
            """
            SELECT frame_id, frame_key, file_name, sample_index, source_frame, timestamp_sec, image_path
            FROM frames ORDER BY sample_index
            """
        ):
            item = {
                "frame_id": int(row[0]),
                "frame_key": row[1],
                "file_name": row[2],
                "sample_index": int(row[3]),
                "source_frame": int(row[4]),
                "timestamp_sec": float(row[5]),
                "image_path": row[6],
            }
            if load_outputs:
                item["outputs"] = [
                    {
                        "output_index": int(out[0]),
                        "output_key": out[1],
                        "property_type": out[2],
                        "binary_b64": out[3],
                        "error": out[4],
                    }
                    for out in conn.execute(
                        """
                        SELECT output_index, output_key, property_type, binary_b64, error
                        FROM output_values WHERE frame_id = ? ORDER BY output_index
                        """,
                        (item["frame_id"],),
                    )
                ]
            rows.append(item)
        return {
            "db_path": str(db_path),
            "meta": meta,
            "outputs": outputs,
            "rows": rows,
        }
    finally:
        conn.close()


def _normalize_regions(prop) -> List[object]:
    if prop is None:
        return []
    try:
        return [x for _, x in prop]
    except Exception:
        try:
            return list(prop)
        except Exception:
            return []


def _region_points(region) -> Optional[object]:
    _require_runtime_deps()
    try:
        ring = region.polygon().outer
        points = [[int(round(p.x)), int(round(p.y))] for p in ring]
        if len(points) >= 2:
            return np.array(points, dtype=np.int32)
    except Exception:
        return None
    return None


def _region_label(region) -> str:
    try:
        return str(region.name())
    except Exception:
        return ""


def _draw_property_on_image(
    img,
    prop,
    output_name: str,
    color,
    *,
    draw_labels: bool = False,
    allowed_labels: Optional[Set[str]] = None,
):
    _require_runtime_deps()
    drawn = 0
    regions = _normalize_regions(prop)
    for region in regions:
        label = _region_label(region)
        if allowed_labels is not None and label not in allowed_labels:
            continue
        pts = _region_points(region)
        if pts is None:
            continue
        cv2.polylines(img, [pts], True, color, 2)
        if draw_labels:
            try:
                score = float(region.score())
                text = f"{label}" if label else output_name
            except Exception:
                text = label or output_name
            x = int(pts[:, 0].min())
            y = max(0, int(pts[:, 1].min()) - 18)
            img = draw_text(img, text, (x, y), font_px=16, color_bgr=color)
        drawn += 1
    return img, drawn


def _draw_render_summary(img, summary: List[str], start_y: int = 8) -> object:
    _require_runtime_deps()
    if not summary:
        return img
    max_items = 12
    lines = summary[:max_items]
    if len(summary) > max_items:
        lines.append(f"... {len(summary) - max_items} more outputs")
    y = max(8, start_y)
    for line in lines:
        img = draw_text(img, line, (8, y), font_px=18, color_bgr=(0, 255, 255))
        y += 24
    return img


def _draw_message_on_image(img, prop, output_name: str, y: int):
    _require_runtime_deps()
    if prop is None or not hasattr(prop, "get"):
        return img, y
    try:
        value = str(prop.get())
    except Exception:
        value = ""
    if not value:
        return img, y
    text = f"{output_name}: {value}"
    img = draw_text(img, text, (8, y), font_px=18, color_bgr=(0, 255, 255))
    return img, y + 24


def _images_to_video(
    image_paths: List[Path],
    output_path: Path,
    fps: float,
    *,
    log: Callable[[str], None] = print,
    progress: Optional[Callable[[int, int, str], None]] = None,
    should_stop: Optional[Callable[[], bool]] = None,
) -> Path:
    _require_runtime_deps()
    if not image_paths:
        raise RuntimeError("没有可用于合成视频的渲染图。")
    first = _imread_unicode(image_paths[0])
    if first is None:
        raise RuntimeError(f"读取首帧渲染图失败：{image_paths[0]}")
    h, w = first.shape[:2]
    if w <= 0 or h <= 0:
        raise RuntimeError("渲染图尺寸无效，无法合成视频。")
    output_path.parent.mkdir(parents=True, exist_ok=True)
    writer = cv2.VideoWriter(
        str(output_path),
        cv2.VideoWriter_fourcc(*"mp4v"),
        max(0.1, float(fps or 1.0)),
        (w, h),
    )
    if not writer.isOpened():
        raise RuntimeError(
            f"无法创建视频文件：{output_path}。当前渲染图尺寸为 {w}x{h}，"
            "可能超过当前 MPEG-4 编码器支持范围；请降低输入/渲染图分辨率后再合成视频。"
        )
    written = 0
    try:
        for idx, image_path in enumerate(image_paths, 1):
            if should_stop and should_stop():
                log("收到中止请求，停止视频合成。")
                break
            if progress:
                progress(idx - 1, len(image_paths), "合成视频")
            img = first if idx == 1 else _imread_unicode(image_path)
            if img is None:
                log(f"跳过无法读取的渲染图：{image_path}")
                continue
            if img.shape[1] != w or img.shape[0] != h:
                img = cv2.resize(img, (w, h), interpolation=cv2.INTER_AREA)
            writer.write(img)
            written += 1
            if progress:
                progress(idx, len(image_paths), "合成视频")
    finally:
        writer.release()
    if written <= 0:
        raise RuntimeError("没有成功写入任何视频帧。")
    log(f"渲染视频合成完成：{output_path}（{written} 帧，{float(fps or 1.0):.2f} FPS）")
    return output_path


def _is_renderable_region_type(edge_type: str) -> bool:
    return "RegionList" in str(edge_type)


def _resolve_frame_image_path(row: Dict[str, object], db_path: Path) -> Path:
    image_text = str(row.get("image_path") or "").strip()
    if image_text:
        image_path = Path(image_text)
        if image_path.exists() and image_path.is_file():
            return image_path
    candidate = db_path.parent / "frames" / str(row.get("file_name", ""))
    if candidate.exists() and candidate.is_file():
        return candidate
    raise RuntimeError(
        "找不到 DB 对应的原始拆帧图像。请确认推理时已勾选“保存拆帧原始图像”，"
        f"缺失帧：{row.get('file_name', '')}"
    )


def discover_cache_dbs(root: Path, *, db_kind: str = "infer") -> List[Path]:
    """Find typed cache databases under a root directory that have sibling frames.

    db_kind:
    - "infer": only `*_infer_cache.sqlite`
    - "rule": only `*_infer_cache_rules.sqlite`
    - "any": both known cache DB names
    """
    kind = str(db_kind or "infer").lower()
    if kind not in {"infer", "rule", "any"}:
        raise ValueError(f"不支持的 DB 类型：{db_kind}")

    def matches(path: Path) -> bool:
        if kind == "infer":
            return is_inference_cache_db(path)
        if kind == "rule":
            return is_rule_cache_db(path)
        return is_inference_cache_db(path) or is_rule_cache_db(path)

    if root.is_file():
        return [root] if matches(root) else []
    if not root.is_dir():
        return []
    candidates = sorted(
        p for p in root.rglob("*")
        if p.is_file() and matches(p)
    )
    result = []
    seen = set()
    for db_path in candidates:
        key = str(db_path.resolve()).lower()
        if key in seen:
            continue
        seen.add(key)
        if (db_path.parent / "frames").is_dir():
            result.append(db_path)
    return result


def _read_processing_info_for_cache(db_path: Path, data: Dict[str, object]) -> Dict[str, object]:
    metadata = data.get("meta", {})
    if not isinstance(metadata, dict):
        metadata = data.get("metadata", {})
    if not isinstance(metadata, dict):
        metadata = {}
    info = metadata.get("processing_info")
    if isinstance(info, dict) and info:
        return info
    sidecar = db_path.parent / "processing_info.json"
    if sidecar.exists():
        try:
            loaded = json.loads(sidecar.read_text(encoding="utf-8"))
            if isinstance(loaded, dict):
                return loaded
        except Exception:
            return {}
    return {}


def _fallback_sample_fps(data: Dict[str, object]) -> float:
    rows = data.get("rows", [])
    if isinstance(rows, list) and len(rows) >= 2:
        times = []
        for row in rows[:10]:
            try:
                times.append(float(row.get("timestamp_sec", 0.0)))
            except Exception:
                pass
        diffs = [b - a for a, b in zip(times, times[1:]) if b > a]
        if diffs:
            return max(0.1, 1.0 / (sum(diffs) / len(diffs)))
    metadata = data.get("meta", {})
    if not isinstance(metadata, dict):
        metadata = data.get("metadata", {})
    if not isinstance(metadata, dict):
        metadata = {}
    try:
        return max(0.1, float(metadata.get("target_fps") or 1.0))
    except Exception:
        return 1.0


def _compose_video_fps(db_path: Path, data: Dict[str, object], log: Callable[[str], None]) -> float:
    info = _read_processing_info_for_cache(db_path, data)
    try:
        fps = float(info.get("actual_sample_fps") or 0.0)
    except Exception:
        fps = 0.0
    if fps > 0:
        log(f"视频合成 FPS：{fps:.3f}（来自 processing_info）")
        return fps
    fps = _fallback_sample_fps(data)
    log(f"视频合成 FPS：{fps:.3f}（旧 DB 兜底推导）")
    return fps


def render_cache_images(
    db_path: Path,
    *,
    output_dir: Optional[Path] = None,
    draw_region_labels: bool = False,
    render_filter: Optional[Dict[str, Optional[Iterable[str]]]] = None,
    compose_video: bool = False,
    parallel_render: bool = False,
    max_workers: int = 1,
    log: Callable[[str], None] = print,
    progress: Optional[Callable[[int, int, str], None]] = None,
    should_stop: Optional[Callable[[], bool]] = None,
) -> Path:
    """把缓存 DB 中的 VisionFlow 输出重新渲染到原始拆帧图上。

    `render_filter` 控制哪些输出节点/标签参与渲染。规则 UI 中的
    “是否渲染”最终会转换成这个参数；规则是否执行不由这里决定。
    """
    _require_runtime_deps()
    data = load_cache(db_path, load_outputs=True)
    rows = data.get("rows", [])
    outputs = data.get("outputs", [])
    if not rows:
        raise RuntimeError("DB 中没有帧记录，无法渲染。")
    if not outputs:
        raise RuntimeError("DB 中没有输出节点记录，无法渲染。")

    for row in rows:
        _resolve_frame_image_path(row, db_path)

    out_dir = output_dir or _default_render_dir(db_path)
    _clear_render_outputs(db_path, out_dir, clear_video=compose_video, log=log)
    out_dir.mkdir(parents=True, exist_ok=True)
    output_by_index = {int(item["index"]): item for item in outputs}
    normalized_filter: Optional[Dict[str, Optional[Set[str]]]] = None
    if render_filter is not None:
        normalized_filter = {}
        for output_key, labels in render_filter.items():
            if labels is None:
                normalized_filter[str(output_key)] = None
            else:
                label_set = {str(item) for item in labels}
                normalized_filter[str(output_key)] = label_set or None
    colors = RENDER_COLORS_BGR
    rendered_paths_by_index: Dict[int, Path] = {}
    render_span = 800 if compose_video else 1000

    def emit_progress(cur: int, total: int, label: str, *, base: int = 0, span: int = 1000) -> None:
        if not progress:
            return
        if total <= 0:
            progress(base, 1000, label)
            return
        value = base + int(span * max(0, min(cur, total)) / total)
        progress(max(0, min(1000, value)), 1000, label)

    emit_progress(0, 1, "准备渲染", span=render_span)

    def render_one_frame(idx: int, row: Dict[str, object]):
        verbose_frame = len(rows) <= 5 or idx == 1 or idx % 50 == 0
        frame_logs: List[str] = []
        # if verbose_frame:
        #     frame_logs.append(f"开始渲染 {idx}/{len(rows)} 帧...")
        img_path = _resolve_frame_image_path(row, db_path)
        # if verbose_frame:
            # frame_logs.append(f"读取原始图像：{img_path.name}")
        img = _imread_unicode(img_path)
        if img is None:
            raise RuntimeError(f"读取原始拆帧图像失败：{img_path}")
        message_y = 8
        total_drawn = 0
        for value in row.get("outputs", []):
            output_index = int(value.get("output_index", -1))
            meta = output_by_index.get(output_index)
            if not meta:
                continue
            if value.get("error"):
                frame_logs.append(f"跳过有错误的输出：{value.get('output_key')}，{value.get('error')}")
                continue
            binary_b64 = str(value.get("binary_b64") or "")
            if not binary_b64:
                continue
            prop = decode_property(str(meta["edge_type"]), binary_b64)
            output_name = str(meta.get("key") or value.get("output_key") or output_index)
            if "StringMessage" in str(meta["edge_type"]):
                # if verbose_frame:
                    # frame_logs.append(f"渲染输出：{output_name}")
                img, message_y = _draw_message_on_image(img, prop, output_name, message_y)
                continue
            if not _is_renderable_region_type(str(meta["edge_type"])):
                continue
            allowed_labels = None
            if normalized_filter is not None:
                if output_name not in normalized_filter:
                    continue
                allowed_labels = normalized_filter[output_name]
            # if verbose_frame:
                # frame_logs.append(f"渲染输出：{output_name}")
            color = colors[output_index % len(colors)]
            img, drawn = _draw_property_on_image(
                img,
                prop,
                output_name,
                color,
                draw_labels=draw_region_labels,
                allowed_labels=allowed_labels,
            )
            total_drawn += drawn
        out_name = Path(str(row.get("file_name") or f"frame_{idx:06d}.jpg")).name
        out_path = out_dir / out_name
        # if verbose_frame:
            # frame_logs.append(f"保存渲染图：{out_name}，区域数：{total_drawn}")
        if not _imwrite_unicode(out_path, img):
            raise RuntimeError(f"保存渲染图失败：{out_path}")
        # if idx % 50 == 0:
        #     frame_logs.append(f"已渲染 {idx}/{len(rows)} 帧...")
        return idx, out_path, frame_logs

    worker_count = max(1, int(max_workers or 1))
    use_parallel = bool(parallel_render) and worker_count > 1 and len(rows) > 1
    if use_parallel:
        log(f"并行渲染已启用：{worker_count} 线程，共 {len(rows)} 帧")
        completed = 0
        with ThreadPoolExecutor(max_workers=worker_count) as executor:
            future_map = {}
            for idx, row in enumerate(rows, 1):
                if should_stop and should_stop():
                    log("收到中止请求，停止提交新的渲染任务。")
                    break
                future_map[executor.submit(render_one_frame, idx, row)] = idx
            for future in as_completed(future_map):
                if should_stop and should_stop():
                    log("收到中止请求，等待已提交渲染任务结束。")
                    break
                idx, out_path, frame_logs = future.result()
                rendered_paths_by_index[idx] = out_path
                for item in frame_logs:
                    log(item)
                completed += 1
                emit_progress(completed, len(future_map), "并行渲染 DB", span=render_span)
    else:
        for idx, row in enumerate(rows, 1):
            if should_stop and should_stop():
                log("收到中止请求，停止渲染。")
                break
            # emit_progress(idx - 1, len(rows), "渲染 DB", span=render_span)
            done_idx, out_path, frame_logs = render_one_frame(idx, row)
            rendered_paths_by_index[done_idx] = out_path
            for item in frame_logs:
                log(item)
            # emit_progress(idx, len(rows), "渲染 DB", span=render_span)

    rendered_paths = [rendered_paths_by_index[idx] for idx in sorted(rendered_paths_by_index)]
    if compose_video and rendered_paths:
        if should_stop and should_stop():
            log("收到中止请求，跳过视频合成。")
        else:
            fps = _compose_video_fps(db_path, data, log)
            video_path = _render_video_path(db_path)
            _images_to_video(
                rendered_paths,
                video_path,
                fps,
                log=log,
                progress=lambda cur, total, label: emit_progress(cur, total, label, base=800, span=200),
                should_stop=should_stop,
            )
    log(f"渲染完成：{out_dir}")
    return out_dir


def _render_rows_to_memory(
    *,
    rows: List[Dict[str, object]],
    outputs: List[Dict[str, object]],
    draw_region_labels: bool = False,
    render_filter: Optional[Dict[str, Optional[Iterable[str]]]] = None,
    sample_indexes: Optional[Iterable[int]] = None,
    parallel_render: bool = False,
    max_workers: int = 1,
    log: Callable[[str], None] = print,
    progress: Optional[Callable[[int, int, str], None]] = None,
    should_stop: Optional[Callable[[], bool]] = None,
) -> Dict[int, object]:
    _require_runtime_deps()
    if not rows:
        raise RuntimeError("内存规则结果中没有帧记录，无法渲染。")
    if not outputs:
        raise RuntimeError("内存规则结果中没有输出节点记录，无法渲染。")
    # [规则渲染按需落盘][生产迭代01-按告警帧渲染]
    # 修改人: Shiver; 修改时间: 2026-06-24;
    # 修改逻辑: 内存渲染支持按 sample_index 子集渲染，避免 normal 视频和非告警帧全量渲染。
    def _row_sample_index(row: Dict[str, object], fallback: int = -1) -> int:
        value = row.get("sample_index", fallback)
        if value is None or value == "":
            value = fallback
        try:
            return int(value)
        except Exception:
            return int(fallback)

    sample_index_filter: Optional[Set[int]] = None
    if sample_indexes is not None:
        sample_index_filter = set()
        for value in sample_indexes:
            try:
                sample_index_filter.add(int(value))
            except Exception:
                continue
    render_rows = rows
    if sample_index_filter is not None:
        render_rows = [
            row for row in rows
            if _row_sample_index(row) in sample_index_filter
        ]
        if not render_rows:
            log(f"内存规则图像按需渲染跳过：目标 sample_indexes={sorted(sample_index_filter)} 未匹配任何帧")
            return {}
    output_by_index = {int(item["index"]): item for item in outputs}
    normalized_filter: Optional[Dict[str, Optional[Set[str]]]] = None
    if render_filter is not None:
        normalized_filter = {}
        for output_key, labels in render_filter.items():
            if labels is None:
                normalized_filter[str(output_key)] = None
            else:
                label_set = {str(item) for item in labels}
                normalized_filter[str(output_key)] = label_set or None
    colors = RENDER_COLORS_BGR
    rendered_by_sample_index: Dict[int, object] = {}

    def render_one_frame(idx: int, row: Dict[str, object]):
        sample_index = _row_sample_index(row, idx - 1)
        source_img = row.get("image")
        # [1.内存模型预加载整段视频全部帧][生产迭代02-有界流式]
        # 修改人: Shiver; 修改时间: 2026-06-22;
        # 修改逻辑: 有界流式规则记录不含原图，渲染当前帧时通过固定容量provider读取。
        if source_img is None:
            provider = row.get("image_provider")
            getter = getattr(provider, "get_image", None)
            if callable(getter):
                source_img = getter(sample_index)
        if source_img is None:
            raise RuntimeError(f"内存帧缺少原图数组：{row.get('file_name', '')}")
        img = source_img.copy()
        message_y = 8
        for value in row.get("outputs", []):
            output_index = int(value.get("output_index", -1))
            meta = output_by_index.get(output_index)
            if not meta or value.get("error"):
                continue
            binary_b64 = str(value.get("binary_b64") or "")
            if not binary_b64:
                continue
            prop = decode_property(str(meta["edge_type"]), binary_b64)
            output_name = str(meta.get("key") or value.get("output_key") or output_index)
            if "StringMessage" in str(meta["edge_type"]):
                img, message_y = _draw_message_on_image(img, prop, output_name, message_y)
                continue
            if not _is_renderable_region_type(str(meta["edge_type"])):
                continue
            allowed_labels = None
            if normalized_filter is not None:
                if output_name not in normalized_filter:
                    continue
                allowed_labels = normalized_filter[output_name]
            color = colors[output_index % len(colors)]
            img, _drawn = _draw_property_on_image(
                img,
                prop,
                output_name,
                color,
                draw_labels=draw_region_labels,
                allowed_labels=allowed_labels,
            )
        return sample_index, img

    worker_count = max(1, int(max_workers or 1))
    use_parallel = bool(parallel_render) and worker_count > 1 and len(render_rows) > 1
    if use_parallel:
        log(f"并行内存渲染已启用：{worker_count} 线程，共 {len(render_rows)} 帧")
        completed = 0
        with ThreadPoolExecutor(max_workers=worker_count) as executor:
            future_map = {}
            for idx, row in enumerate(render_rows, 1):
                if should_stop and should_stop():
                    log("收到中止请求，停止提交新的内存渲染任务。")
                    break
                future_map[executor.submit(render_one_frame, idx, row)] = idx
            for future in as_completed(future_map):
                if should_stop and should_stop():
                    log("收到中止请求，等待已提交内存渲染任务结束。")
                    break
                sample_index, img = future.result()
                rendered_by_sample_index[sample_index] = img
                completed += 1
                if progress:
                    progress(completed, max(1, len(future_map)), "内存渲染")
    else:
        for idx, row in enumerate(render_rows, 1):
            if should_stop and should_stop():
                log("收到中止请求，停止内存渲染。")
                break
            sample_index, img = render_one_frame(idx, row)
            rendered_by_sample_index[sample_index] = img
            if progress:
                progress(idx, len(render_rows), "内存渲染")
    log(f"内存规则图像渲染完成：{len(rendered_by_sample_index)} 帧")
    return rendered_by_sample_index


def render_rule_images_memory(
    rule_result: MemoryRuleResult,
    *,
    draw_region_labels: bool = False,
    render_filter: Optional[Dict[str, Optional[Iterable[str]]]] = None,
    sample_indexes: Optional[Iterable[int]] = None,
    parallel_render: bool = False,
    max_workers: int = 1,
    log: Callable[[str], None] = print,
    progress: Optional[Callable[[int, int, str], None]] = None,
    should_stop: Optional[Callable[[], bool]] = None,
) -> Dict[int, object]:
    """Render rule outputs on in-memory source frames without writing rendered_rules/.

    [规则渲染按需落盘][生产迭代01-按告警帧渲染]
    修改人: Shiver; 修改时间: 2026-06-24;
    修改逻辑: sample_indexes 非空时只渲染指定帧，用于告警协议产物按需落盘。
    """
    rendered = _render_rows_to_memory(
        rows=rule_result.frames,
        outputs=rule_result.outputs,
        draw_region_labels=draw_region_labels,
        render_filter=render_filter,
        sample_indexes=sample_indexes,
        parallel_render=parallel_render,
        max_workers=max_workers,
        log=log,
        progress=progress,
        should_stop=should_stop,
    )
    rule_result.rendered_images = rendered
    return rendered


def render_cache_batch(
    target_path: Path,
    *,
    draw_region_labels: bool = False,
    render_filter: Optional[Dict[str, Optional[Iterable[str]]]] = None,
    compose_video: bool = False,
    parallel_render: bool = False,
    max_workers: int = 1,
    only_rule_dbs: bool = False,
    log: Callable[[str], None] = print,
    progress: Optional[Callable[[int, int, str], None]] = None,
    should_stop: Optional[Callable[[], bool]] = None,
) -> List[Path]:
    db_paths = discover_cache_dbs(target_path, db_kind="rule" if only_rule_dbs else "infer")
    if not db_paths:
        expected = "*_infer_cache_rules.sqlite" if only_rule_dbs else "*_infer_cache.sqlite"
        raise RuntimeError(
            f"未找到可渲染的缓存 DB：{target_path}。"
            f"仅支持 {expected}，且需要 DB 同级目录存在 frames/。"
        )
    results = []
    failures = 0
    total = len(db_paths)
    single_db_mode = target_path.is_file() and total == 1
    log(f"发现 {total} 个可渲染 DB。")
    for idx, db_path in enumerate(db_paths, 1):
        if should_stop and should_stop():
            log("收到中止请求，停止批量渲染。")
            break
        log(f"===== [{idx}/{total}] 开始渲染：{db_path} =====")
        if progress:
            progress(idx - 1, total, "批量渲染")
        try:
            out_dir = render_cache_images(
                db_path,
                draw_region_labels=draw_region_labels,
                render_filter=render_filter,
                compose_video=compose_video,
                parallel_render=parallel_render,
                max_workers=max_workers,
                log=log,
                progress=progress if single_db_mode else None,
                should_stop=should_stop,
            )
            results.append(out_dir)
        except Exception as exc:
            if single_db_mode:
                raise
            failures += 1
            log(f"渲染失败，跳过该 DB：{db_path}")
            log(str(exc))
        if progress:
            progress(idx, total, "批量渲染")
    if not results and failures:
        raise RuntimeError(f"批量渲染失败：{failures}/{total} 个 DB 失败，详见日志。")
    log(f"批量渲染完成：成功 {len(results)} 个，失败 {failures} 个。")
    return results


def export_classified_images(
    db_path: Path,
    labels: Iterable[str],
    *,
    save_original: bool = False,
    save_rendered: bool = False,
    log: Callable[[str], None] = print,
) -> Dict[str, int]:
    """Copy frames/rendered images into label folders according to rule DB frame_labels.

    This never moves or modifies the original `frames/` directory. It only copies
    selected files into:
    - classified_frames/<label>/
    - classified_rendered/<label>/
    """
    db_path = Path(db_path)
    if not is_rule_cache_db(db_path):
        raise RuntimeError(f"分类保存只支持规则 DB：{db_path}")
    selected_labels = [str(label).strip() for label in labels if str(label).strip()]
    if not selected_labels:
        raise RuntimeError("分类保存未选择任何 summary 标签。")
    if not save_original and not save_rendered:
        raise RuntimeError("分类保存需要至少选择保存原图或渲染图。")

    data = load_cache(db_path, load_outputs=False)
    rows_by_id = {int(row["frame_id"]): row for row in data.get("rows", [])}
    label_set = set(selected_labels)
    rendered_dir = _default_render_dir(db_path)
    out_frames_root = db_path.parent / "classified_frames"
    out_rendered_root = db_path.parent / "classified_rendered"
    if save_original:
        _remove_existing_path(out_frames_root, log=log, label="旧分类原图")
    if save_rendered:
        _remove_existing_path(out_rendered_root, log=log, label="旧分类渲染图")

    stats = {label: 0 for label in selected_labels}
    with sqlite3.connect(str(db_path)) as conn:
        try:
            label_rows = conn.execute(
                """
                SELECT frame_id, label FROM frame_labels
                WHERE label IN ({})
                ORDER BY frame_id, label
                """.format(",".join("?" for _ in selected_labels)),
                selected_labels,
            ).fetchall()
        except sqlite3.OperationalError as exc:
            raise RuntimeError("规则 DB 中没有 frame_labels 表，请先重新执行规则生成 summary 标签。") from exc

    for frame_id, label in label_rows:
        label = str(label)
        if label not in label_set:
            continue
        row = rows_by_id.get(int(frame_id))
        if not row:
            continue
        file_name = Path(str(row.get("file_name") or f"frame_{frame_id:06d}.jpg")).name
        copied_any = False
        safe_label = _safe_label_dir_name(label)
        if save_original:
            src = _resolve_frame_image_path(row, db_path)
            dst_dir = out_frames_root / safe_label
            dst_dir.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dst_dir / file_name)
            copied_any = True
        if save_rendered:
            src = rendered_dir / file_name
            if not src.exists():
                log(f"分类保存跳过渲染图，文件不存在：{src}")
            else:
                dst_dir = out_rendered_root / safe_label
                dst_dir.mkdir(parents=True, exist_ok=True)
                shutil.copy2(src, dst_dir / file_name)
                copied_any = True
        if copied_any:
            stats[label] += 1

    log(
        "分类保存完成："
        + "，".join(f"{label}={count}" for label, count in stats.items())
    )
    return stats
