#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Offline aggregator for infer-cache video trace JSONL files.

[视频处理耗时复盘JSONL][离线汇总01]
修改人: Shiver; 修改时间: 2026-06-24;
修改逻辑: 新增纯标准库离线汇总脚本，按 online/test 环境和用户指定时间范围，
汇总 video_summary/video_stage JSONL 记录为 CSV，避免现场离线环境安装额外依赖。
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import shutil
import sys
import zipfile
from collections import OrderedDict, defaultdict
from collections.abc import Iterable, Mapping, MutableMapping, Sequence
from datetime import date, datetime, time, timedelta
from pathlib import Path
from typing import Dict, List, Optional, Tuple


TRACE_PREFIX = "[视频处理耗时复盘JSONL][离线汇总01]"
SCRIPT_DIR = Path(__file__).resolve().parent
DEFAULT_OUTPUT_ROOT = SCRIPT_DIR / "output"
DEFAULT_TRACE_ROOTS = {
    "online": Path("/opt/mnt/dev/aq/trace"),
    "test": Path("/opt/mnt/dev/aqtest/trace"),
}
DEFAULT_PATTERN = "*_video_trace.jsonl"
SCAN_EXTRA_DAYS_AFTER = 1


SUMMARY_COLUMNS = [
    "trace_id",
    "run_id",
    "task_id",
    "request_id",
    "instance_id",
    "video_index",
    "video_status",
    "overall_result",
    "protocol_status",
    "is_alarm",
    "machine_type",
    "eqp_id",
    "chamber",
    "wafer_id",
    "wafer_start_time",
    "send_time",
    "raw_video_path",
    "local_video_path",
    "video_suffix",
    "video_size_bytes",
    "source_fps",
    "target_fps",
    "actual_sample_fps",
    "duration_sec",
    "source_frame_count",
    "expected_sample_frames",
    "sampled_frame_count",
    "image_width",
    "image_height",
    "source_is_probable_nas",
    "source_mount_type",
    "source_mount_point",
    "source_mount_source",
    "stage1_frame_count",
    "stage1_hit_count",
    "stage2_target_frame_count",
    "stage2_processed_frame_count",
    # [2#稀疏补推][生产迭代01]
    # 修改人: Shiver; 修改时间: 2026-06-25;
    # 修改逻辑: video_summary CSV增加2#稀疏补推计数，支持A/C对比推理量、节省量和回退情况。
    "stage2_sparse_enabled",
    "stage2_sparse_stride",
    "stage2_sparse_trigger_mode",
    "stage2_sparse_initial_count",
    "stage2_sparse_model_raw_hit_count",
    "stage2_sparse_rule3_hit_count",
    "stage2_sparse_hit_count",
    "stage2_sparse_refine_count",
    "stage2_sparse_final_count",
    "stage2_sparse_saved_count",
    "stage2_sparse_boundary_dense_count",
    "stage2_sparse_fallback_full",
    "stage2_sparse_trigger_eval_ms",
    "stage2_sparse_trigger_fallback_model_raw",
    "rule_frame_count",
    "rendered_frame_count",
    "gif_frame_count",
    # [视频处理耗时复盘JSONL][NAS读取诊断01]
    # 修改人: Shiver; 修改时间: 2026-06-24;
    # 修改逻辑: 单视频明细直接导出源视频读取+解码耗时，支持排查 NAS/CIFS 或 OpenCV 解码瓶颈。
    "source_video_read_decode_ms",
    "source_video_read_decode_time",
    "stage1_source_video_read_decode_ms",
    "stage1_source_video_read_decode_time",
    "stage2_source_video_read_decode_ms",
    "stage2_source_video_read_decode_time",
    "provider_source_video_read_decode_ms",
    "provider_source_video_read_decode_time",
    "source_video_read_call_count",
    "source_video_read_frame_count",
    "source_video_yield_frame_count",
    "video_total_ms",
    "video_total_sec",
    "video_total_time",
    "local_processing_ms_exclude_callback",
    "local_processing_time_exclude_callback",
    "video_prepare_ms",
    "video_prepare_time",
    "stage1_stream_infer_ms",
    "stage1_stream_infer_time",
    "target_select_ms",
    "target_select_time",
    "stage2_stream_infer_ms",
    "stage2_stream_infer_time",
    "rule_execute_ms",
    "rule_execute_time",
    "rule_render_ms",
    "rule_render_time",
    "rule_result_read_ms",
    "rule_result_read_time",
    "frame_assembly_ms",
    "frame_assembly_time",
    "testoutput_save_ms",
    "testoutput_save_time",
    "protocol_materialize_ms",
    "protocol_materialize_time",
    "alarm_callback_ms",
    "alarm_callback_time",
    "video_release_ms",
    "video_release_time",
    "result_json_path",
    "text_log_path",
    "select_img_path",
    "original_img_path",
    "roi_img_path",
    "original_gif_path",
    "rendered_gif_path",
    "alarm_video_path",
    "alarm_sample_index",
    "alarm_matched_label",
    "alarm_priority_rank",
    "callback_attempted",
    "callback_status_code",
    "callback_error",
    "started_at",
    "ended_at",
    "created_at",
    "timezone",
    "error_message",
]


STAGE_COLUMNS = [
    "trace_id",
    "run_id",
    "task_id",
    "request_id",
    "instance_id",
    "video_index",
    "machine_type",
    "eqp_id",
    "chamber",
    "wafer_id",
    "raw_video_path",
    "local_video_path",
    "stage_order",
    "stage_key",
    "stage_name",
    "status",
    "duration_ms",
    "duration_sec",
    "duration_time",
    "started_at",
    "ended_at",
    "created_at",
    "frame_count",
    "decoded_frame_count",
    "processed_frame_count",
    "target_count",
    "output_count",
    "stage1_frame_count",
    "stage1_hit_count",
    "stage2_decode_frame_count",
    "stage2_target_frame_count",
    "stage2_processed_frame_count",
    "stage2_skipped_frame_count",
    # [2#稀疏补推][生产迭代01]
    # 修改人: Shiver; 修改时间: 2026-06-25;
    # 修改逻辑: 阶段明细展开2#稀疏扫描/补推字段，避免现场手工解析workload_json。
    "stage2_sparse_enabled",
    "stage2_sparse_stride",
    "stage2_sparse_trigger_mode",
    "stage2_sparse_initial_count",
    "stage2_sparse_model_raw_hit_count",
    "stage2_sparse_rule3_hit_count",
    "stage2_sparse_hit_count",
    "stage2_sparse_refine_count",
    "stage2_sparse_final_count",
    "stage2_sparse_saved_count",
    "stage2_sparse_boundary_dense_count",
    "stage2_sparse_fallback_full",
    "stage2_sparse_trigger_eval_ms",
    "stage2_sparse_trigger_fallback_model_raw",
    "missing_count",
    # [规则渲染按需落盘][生产迭代01-按告警帧渲染]
    # 修改人: Shiver; 修改时间: 2026-06-24;
    # 修改逻辑: 阶段明细 CSV 直接导出按需渲染目标帧数，现场不用再手工解析 detail_json/workload。
    "render_target_frame_count",
    "rendered_frame_count",
    "image_write_count",
    "gif_frame_count",
    "copy_bytes",
    "queue_limit",
    "pending_peak",
    "resident_raw_frames",
    # [视频处理耗时复盘JSONL][NAS读取诊断01]
    # 修改人: Shiver; 修改时间: 2026-06-24;
    # 修改逻辑: 阶段明细展开源视频打开、seek、读取+解码耗时，不用现场手工解析 timing_detail_json。
    "source_is_probable_nas",
    "source_mount_type",
    "source_mount_point",
    "source_mount_source",
    "source_video_safe_path_ms",
    "source_video_open_ms",
    "source_video_metadata_ms",
    "source_video_seek_ms",
    "source_video_read_call_count",
    "source_video_read_frame_count",
    "source_video_yield_frame_count",
    "source_video_read_decode_ms",
    "source_video_read_decode_time",
    "source_video_read_decode_avg_ms",
    "source_video_read_decode_max_ms",
    "source_video_first_frame_read_ms",
    "memory_usage_bytes",
    "pids",
    "python_threads",
    "timing_detail_json",
    "detail_json",
    "resource_json",
    "error_message",
]


MACHINE_COLUMNS = [
    "machine_type",
    "eqp_id",
    "chamber",
    "video_count",
    "alarm_video_count",
    "normal_video_count",
    "failed_video_count",
    "alarm_rate",
    "avg_video_total_time",
    "p50_video_total_time",
    "p90_video_total_time",
    "max_video_total_time",
    "avg_video_total_ms",
    "p50_video_total_ms",
    "p90_video_total_ms",
    "max_video_total_ms",
    "avg_local_processing_time_exclude_callback",
    "avg_local_processing_ms_exclude_callback",
    "avg_duration_sec",
    "avg_source_frame_count",
    "avg_stage1_frame_count",
    "avg_stage1_hit_count",
    "avg_stage2_target_frame_count",
    "avg_stage2_processed_frame_count",
]


STAGE_AGG_COLUMNS = [
    "stage_key",
    "stage_name",
    "min_stage_order",
    "record_count",
    "success_count",
    "skipped_count",
    "failed_count",
    "total_duration_time",
    "avg_duration_time",
    "p50_duration_time",
    "p90_duration_time",
    "max_duration_time",
    "total_duration_ms",
    "avg_duration_ms",
    "p50_duration_ms",
    "p90_duration_ms",
    "max_duration_ms",
    "avg_frame_count",
    "avg_stage2_target_frame_count",
    "avg_stage2_processed_frame_count",
    "avg_stage2_sparse_initial_count",
    "avg_stage2_sparse_model_raw_hit_count",
    "avg_stage2_sparse_rule3_hit_count",
    "avg_stage2_sparse_refine_count",
    "avg_stage2_sparse_final_count",
    "avg_stage2_sparse_saved_count",
    "total_stage2_sparse_saved_count",
    "stage2_sparse_fallback_full_count",
    "avg_stage2_sparse_trigger_eval_ms",
    "total_stage2_sparse_trigger_eval_ms",
    "stage2_sparse_trigger_fallback_model_raw_count",
    # [规则渲染按需落盘][生产迭代01-按告警帧渲染]
    # 修改人: Shiver; 修改时间: 2026-06-24;
    # 修改逻辑: 阶段聚合 CSV 增加 rule_render 的目标帧/实际渲染帧统计，便于确认优化生效。
    "avg_render_target_frame_count",
    "total_render_target_frame_count",
    "total_rendered_frame_count",
    "total_image_write_count",
    "total_gif_frame_count",
    "total_copy_bytes",
    # [视频处理耗时复盘JSONL][NAS读取诊断01]
    # 修改人: Shiver; 修改时间: 2026-06-24;
    # 修改逻辑: 阶段聚合直接统计源视频读解码耗时，便于对比 stage1/stage2/provider 的源读取压力。
    "total_source_video_read_decode_time",
    "avg_source_video_read_decode_time",
    "p90_source_video_read_decode_time",
    "max_source_video_read_decode_time",
    "total_source_video_read_decode_ms",
    "avg_source_video_read_decode_ms",
    "p90_source_video_read_decode_ms",
    "max_source_video_read_decode_ms",
    "total_source_video_read_call_count",
    "total_source_video_read_frame_count",
    "total_source_video_open_time",
    "avg_source_video_open_time",
    "total_source_video_metadata_time",
    "avg_source_video_metadata_time",
    "total_source_video_seek_time",
    "avg_source_video_seek_time",
]


ALARM_COLUMNS = [
    "trace_id",
    "task_id",
    "instance_id",
    "video_index",
    "protocol_status",
    "overall_result",
    "eqp_id",
    "chamber",
    "wafer_id",
    "send_time",
    "raw_video_path",
    "local_video_path",
    "alarm_matched_label",
    "alarm_sample_index",
    "video_total_ms",
    "video_total_time",
    "stage1_stream_infer_ms",
    "stage1_stream_infer_time",
    "stage2_stream_infer_ms",
    "stage2_stream_infer_time",
    "stage2_sparse_enabled",
    "stage2_sparse_trigger_mode",
    "stage2_sparse_initial_count",
    "stage2_sparse_model_raw_hit_count",
    "stage2_sparse_rule3_hit_count",
    "stage2_sparse_hit_count",
    "stage2_sparse_refine_count",
    "stage2_sparse_saved_count",
    "stage2_sparse_fallback_full",
    "stage2_sparse_trigger_eval_ms",
    "stage2_sparse_trigger_fallback_model_raw",
    "source_video_read_decode_time",
    "stage1_source_video_read_decode_time",
    "stage2_source_video_read_decode_time",
    "provider_source_video_read_decode_time",
    "protocol_materialize_ms",
    "protocol_materialize_time",
    "alarm_callback_ms",
    "alarm_callback_time",
    "select_img_path",
    "original_img_path",
    "roi_img_path",
    "original_gif_path",
    "rendered_gif_path",
    "alarm_video_path",
    "result_json_path",
    "text_log_path",
    "callback_attempted",
    "callback_status_code",
    "callback_error",
    "started_at",
    "ended_at",
]


ASSET_MANIFEST_COLUMNS = [
    "trace_id",
    "task_id",
    "instance_id",
    "video_index",
    "eqp_id",
    "chamber",
    "wafer_id",
    "asset_type",
    "source_path",
    "exists",
    "file_size_bytes",
    "zip_path",
    "error_message",
]


VIDEO_KEY_COLUMNS = [
    "trace_id",
    "run_id",
    "task_id",
    "request_id",
    "instance_id",
    "video_index",
    "video_status",
    "overall_result",
    "protocol_status",
    "is_alarm",
    "machine_type",
    "eqp_id",
    "chamber",
    "wafer_id",
    "send_time",
    "raw_video_path",
    "local_video_path",
    "source_frame_count",
    "sampled_frame_count",
    "stage1_frame_count",
    "stage1_hit_count",
    "stage2_target_frame_count",
    "stage2_processed_frame_count",
    "stage2_sparse_enabled",
    "stage2_sparse_stride",
    "stage2_sparse_trigger_mode",
    "stage2_sparse_initial_count",
    "stage2_sparse_model_raw_hit_count",
    "stage2_sparse_rule3_hit_count",
    "stage2_sparse_hit_count",
    "stage2_sparse_refine_count",
    "stage2_sparse_final_count",
    "stage2_sparse_saved_count",
    "stage2_sparse_fallback_full",
    "stage2_sparse_trigger_eval_ms",
    "stage2_sparse_trigger_fallback_model_raw",
    "rule_frame_count",
    "rendered_frame_count",
    "gif_frame_count",
    "source_is_probable_nas",
    "source_mount_type",
    "source_mount_point",
    "source_mount_source",
    "source_video_read_decode_time",
    "source_video_read_decode_ms",
    "stage1_source_video_read_decode_time",
    "stage1_source_video_read_decode_ms",
    "stage2_source_video_read_decode_time",
    "stage2_source_video_read_decode_ms",
    "provider_source_video_read_decode_time",
    "provider_source_video_read_decode_ms",
    "source_video_read_call_count",
    "source_video_read_frame_count",
    "source_video_yield_frame_count",
    "video_total_time",
    "video_total_ms",
    "local_processing_time_exclude_callback",
    "local_processing_ms_exclude_callback",
    "stage1_stream_infer_time",
    "stage1_stream_infer_ms",
    "stage2_stream_infer_time",
    "stage2_stream_infer_ms",
    "rule_execute_time",
    "rule_execute_ms",
    "rule_render_time",
    "rule_render_ms",
    "protocol_materialize_time",
    "protocol_materialize_ms",
    "alarm_callback_time",
    "alarm_callback_ms",
    "select_img_path",
    "original_img_path",
    "roi_img_path",
    "original_gif_path",
    "rendered_gif_path",
    "alarm_video_path",
    "callback_status_code",
    "callback_error",
    "started_at",
    "ended_at",
]


def _json_text(value: object) -> str:
    if value is None:
        return ""
    if isinstance(value, (dict, list, tuple)):
        return json.dumps(value, ensure_ascii=False, separators=(",", ":"))
    if isinstance(value, bool):
        return "true" if value else "false"
    return str(value)


def _is_empty(value: object) -> bool:
    return value is None or (isinstance(value, str) and value == "")


def _get_path(record: Mapping[str, object], dotted: str, default: object = "") -> object:
    current: object = record
    for part in dotted.split("."):
        if isinstance(current, Mapping) and part in current:
            current = current[part]
        else:
            return default
    return current


def _pick(record: Mapping[str, object], *paths: str, default: object = "") -> object:
    for path in paths:
        value = _get_path(record, path, default=None)
        if not _is_empty(value):
            return value
    return default


def _to_int(value: object, default: int = 0) -> int:
    if value is None or value == "":
        return default
    try:
        return int(float(str(value)))
    except Exception:
        return default


def _to_float(value: object, default: float = 0.0) -> float:
    if value is None or value == "":
        return default
    try:
        return float(str(value))
    except Exception:
        return default


def _round_float(value: object, digits: int = 3) -> object:
    number = _to_float(value, default=math.nan)
    if math.isnan(number):
        return ""
    return round(number, digits)


def _duration_text_from_ms(value: object) -> str:
    """Return human-readable duration.

    [视频处理耗时复盘JSONL][离线汇总02]
    修改人: Shiver; 修改时间: 2026-06-24;
    修改逻辑: 现场汇总默认以秒为单位展示；超过 1 分钟展示为 xminxs，
    同时保留原始毫秒字段用于排序和二次分析。
    """
    ms = _to_float(value, default=math.nan)
    if math.isnan(ms):
        return ""
    seconds = ms / 1000.0
    if seconds < 60:
        text = f"{seconds:.3f}".rstrip("0").rstrip(".")
        return f"{text or '0'}s"
    minutes = int(seconds // 60)
    remain = seconds - minutes * 60
    remain_text = f"{remain:.3f}".rstrip("0").rstrip(".")
    return f"{minutes}min{remain_text or '0'}s"


def _avg(values: Sequence[float]) -> object:
    clean = [float(v) for v in values if v is not None]
    if not clean:
        return ""
    return round(sum(clean) / len(clean), 3)


def _percentile(values: Sequence[float], percentile: float) -> object:
    clean = sorted(float(v) for v in values if v is not None)
    if not clean:
        return ""
    if len(clean) == 1:
        return round(clean[0], 3)
    rank = (len(clean) - 1) * percentile
    lower = math.floor(rank)
    upper = math.ceil(rank)
    if lower == upper:
        return round(clean[int(rank)], 3)
    weight = rank - lower
    return round(clean[lower] * (1 - weight) + clean[upper] * weight, 3)


def _date_from_text(text: str) -> date:
    value = str(text or "").strip()
    for fmt in ("%Y-%m-%d", "%Y_%m_%d", "%Y%m%d"):
        try:
            return datetime.strptime(value, fmt).date()
        except ValueError:
            continue
    raise ValueError(f"日期格式不支持：{text}，请使用 YYYY-MM-DD，例如 2026-06-24")


def _is_time_only(text: str) -> bool:
    value = str(text or "").strip()
    return bool(value) and ":" in value and all(ch.isdigit() or ch == ":" for ch in value)


def _parse_time_only(text: str, *, default_end: bool = False) -> time:
    value = str(text or "").strip()
    for fmt in ("%H:%M:%S", "%H:%M"):
        try:
            parsed = datetime.strptime(value, fmt).time()
            if fmt == "%H:%M" and default_end:
                return time(parsed.hour, parsed.minute, 59, 999999)
            return parsed
        except ValueError:
            continue
    raise ValueError(f"时间格式不支持：{text}，请使用 HH:MM:SS，例如 10:30:00")


def _parse_datetime_text(text: str, *, base_date: Optional[date] = None, default_end: bool = False) -> datetime:
    value = str(text or "").strip()
    if not value:
        raise ValueError("时间不能为空")
    if base_date is not None and _is_time_only(value):
        return datetime.combine(base_date, _parse_time_only(value, default_end=default_end))
    normalized = value.replace("/", "-")
    try:
        iso_value = normalized[:-1] + "+00:00" if normalized.endswith("Z") else normalized
        parsed = datetime.fromisoformat(iso_value)
        if default_end and (" " not in normalized and "T" not in normalized):
            parsed = datetime.combine(parsed.date(), time(23, 59, 59, 999999))
        elif default_end and (" " in normalized or "T" in normalized):
            time_part = normalized.split("T", 1)[-1].split(" ", 1)[-1]
            if time_part.count(":") == 1:
                parsed = parsed.replace(second=59, microsecond=999999)
        return parsed.replace(tzinfo=None) if parsed.tzinfo else parsed
    except ValueError:
        pass
    for fmt in (
        "%Y-%m-%d %H:%M:%S",
        "%Y-%m-%d %H:%M",
        "%Y_%m_%d %H:%M:%S",
        "%Y_%m_%d %H:%M",
        "%Y%m%d%H%M%S",
        "%Y%m%d_%H%M%S",
        "%Y-%m-%d",
        "%Y_%m_%d",
        "%Y%m%d",
    ):
        try:
            parsed = datetime.strptime(normalized, fmt)
            if fmt in ("%Y-%m-%d", "%Y_%m_%d", "%Y%m%d") and default_end:
                return datetime.combine(parsed.date(), time(23, 59, 59, 999999))
            if fmt in ("%Y-%m-%d %H:%M", "%Y_%m_%d %H:%M") and default_end:
                return parsed.replace(second=59, microsecond=999999)
            return parsed
        except ValueError:
            continue
    raise ValueError(f"日期时间格式不支持：{text}，请使用 YYYY-MM-DD HH:MM:SS")


def _resolve_time_range(args: argparse.Namespace) -> Tuple[datetime, datetime]:
    if args.date:
        selected_day = _date_from_text(args.date)
        start_dt = datetime.combine(selected_day, time(0, 0, 0))
        end_dt = datetime.combine(selected_day, time(23, 59, 59, 999999))
        if args.start:
            start_dt = _parse_datetime_text(args.start, base_date=selected_day, default_end=False)
        if args.end:
            end_dt = _parse_datetime_text(args.end, base_date=selected_day, default_end=True)
    else:
        today = datetime.now().date()
        start_dt = _parse_datetime_text(args.start, default_end=False) if args.start else datetime.combine(today, time(0, 0, 0))
        if args.end:
            end_dt = _parse_datetime_text(args.end, default_end=True)
        else:
            end_dt = datetime.combine(start_dt.date(), time(23, 59, 59, 999999))
    if end_dt < start_dt:
        raise ValueError(f"结束时间早于开始时间：start={start_dt} end={end_dt}")
    return start_dt, end_dt


def _iter_days(start_dt: datetime, end_dt: datetime) -> Iterable[date]:
    current = start_dt.date()
    last = end_dt.date()
    while current <= last:
        yield current
        current += timedelta(days=1)


def _parse_record_time(record: Mapping[str, object]) -> Optional[datetime]:
    for key in ("started_at", "created_at", "ended_at"):
        value = record.get(key)
        if not value:
            continue
        try:
            return _parse_datetime_text(str(value), default_end=False)
        except Exception:
            continue
    return None


def _record_in_range(record: Mapping[str, object], start_dt: datetime, end_dt: datetime) -> bool:
    parsed = _parse_record_time(record)
    if parsed is None:
        return True
    return start_dt <= parsed <= end_dt


def _safe_output_name(text: str) -> str:
    return "".join(ch if ch.isalnum() or ch in {"-", "_"} else "_" for ch in text)


def _path_is_inside(child: Path, parent: Path) -> bool:
    try:
        child.resolve().relative_to(parent.resolve())
        return True
    except Exception:
        return False


def _find_input_files(trace_root: Path, start_dt: datetime, end_dt: datetime, pattern: str) -> List[Path]:
    files: List[Path] = []
    # [视频处理耗时复盘JSONL][离线汇总02]
    # 修改人: Shiver; 修改时间: 2026-06-24;
    # 修改逻辑: JSONL 文件目录按记录写入当天生成；视频汇总统计按 started_at，
    # 所以默认多扫描结束日期后 1 天，覆盖跨零点结束的视频 summary。
    scan_end_dt = end_dt + timedelta(days=SCAN_EXTRA_DAYS_AFTER)
    for day in _iter_days(start_dt, scan_end_dt):
        day_dir = trace_root / day.strftime("%Y-%m-%d")
        if day_dir.exists():
            files.extend(sorted(path for path in day_dir.glob(pattern) if path.is_file()))
    return sorted(files)


def _is_alarm(summary: Mapping[str, object]) -> bool:
    protocol_status = str(_pick(summary, "protocol_status", default="")).strip().lower()
    overall_result = str(_pick(summary, "overall_result", default="")).strip().upper()
    return protocol_status == "alarm" or overall_result == "NG"


def _is_failed(summary: Mapping[str, object]) -> bool:
    protocol_status = str(_pick(summary, "protocol_status", default="")).strip().lower()
    video_status = str(_pick(summary, "video_status", default="")).strip().lower()
    return protocol_status == "internal_error" or video_status == "failed"


def _summary_row(record: Mapping[str, object]) -> Dict[str, object]:
    video_total_ms = _to_int(_pick(record, "timing_ms.video_total_ms", default=0), 0)
    callback_ms = _to_int(_pick(record, "timing_ms.alarm_callback_ms", default=0), 0)
    local_processing_ms = max(0, video_total_ms - callback_ms)
    video_prepare_ms = _pick(record, "timing_ms.video_prepare_ms")
    stage1_stream_infer_ms = _pick(record, "timing_ms.stage1_stream_infer_ms")
    target_select_ms = _pick(record, "timing_ms.target_select_ms")
    stage2_stream_infer_ms = _pick(record, "timing_ms.stage2_stream_infer_ms")
    rule_execute_ms = _pick(record, "timing_ms.rule_execute_ms")
    rule_render_ms = _pick(record, "timing_ms.rule_render_ms")
    rule_result_read_ms = _pick(record, "timing_ms.rule_result_read_ms")
    frame_assembly_ms = _pick(record, "timing_ms.frame_assembly_ms")
    testoutput_save_ms = _pick(record, "timing_ms.testoutput_save_ms")
    protocol_materialize_ms = _pick(record, "timing_ms.protocol_materialize_ms")
    video_release_ms = _pick(record, "timing_ms.video_release_ms")
    # [视频处理耗时复盘JSONL][NAS读取诊断01]
    # 修改人: Shiver; 修改时间: 2026-06-24;
    # 修改逻辑: 单视频 summary workload 中的源AVI读解码耗时保留毫秒小数，并补充可读耗时。
    source_video_read_decode_ms = _pick(record, "workload.source_video_read_decode_ms")
    stage1_source_video_read_decode_ms = _pick(record, "workload.stage1_source_video_read_decode_ms")
    stage2_source_video_read_decode_ms = _pick(record, "workload.stage2_source_video_read_decode_ms")
    provider_source_video_read_decode_ms = _pick(record, "workload.provider_source_video_read_decode_ms")
    row = {
        "trace_id": _pick(record, "trace_id"),
        "run_id": _pick(record, "run_id"),
        "task_id": _pick(record, "task_id"),
        "request_id": _pick(record, "request_id"),
        "instance_id": _pick(record, "instance_id"),
        "video_index": _pick(record, "video_index"),
        "video_status": _pick(record, "video_status"),
        "overall_result": _pick(record, "overall_result"),
        "protocol_status": _pick(record, "protocol_status"),
        "is_alarm": _is_alarm(record),
        "machine_type": _pick(record, "business.machine_type", "machine_type"),
        "eqp_id": _pick(record, "business.eqp_id", "eqp_id"),
        "chamber": _pick(record, "business.chamber", "chamber"),
        "wafer_id": _pick(record, "business.wafer_id", "wafer_id"),
        "wafer_start_time": _pick(record, "business.wafer_start_time", "wafer_start_time"),
        "send_time": _pick(record, "business.send_time", "send_time"),
        "raw_video_path": _pick(record, "video_info.raw_video_path", "raw_video_path"),
        "local_video_path": _pick(record, "video_info.local_video_path", "local_video_path"),
        "video_suffix": _pick(record, "video_info.video_suffix"),
        "video_size_bytes": _pick(record, "video_info.video_size_bytes"),
        "source_fps": _pick(record, "video_info.source_fps"),
        "target_fps": _pick(record, "video_info.target_fps"),
        "actual_sample_fps": _pick(record, "video_info.actual_sample_fps"),
        "duration_sec": _pick(record, "video_info.duration_sec"),
        "source_frame_count": _pick(record, "video_info.source_frame_count"),
        "expected_sample_frames": _pick(record, "video_info.expected_sample_frames"),
        "sampled_frame_count": _pick(record, "video_info.sampled_frame_count"),
        "image_width": _pick(record, "video_info.image_width"),
        "image_height": _pick(record, "video_info.image_height"),
        "source_is_probable_nas": _pick(record, "video_info.source_is_probable_nas"),
        "source_mount_type": _pick(record, "video_info.source_mount_type"),
        "source_mount_point": _pick(record, "video_info.source_mount_point"),
        "source_mount_source": _pick(record, "video_info.source_mount_source"),
        "stage1_frame_count": _pick(record, "workload.stage1_frame_count"),
        "stage1_hit_count": _pick(record, "workload.stage1_hit_count"),
        "stage2_target_frame_count": _pick(record, "workload.stage2_target_frame_count"),
        "stage2_processed_frame_count": _pick(record, "workload.stage2_processed_frame_count"),
        # [2#稀疏补推][生产迭代01]
        # 修改人: Shiver; 修改时间: 2026-06-25;
        # 修改逻辑: 单视频汇总行展开2#稀疏补推计数，支持直接过滤/排序分析。
        "stage2_sparse_enabled": _pick(record, "workload.stage2_sparse_enabled"),
        "stage2_sparse_stride": _pick(record, "workload.stage2_sparse_stride"),
        "stage2_sparse_trigger_mode": _pick(record, "workload.stage2_sparse_trigger_mode"),
        "stage2_sparse_initial_count": _pick(record, "workload.stage2_sparse_initial_count"),
        "stage2_sparse_model_raw_hit_count": _pick(record, "workload.stage2_sparse_model_raw_hit_count"),
        "stage2_sparse_rule3_hit_count": _pick(record, "workload.stage2_sparse_rule3_hit_count"),
        "stage2_sparse_hit_count": _pick(record, "workload.stage2_sparse_hit_count"),
        "stage2_sparse_refine_count": _pick(record, "workload.stage2_sparse_refine_count"),
        "stage2_sparse_final_count": _pick(record, "workload.stage2_sparse_final_count"),
        "stage2_sparse_saved_count": _pick(record, "workload.stage2_sparse_saved_count"),
        "stage2_sparse_boundary_dense_count": _pick(record, "workload.stage2_sparse_boundary_dense_count"),
        "stage2_sparse_fallback_full": _pick(record, "workload.stage2_sparse_fallback_full"),
        "stage2_sparse_trigger_eval_ms": _pick(record, "workload.stage2_sparse_trigger_eval_ms"),
        "stage2_sparse_trigger_fallback_model_raw": _pick(record, "workload.stage2_sparse_trigger_fallback_model_raw"),
        "rule_frame_count": _pick(record, "workload.rule_frame_count"),
        "rendered_frame_count": _pick(record, "workload.rendered_frame_count"),
        "gif_frame_count": _pick(record, "workload.gif_frame_count"),
        "source_video_read_decode_ms": source_video_read_decode_ms,
        "source_video_read_decode_time": _duration_text_from_ms(source_video_read_decode_ms),
        "stage1_source_video_read_decode_ms": stage1_source_video_read_decode_ms,
        "stage1_source_video_read_decode_time": _duration_text_from_ms(stage1_source_video_read_decode_ms),
        "stage2_source_video_read_decode_ms": stage2_source_video_read_decode_ms,
        "stage2_source_video_read_decode_time": _duration_text_from_ms(stage2_source_video_read_decode_ms),
        "provider_source_video_read_decode_ms": provider_source_video_read_decode_ms,
        "provider_source_video_read_decode_time": _duration_text_from_ms(provider_source_video_read_decode_ms),
        "source_video_read_call_count": _pick(record, "workload.source_video_read_call_count"),
        "source_video_read_frame_count": _pick(record, "workload.source_video_read_frame_count"),
        "source_video_yield_frame_count": _pick(record, "workload.source_video_yield_frame_count"),
        "video_total_ms": video_total_ms,
        "video_total_sec": round(video_total_ms / 1000.0, 3),
        "video_total_time": _duration_text_from_ms(video_total_ms),
        "local_processing_ms_exclude_callback": local_processing_ms,
        "local_processing_time_exclude_callback": _duration_text_from_ms(local_processing_ms),
        "video_prepare_ms": video_prepare_ms,
        "video_prepare_time": _duration_text_from_ms(video_prepare_ms),
        "stage1_stream_infer_ms": stage1_stream_infer_ms,
        "stage1_stream_infer_time": _duration_text_from_ms(stage1_stream_infer_ms),
        "target_select_ms": target_select_ms,
        "target_select_time": _duration_text_from_ms(target_select_ms),
        "stage2_stream_infer_ms": stage2_stream_infer_ms,
        "stage2_stream_infer_time": _duration_text_from_ms(stage2_stream_infer_ms),
        "rule_execute_ms": rule_execute_ms,
        "rule_execute_time": _duration_text_from_ms(rule_execute_ms),
        "rule_render_ms": rule_render_ms,
        "rule_render_time": _duration_text_from_ms(rule_render_ms),
        "rule_result_read_ms": rule_result_read_ms,
        "rule_result_read_time": _duration_text_from_ms(rule_result_read_ms),
        "frame_assembly_ms": frame_assembly_ms,
        "frame_assembly_time": _duration_text_from_ms(frame_assembly_ms),
        "testoutput_save_ms": testoutput_save_ms,
        "testoutput_save_time": _duration_text_from_ms(testoutput_save_ms),
        "protocol_materialize_ms": protocol_materialize_ms,
        "protocol_materialize_time": _duration_text_from_ms(protocol_materialize_ms),
        "alarm_callback_ms": callback_ms,
        "alarm_callback_time": _duration_text_from_ms(callback_ms),
        "video_release_ms": video_release_ms,
        "video_release_time": _duration_text_from_ms(video_release_ms),
        "result_json_path": _pick(record, "artifacts.result_json_path"),
        "text_log_path": _pick(record, "artifacts.text_log_path"),
        "select_img_path": _pick(record, "artifacts.select_img_path"),
        "original_img_path": _pick(record, "artifacts.original_img_path"),
        "roi_img_path": _pick(record, "artifacts.roi_img_path"),
        "original_gif_path": _pick(record, "artifacts.original_gif_path"),
        "rendered_gif_path": _pick(record, "artifacts.rendered_gif_path"),
        "alarm_video_path": _pick(record, "artifacts.alarm_video_path"),
        "alarm_sample_index": _pick(record, "alarm_frame.sample_index"),
        "alarm_matched_label": _pick(record, "alarm_frame.matched_label"),
        "alarm_priority_rank": _pick(record, "alarm_frame.priority_rank"),
        "callback_attempted": _pick(record, "callback.alarm_callback_attempted"),
        "callback_status_code": _pick(record, "callback.alarm_callback_status_code"),
        "callback_error": _pick(record, "callback.alarm_callback_error"),
        "started_at": _pick(record, "started_at"),
        "ended_at": _pick(record, "ended_at"),
        "created_at": _pick(record, "created_at"),
        "timezone": _pick(record, "timezone"),
        "error_message": _pick(record, "error_message"),
    }
    return row


def _stage_row(record: Mapping[str, object]) -> Dict[str, object]:
    workload = record.get("workload") if isinstance(record.get("workload"), Mapping) else {}
    detail = record.get("detail") if isinstance(record.get("detail"), Mapping) else {}
    resource = record.get("resource") if isinstance(record.get("resource"), Mapping) else {}
    timing_detail = record.get("timing_detail_ms") if isinstance(record.get("timing_detail_ms"), Mapping) else {}
    duration_ms = _to_int(_pick(record, "duration_ms", default=0), 0)
    source_video_read_decode_ms = _pick(timing_detail, "source_video_read_decode_ms", default="")
    row = {
        "trace_id": _pick(record, "trace_id"),
        "run_id": _pick(record, "run_id"),
        "task_id": _pick(record, "task_id"),
        "request_id": _pick(record, "request_id"),
        "instance_id": _pick(record, "instance_id"),
        "video_index": _pick(record, "video_index"),
        "machine_type": _pick(record, "machine_type"),
        "eqp_id": _pick(record, "eqp_id"),
        "chamber": _pick(record, "chamber"),
        "wafer_id": _pick(record, "wafer_id"),
        "raw_video_path": _pick(record, "raw_video_path"),
        "local_video_path": _pick(record, "local_video_path"),
        "stage_order": _pick(record, "stage_order"),
        "stage_key": _pick(record, "stage_key"),
        "stage_name": _pick(record, "stage_name"),
        "status": _pick(record, "status"),
        "duration_ms": duration_ms,
        "duration_sec": round(duration_ms / 1000.0, 3),
        "duration_time": _duration_text_from_ms(duration_ms),
        "started_at": _pick(record, "started_at"),
        "ended_at": _pick(record, "ended_at"),
        "created_at": _pick(record, "created_at"),
        "frame_count": _pick(workload, "frame_count", default=""),
        "decoded_frame_count": _pick(workload, "decoded_frame_count", default=""),
        "processed_frame_count": _pick(workload, "processed_frame_count", default=""),
        "target_count": _pick(workload, "target_count", default=""),
        "output_count": _pick(workload, "output_count", default=""),
        "stage1_frame_count": _pick(workload, "stage1_frame_count", default=""),
        "stage1_hit_count": _pick(workload, "stage1_hit_count", default=""),
        "stage2_decode_frame_count": _pick(workload, "stage2_decode_frame_count", default=""),
        "stage2_target_frame_count": _pick(workload, "stage2_target_frame_count", default=""),
        "stage2_processed_frame_count": _pick(workload, "stage2_processed_frame_count", default=""),
        "stage2_skipped_frame_count": _pick(workload, "stage2_skipped_frame_count", default=""),
        # [2#稀疏补推][生产迭代01]
        # 修改人: Shiver; 修改时间: 2026-06-25;
        # 修改逻辑: stage明细行展开2#稀疏补推字段。
        "stage2_sparse_enabled": _pick(workload, "stage2_sparse_enabled", default=""),
        "stage2_sparse_stride": _pick(workload, "stage2_sparse_stride", default=""),
        "stage2_sparse_trigger_mode": _pick(workload, "stage2_sparse_trigger_mode", default=""),
        "stage2_sparse_initial_count": _pick(workload, "stage2_sparse_initial_count", default=""),
        "stage2_sparse_model_raw_hit_count": _pick(workload, "stage2_sparse_model_raw_hit_count", default=""),
        "stage2_sparse_rule3_hit_count": _pick(workload, "stage2_sparse_rule3_hit_count", default=""),
        "stage2_sparse_hit_count": _pick(workload, "stage2_sparse_hit_count", default=""),
        "stage2_sparse_refine_count": _pick(workload, "stage2_sparse_refine_count", default=""),
        "stage2_sparse_final_count": _pick(workload, "stage2_sparse_final_count", default=""),
        "stage2_sparse_saved_count": _pick(workload, "stage2_sparse_saved_count", default=""),
        "stage2_sparse_boundary_dense_count": _pick(workload, "stage2_sparse_boundary_dense_count", default=""),
        "stage2_sparse_fallback_full": _pick(workload, "stage2_sparse_fallback_full", default=""),
        "stage2_sparse_trigger_eval_ms": _pick(workload, "stage2_sparse_trigger_eval_ms", default=""),
        "stage2_sparse_trigger_fallback_model_raw": _pick(workload, "stage2_sparse_trigger_fallback_model_raw", default=""),
        "missing_count": _pick(workload, "missing_count", default=""),
        "render_target_frame_count": _pick(workload, "render_target_frame_count", default=""),
        "rendered_frame_count": _pick(workload, "rendered_frame_count", default=""),
        "image_write_count": _pick(workload, "image_write_count", default=""),
        "gif_frame_count": _pick(workload, "gif_frame_count", default=""),
        "copy_bytes": _pick(workload, "copy_bytes", "source_size_bytes", default=""),
        "queue_limit": _pick(workload, "queue_limit", default=""),
        "pending_peak": _pick(workload, "pending_peak", default=""),
        "resident_raw_frames": _pick(workload, "resident_raw_frames", default=""),
        "source_is_probable_nas": _pick(timing_detail, "source_is_probable_nas", default=""),
        "source_mount_type": _pick(timing_detail, "source_mount_type", default=""),
        "source_mount_point": _pick(timing_detail, "source_mount_point", default=""),
        "source_mount_source": _pick(timing_detail, "source_mount_source", default=""),
        "source_video_safe_path_ms": _pick(timing_detail, "source_video_safe_path_ms", default=""),
        "source_video_open_ms": _pick(timing_detail, "source_video_open_ms", default=""),
        "source_video_metadata_ms": _pick(timing_detail, "source_video_metadata_ms", default=""),
        "source_video_seek_ms": _pick(timing_detail, "source_video_seek_ms", default=""),
        "source_video_read_call_count": _pick(timing_detail, "source_video_read_call_count", default=""),
        "source_video_read_frame_count": _pick(timing_detail, "source_video_read_frame_count", default=""),
        "source_video_yield_frame_count": _pick(timing_detail, "source_video_yield_frame_count", default=""),
        "source_video_read_decode_ms": source_video_read_decode_ms,
        "source_video_read_decode_time": _duration_text_from_ms(source_video_read_decode_ms),
        "source_video_read_decode_avg_ms": _pick(timing_detail, "source_video_read_decode_avg_ms", default=""),
        "source_video_read_decode_max_ms": _pick(timing_detail, "source_video_read_decode_max_ms", default=""),
        "source_video_first_frame_read_ms": _pick(timing_detail, "source_video_first_frame_read_ms", default=""),
        "memory_usage_bytes": _pick(resource, "memory_usage_bytes", "memory_end_bytes", default=""),
        "pids": _pick(resource, "pids", "pids_end", default=""),
        "python_threads": _pick(resource, "python_threads", "python_threads_end", default=""),
        "timing_detail_json": _json_text(timing_detail),
        "detail_json": _json_text(detail),
        "resource_json": _json_text(resource),
        "error_message": _pick(record, "error_message"),
    }
    return row


def _write_csv(path: Path, columns: Sequence[str], rows: Iterable[Mapping[str, object]], encoding: str) -> int:
    path.parent.mkdir(parents=True, exist_ok=True)
    count = 0
    with path.open("w", encoding=encoding, newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(columns), extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow({key: _json_text(row.get(key, "")) for key in columns})
            count += 1
    return count


def _load_records(files: Sequence[Path], start_dt: datetime, end_dt: datetime) -> Tuple[List[dict], List[dict], Dict[str, int]]:
    stats = {
        "input_file_count": len(files),
        "input_line_count": 0,
        "parsed_record_count": 0,
        "json_parse_error_lines": 0,
        "non_object_lines": 0,
        "out_of_range_record_count": 0,
        "summary_duplicate_count": 0,
        "other_record_count": 0,
    }
    summaries_by_trace: "OrderedDict[str, dict]" = OrderedDict()
    stages: List[dict] = []
    for file_path in files:
        with file_path.open("r", encoding="utf-8", errors="replace") as f:
            for line_no, line in enumerate(f, start=1):
                stats["input_line_count"] += 1
                text = line.strip()
                if not text:
                    continue
                try:
                    record = json.loads(text)
                except json.JSONDecodeError:
                    stats["json_parse_error_lines"] += 1
                    continue
                if not isinstance(record, dict):
                    stats["non_object_lines"] += 1
                    continue
                if not _record_in_range(record, start_dt, end_dt):
                    stats["out_of_range_record_count"] += 1
                    continue
                stats["parsed_record_count"] += 1
                record["_source_file"] = str(file_path)
                record["_source_line"] = line_no
                record_type = str(record.get("record_type") or "").strip()
                if record_type == "video_summary":
                    trace_id = str(record.get("trace_id") or f"{file_path}:{line_no}")
                    if trace_id in summaries_by_trace:
                        stats["summary_duplicate_count"] += 1
                    summaries_by_trace[trace_id] = record
                elif record_type == "video_stage":
                    stages.append(record)
                else:
                    stats["other_record_count"] += 1
    summaries = list(summaries_by_trace.values())
    return summaries, stages, stats


def _sort_summary_rows(rows: List[Dict[str, object]]) -> List[Dict[str, object]]:
    return sorted(
        rows,
        key=lambda row: (
            str(row.get("started_at") or row.get("created_at") or ""),
            str(row.get("instance_id") or ""),
            _to_int(row.get("video_index"), 0),
            str(row.get("trace_id") or ""),
        ),
    )


def _sort_stage_rows(rows: List[Dict[str, object]]) -> List[Dict[str, object]]:
    return sorted(
        rows,
        key=lambda row: (
            str(row.get("trace_id") or ""),
            _to_int(row.get("stage_order"), 0),
            str(row.get("started_at") or row.get("created_at") or ""),
            str(row.get("stage_key") or ""),
        ),
    )


def _summary_metric_rows(
    *,
    env: str,
    trace_root: Path,
    start_dt: datetime,
    end_dt: datetime,
    files: Sequence[Path],
    stats: Mapping[str, int],
    summary_rows: Sequence[Mapping[str, object]],
    stage_rows: Sequence[Mapping[str, object]],
) -> List[Dict[str, object]]:
    video_count = len(summary_rows)
    alarm_count = sum(1 for row in summary_rows if str(row.get("is_alarm")).lower() == "true")
    failed_count = sum(1 for row in summary_rows if str(row.get("video_status")).lower() == "failed" or str(row.get("protocol_status")).lower() == "internal_error")
    normal_count = sum(1 for row in summary_rows if str(row.get("protocol_status")).lower() == "normal")
    ok_count = sum(1 for row in summary_rows if str(row.get("overall_result")).upper() == "OK")
    ng_count = sum(1 for row in summary_rows if str(row.get("overall_result")).upper() == "NG")
    callback_attempted_count = sum(1 for row in summary_rows if str(row.get("callback_attempted")).lower() == "true")
    callback_success_count = sum(1 for row in summary_rows if 200 <= _to_int(row.get("callback_status_code"), 0) < 300)
    total_ms = [_to_float(row.get("video_total_ms")) for row in summary_rows if _to_float(row.get("video_total_ms")) > 0]
    local_ms = [_to_float(row.get("local_processing_ms_exclude_callback")) for row in summary_rows if _to_float(row.get("local_processing_ms_exclude_callback")) > 0]
    source_read_ms = [_to_float(row.get("source_video_read_decode_ms")) for row in summary_rows if _to_float(row.get("source_video_read_decode_ms")) > 0]
    time_window_ms = max(0.0, (end_dt - start_dt).total_seconds() * 1000.0)

    def metric(name: str, value: object, description: str = "") -> Dict[str, object]:
        return {"metric": name, "value": value, "description": description}

    # [视频处理耗时复盘JSONL][离线汇总03-宿主机一键汇总]
    # 修改人: Shiver; 修改时间: 2026-06-24;
    # 修改逻辑: 总览只保留现场优先判断需要的核心指标，避免第一眼看到过多低优先级统计。
    rows = [
        metric("env", env, "online=生产；test=测试"),
        metric("time_start", start_dt.strftime("%Y-%m-%d %H:%M:%S"), "过滤开始时间，闭区间"),
        metric("time_end", end_dt.strftime("%Y-%m-%d %H:%M:%S"), "过滤结束时间，闭区间"),
        metric("generated_at", datetime.now().strftime("%Y-%m-%d %H:%M:%S"), "报表生成时间"),
        metric("time_window", _duration_text_from_ms(time_window_ms), "本次统计覆盖的自然时间窗口"),
        metric("trace_root", str(trace_root), "本次读取的 JSONL 根目录"),
        metric("input_file_count", len(files), "命中的 JSONL 文件数"),
        metric("video_count", video_count, "单视频 video_summary 总数"),
        metric("alarm_video_count", alarm_count, "protocol_status=alarm 或 overall_result=NG"),
        metric("alarm_rate", round(alarm_count / video_count, 6) if video_count else "", "alarm_video_count / video_count"),
        metric("normal_video_count", normal_count, "protocol_status=normal"),
        metric("failed_video_count", failed_count, "video_status=failed 或 protocol_status=internal_error"),
        metric("ok_video_count", ok_count, "overall_result=OK"),
        metric("ng_video_count", ng_count, "overall_result=NG"),
        metric("sum_video_total_time", _duration_text_from_ms(sum(total_ms)), "所有视频单视频总耗时累计；用于看总工作量，不等于墙钟耗时"),
        metric("avg_video_total_time", _duration_text_from_ms(_avg(total_ms)), "平均单视频总耗时，可读格式"),
        metric("p50_video_total_time", _duration_text_from_ms(_percentile(total_ms, 0.50)), "单视频总耗时 P50，可读格式"),
        metric("p90_video_total_time", _duration_text_from_ms(_percentile(total_ms, 0.90)), "单视频总耗时 P90，可读格式"),
        metric("max_video_total_time", _duration_text_from_ms(max(total_ms) if total_ms else ""), "单视频总耗时最大值，可读格式"),
        metric("sum_local_processing_time_exclude_callback", _duration_text_from_ms(sum(local_ms)), "剔除告警回调后的本地处理累计耗时"),
        metric("avg_local_processing_time_exclude_callback", _duration_text_from_ms(_avg(local_ms)), "剔除告警回调后的平均本地耗时，可读格式"),
        metric("p90_local_processing_time_exclude_callback", _duration_text_from_ms(_percentile(local_ms, 0.90)), "剔除告警回调后的本地耗时 P90，可读格式"),
        # [视频处理耗时复盘JSONL][NAS读取诊断01]
        # 修改人: Shiver; 修改时间: 2026-06-24;
        # 修改逻辑: 总览增加源视频读取+解码核心统计，现场优先判断 NAS/解码是否是主要瓶颈。
        metric("sum_source_video_read_decode_time", _duration_text_from_ms(sum(source_read_ms)), "所有视频源AVI读取+OpenCV解码累计耗时；不等于纯网络延迟"),
        metric("avg_source_video_read_decode_time", _duration_text_from_ms(_avg(source_read_ms)), "平均单视频源AVI读取+解码耗时"),
        metric("p90_source_video_read_decode_time", _duration_text_from_ms(_percentile(source_read_ms, 0.90)), "单视频源AVI读取+解码耗时 P90"),
        metric("max_source_video_read_decode_time", _duration_text_from_ms(max(source_read_ms) if source_read_ms else ""), "单视频源AVI读取+解码耗时最大值"),
        metric("callback_attempted_video_count", callback_attempted_count, "尝试告警回调的视频数"),
        metric("callback_success_video_count", callback_success_count, "HTTP 2xx 回调视频数"),
        metric("total_stage1_frame_count", sum(_to_int(row.get("stage1_frame_count"), 0) for row in summary_rows), "1# 总处理帧数"),
        metric("total_stage1_hit_count", sum(_to_int(row.get("stage1_hit_count"), 0) for row in summary_rows), "1# 总命中帧数"),
        metric("total_stage2_target_frame_count", sum(_to_int(row.get("stage2_target_frame_count"), 0) for row in summary_rows), "2# 总目标帧数"),
        metric("total_stage2_processed_frame_count", sum(_to_int(row.get("stage2_processed_frame_count"), 0) for row in summary_rows), "2# 总实际推理帧数"),
        # [2#稀疏补推][生产迭代01]
        # 修改人: Shiver; 修改时间: 2026-06-25;
        # 修改逻辑: 总览直接输出2#稀疏补推节省量和回退次数，现场快速判断优化是否生效。
        metric("stage2_sparse_enabled_video_count", sum(1 for row in summary_rows if str(row.get("stage2_sparse_enabled")).lower() == "true"), "启用2#稀疏补推的视频数"),
        metric("total_stage2_sparse_initial_count", sum(_to_int(row.get("stage2_sparse_initial_count"), 0) for row in summary_rows), "2# 稀疏扫描总帧数"),
        metric("total_stage2_sparse_model_raw_hit_count", sum(_to_int(row.get("stage2_sparse_model_raw_hit_count"), 0) for row in summary_rows), "2# 原始模型命中总帧数"),
        metric("total_stage2_sparse_rule3_hit_count", sum(_to_int(row.get("stage2_sparse_rule3_hit_count"), 0) for row in summary_rows), "2# 经过rule3过滤后的命中总帧数"),
        metric("total_stage2_sparse_hit_count", sum(_to_int(row.get("stage2_sparse_hit_count"), 0) for row in summary_rows), "2# 稀疏扫描命中总帧数"),
        metric("total_stage2_sparse_refine_count", sum(_to_int(row.get("stage2_sparse_refine_count"), 0) for row in summary_rows), "2# 命中后补推总帧数"),
        metric("total_stage2_sparse_saved_count", sum(_to_int(row.get("stage2_sparse_saved_count"), 0) for row in summary_rows), "2# 相对目标帧节省的推理帧数"),
        metric("stage2_sparse_fallback_full_count", sum(1 for row in summary_rows if str(row.get("stage2_sparse_fallback_full")).lower() == "true"), "2# 稀疏命中率过高回退全量的视频数"),
        metric("total_stage2_sparse_trigger_eval_time", _duration_text_from_ms(sum(_to_float(row.get("stage2_sparse_trigger_eval_ms")) for row in summary_rows)), "C组rule3触发预判累计耗时"),
        metric("avg_stage2_sparse_trigger_eval_time", _duration_text_from_ms(_avg([_to_float(row.get("stage2_sparse_trigger_eval_ms")) for row in summary_rows if _to_float(row.get("stage2_sparse_trigger_eval_ms")) > 0])), "C组rule3触发预判平均耗时"),
        metric("stage2_sparse_trigger_fallback_model_raw_count", sum(1 for row in summary_rows if str(row.get("stage2_sparse_trigger_fallback_model_raw")).lower() == "true"), "rule3触发预判异常后回退model_raw的视频数"),
        metric("stage_record_count", len(stage_rows), "video_stage 明细记录数"),
        metric("json_parse_error_lines", stats.get("json_parse_error_lines", 0), "JSON 损坏行数"),
        metric("summary_duplicate_count", stats.get("summary_duplicate_count", 0), "同 trace_id 重复 summary 数，汇总时保留最后一条"),
    ]
    return rows


def _machine_aggregate_rows(summary_rows: Sequence[Mapping[str, object]]) -> List[Dict[str, object]]:
    groups: MutableMapping[Tuple[str, str, str], List[Mapping[str, object]]] = defaultdict(list)
    for row in summary_rows:
        key = (
            str(row.get("machine_type") or ""),
            str(row.get("eqp_id") or ""),
            str(row.get("chamber") or ""),
        )
        groups[key].append(row)
    output: List[Dict[str, object]] = []
    for (machine_type, eqp_id, chamber), rows in sorted(groups.items()):
        total_ms = [_to_float(row.get("video_total_ms")) for row in rows if _to_float(row.get("video_total_ms")) > 0]
        local_ms = [_to_float(row.get("local_processing_ms_exclude_callback")) for row in rows if _to_float(row.get("local_processing_ms_exclude_callback")) > 0]
        video_count = len(rows)
        alarm_count = sum(1 for row in rows if str(row.get("is_alarm")).lower() == "true")
        output.append(
            {
                "machine_type": machine_type,
                "eqp_id": eqp_id,
                "chamber": chamber,
                "video_count": video_count,
                "alarm_video_count": alarm_count,
                "normal_video_count": sum(1 for row in rows if str(row.get("protocol_status")).lower() == "normal"),
                "failed_video_count": sum(1 for row in rows if str(row.get("video_status")).lower() == "failed" or str(row.get("protocol_status")).lower() == "internal_error"),
                "alarm_rate": round(alarm_count / video_count, 6) if video_count else "",
                "avg_video_total_time": _duration_text_from_ms(_avg(total_ms)),
                "p50_video_total_time": _duration_text_from_ms(_percentile(total_ms, 0.50)),
                "p90_video_total_time": _duration_text_from_ms(_percentile(total_ms, 0.90)),
                "max_video_total_time": _duration_text_from_ms(max(total_ms) if total_ms else ""),
                "avg_video_total_ms": _avg(total_ms),
                "p50_video_total_ms": _percentile(total_ms, 0.50),
                "p90_video_total_ms": _percentile(total_ms, 0.90),
                "max_video_total_ms": max(total_ms) if total_ms else "",
                "avg_local_processing_time_exclude_callback": _duration_text_from_ms(_avg(local_ms)),
                "avg_local_processing_ms_exclude_callback": _avg(local_ms),
                "avg_duration_sec": _avg([_to_float(row.get("duration_sec")) for row in rows if _to_float(row.get("duration_sec")) > 0]),
                "avg_source_frame_count": _avg([_to_float(row.get("source_frame_count")) for row in rows if _to_float(row.get("source_frame_count")) > 0]),
                "avg_stage1_frame_count": _avg([_to_float(row.get("stage1_frame_count")) for row in rows if _to_float(row.get("stage1_frame_count")) > 0]),
                "avg_stage1_hit_count": _avg([_to_float(row.get("stage1_hit_count")) for row in rows if _to_float(row.get("stage1_hit_count")) > 0]),
                "avg_stage2_target_frame_count": _avg([_to_float(row.get("stage2_target_frame_count")) for row in rows if _to_float(row.get("stage2_target_frame_count")) > 0]),
                "avg_stage2_processed_frame_count": _avg([_to_float(row.get("stage2_processed_frame_count")) for row in rows if _to_float(row.get("stage2_processed_frame_count")) > 0]),
            }
        )
    return output


def _stage_aggregate_rows(stage_rows: Sequence[Mapping[str, object]]) -> List[Dict[str, object]]:
    groups: MutableMapping[str, List[Mapping[str, object]]] = defaultdict(list)
    for row in stage_rows:
        groups[str(row.get("stage_key") or "")].append(row)
    output: List[Dict[str, object]] = []
    for stage_key, rows in sorted(groups.items(), key=lambda item: min(_to_int(row.get("stage_order"), 0) for row in item[1]) if item[1] else 0):
        durations = [_to_float(row.get("duration_ms")) for row in rows if _to_float(row.get("duration_ms")) > 0]
        source_read_ms = [_to_float(row.get("source_video_read_decode_ms")) for row in rows if _to_float(row.get("source_video_read_decode_ms")) > 0]
        source_open_ms = [_to_float(row.get("source_video_open_ms")) for row in rows if _to_float(row.get("source_video_open_ms")) > 0]
        source_metadata_ms = [_to_float(row.get("source_video_metadata_ms")) for row in rows if _to_float(row.get("source_video_metadata_ms")) > 0]
        source_seek_ms = [_to_float(row.get("source_video_seek_ms")) for row in rows if _to_float(row.get("source_video_seek_ms")) > 0]
        stage_name = next((str(row.get("stage_name") or "") for row in rows if row.get("stage_name")), "")
        output.append(
            {
                "stage_key": stage_key,
                "stage_name": stage_name,
                "min_stage_order": min(_to_int(row.get("stage_order"), 0) for row in rows) if rows else "",
                "record_count": len(rows),
                "success_count": sum(1 for row in rows if str(row.get("status")).lower() == "success"),
                "skipped_count": sum(1 for row in rows if str(row.get("status")).lower() == "skipped"),
                "failed_count": sum(1 for row in rows if str(row.get("status")).lower() == "failed"),
                "total_duration_time": _duration_text_from_ms(sum(durations)),
                "avg_duration_time": _duration_text_from_ms(_avg(durations)),
                "p50_duration_time": _duration_text_from_ms(_percentile(durations, 0.50)),
                "p90_duration_time": _duration_text_from_ms(_percentile(durations, 0.90)),
                "max_duration_time": _duration_text_from_ms(max(durations) if durations else ""),
                "total_duration_ms": sum(durations),
                "avg_duration_ms": _avg(durations),
                "p50_duration_ms": _percentile(durations, 0.50),
                "p90_duration_ms": _percentile(durations, 0.90),
                "max_duration_ms": max(durations) if durations else "",
                "avg_frame_count": _avg([_to_float(row.get("frame_count")) for row in rows if _to_float(row.get("frame_count")) > 0]),
                "avg_stage2_target_frame_count": _avg([_to_float(row.get("stage2_target_frame_count")) for row in rows if _to_float(row.get("stage2_target_frame_count")) > 0]),
                "avg_stage2_processed_frame_count": _avg([_to_float(row.get("stage2_processed_frame_count")) for row in rows if _to_float(row.get("stage2_processed_frame_count")) > 0]),
                # [2#稀疏补推][生产迭代01]
                # 修改人: Shiver; 修改时间: 2026-06-25;
                # 修改逻辑: 阶段聚合输出2#稀疏补推平均值/总节省/回退次数，辅助对比stage2_stream_infer。
                "avg_stage2_sparse_initial_count": _avg([_to_float(row.get("stage2_sparse_initial_count")) for row in rows if _to_float(row.get("stage2_sparse_initial_count")) > 0]),
                "avg_stage2_sparse_model_raw_hit_count": _avg([_to_float(row.get("stage2_sparse_model_raw_hit_count")) for row in rows if _to_float(row.get("stage2_sparse_model_raw_hit_count")) > 0]),
                "avg_stage2_sparse_rule3_hit_count": _avg([_to_float(row.get("stage2_sparse_rule3_hit_count")) for row in rows if _to_float(row.get("stage2_sparse_rule3_hit_count")) > 0]),
                "avg_stage2_sparse_refine_count": _avg([_to_float(row.get("stage2_sparse_refine_count")) for row in rows if _to_float(row.get("stage2_sparse_refine_count")) > 0]),
                "avg_stage2_sparse_final_count": _avg([_to_float(row.get("stage2_sparse_final_count")) for row in rows if _to_float(row.get("stage2_sparse_final_count")) > 0]),
                "avg_stage2_sparse_saved_count": _avg([_to_float(row.get("stage2_sparse_saved_count")) for row in rows if _to_float(row.get("stage2_sparse_saved_count")) > 0]),
                "total_stage2_sparse_saved_count": sum(_to_int(row.get("stage2_sparse_saved_count"), 0) for row in rows),
                "stage2_sparse_fallback_full_count": sum(1 for row in rows if str(row.get("stage2_sparse_fallback_full")).lower() == "true"),
                "avg_stage2_sparse_trigger_eval_ms": _avg([_to_float(row.get("stage2_sparse_trigger_eval_ms")) for row in rows if _to_float(row.get("stage2_sparse_trigger_eval_ms")) > 0]),
                "total_stage2_sparse_trigger_eval_ms": sum(_to_float(row.get("stage2_sparse_trigger_eval_ms")) for row in rows),
                "stage2_sparse_trigger_fallback_model_raw_count": sum(1 for row in rows if str(row.get("stage2_sparse_trigger_fallback_model_raw")).lower() == "true"),
                "avg_render_target_frame_count": _avg([_to_float(row.get("render_target_frame_count")) for row in rows if _to_float(row.get("render_target_frame_count")) > 0]),
                "total_render_target_frame_count": sum(_to_int(row.get("render_target_frame_count"), 0) for row in rows),
                "total_rendered_frame_count": sum(_to_int(row.get("rendered_frame_count"), 0) for row in rows),
                "total_image_write_count": sum(_to_int(row.get("image_write_count"), 0) for row in rows),
                "total_gif_frame_count": sum(_to_int(row.get("gif_frame_count"), 0) for row in rows),
                "total_copy_bytes": sum(_to_int(row.get("copy_bytes"), 0) for row in rows),
                "total_source_video_read_decode_time": _duration_text_from_ms(sum(source_read_ms)),
                "avg_source_video_read_decode_time": _duration_text_from_ms(_avg(source_read_ms)),
                "p90_source_video_read_decode_time": _duration_text_from_ms(_percentile(source_read_ms, 0.90)),
                "max_source_video_read_decode_time": _duration_text_from_ms(max(source_read_ms) if source_read_ms else ""),
                "total_source_video_read_decode_ms": sum(source_read_ms),
                "avg_source_video_read_decode_ms": _avg(source_read_ms),
                "p90_source_video_read_decode_ms": _percentile(source_read_ms, 0.90),
                "max_source_video_read_decode_ms": max(source_read_ms) if source_read_ms else "",
                "total_source_video_read_call_count": sum(_to_int(row.get("source_video_read_call_count"), 0) for row in rows),
                "total_source_video_read_frame_count": sum(_to_int(row.get("source_video_read_frame_count"), 0) for row in rows),
                "total_source_video_open_time": _duration_text_from_ms(sum(source_open_ms)),
                "avg_source_video_open_time": _duration_text_from_ms(_avg(source_open_ms)),
                "total_source_video_metadata_time": _duration_text_from_ms(sum(source_metadata_ms)),
                "avg_source_video_metadata_time": _duration_text_from_ms(_avg(source_metadata_ms)),
                "total_source_video_seek_time": _duration_text_from_ms(sum(source_seek_ms)),
                "avg_source_video_seek_time": _duration_text_from_ms(_avg(source_seek_ms)),
            }
        )
    return output


def _safe_archive_part(value: object, default: str = "unknown") -> str:
    text = str(value or "").strip() or default
    cleaned = "".join(ch if ch.isalnum() or ch in {"-", "_", "."} else "_" for ch in text)
    cleaned = cleaned.strip("._-")
    return cleaned or default


def _alarm_asset_zip_path(row: Mapping[str, object], source_path: Path) -> str:
    # [视频处理耗时复盘JSONL][离线汇总03-宿主机一键汇总]
    # 修改人: Shiver; 修改时间: 2026-06-24;
    # 修改逻辑: alarm 资产在 ZIP 中保留原文件名，只按机台号建一级目录，避免 trace_id/资产类型目录造成现场复核困难。
    eqp_part = _safe_archive_part(row.get("eqp_id"), "unknown_eqp")
    return f"{eqp_part}/{source_path.name}"


def _alarm_asset_manifest_rows(alarm_rows: Sequence[Mapping[str, object]]) -> List[Dict[str, object]]:
    """Build manifest rows for alarm GIF/video assets.

    [视频处理耗时复盘JSONL][离线汇总02]
    修改人: Shiver; 修改时间: 2026-06-24;
    修改逻辑: 默认把所有 alarm 视频对应的原始 GIF、渲染 GIF、告警视频纳入 ZIP 打包清单；
    文件缺失只记录清单，不中断 CSV 汇总。
    """
    asset_fields = (
        ("select_jpg", "select_img_path"),
        ("original_jpg", "original_img_path"),
        ("roi_jpg", "roi_img_path"),
        ("original_gif", "original_gif_path"),
        ("rendered_gif", "rendered_gif_path"),
        ("alarm_video", "alarm_video_path"),
    )
    output: List[Dict[str, object]] = []
    for row in alarm_rows:
        for asset_type, column in asset_fields:
            source_path = str(row.get(column) or "").strip()
            path = Path(source_path) if source_path else None
            exists = bool(path and path.is_file())
            size = path.stat().st_size if exists and path is not None else 0
            zip_path = _alarm_asset_zip_path(row, path) if path is not None else ""
            error_message = "" if source_path else f"{column} empty"
            if source_path and not exists:
                error_message = "file not found"
            output.append(
                {
                    "trace_id": row.get("trace_id", ""),
                    "task_id": row.get("task_id", ""),
                    "instance_id": row.get("instance_id", ""),
                    "video_index": row.get("video_index", ""),
                    "eqp_id": row.get("eqp_id", ""),
                    "chamber": row.get("chamber", ""),
                    "wafer_id": row.get("wafer_id", ""),
                    "asset_type": asset_type,
                    "source_path": source_path,
                    "exists": exists,
                    "file_size_bytes": size,
                    "zip_path": zip_path,
                    "error_message": error_message,
                }
            )
    return output


def _write_package_zip(
    *,
    zip_path: Path,
    report_files: Sequence[Path],
    asset_rows: Sequence[Mapping[str, object]],
) -> Dict[str, object]:
    zip_path.parent.mkdir(parents=True, exist_ok=True)
    report_count = 0
    asset_count = 0
    missing_asset_count = 0
    error_count = 0
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED, allowZip64=True) as zf:
        for file_path in report_files:
            try:
                if file_path.is_file():
                    # [视频处理耗时复盘JSONL][离线汇总03-宿主机一键汇总]
                    # 修改人: Shiver; 修改时间: 2026-06-24;
                    # 修改逻辑: ZIP 内报表直接放根目录，减少现场打开压缩包后的查找层级。
                    zf.write(file_path, file_path.name)
                    report_count += 1
            except Exception as exc:
                error_count += 1
                print(f"{TRACE_PREFIX}[ZIP_WARN] report={file_path} error={exc}", file=sys.stderr)
        for row in asset_rows:
            source_path = Path(str(row.get("source_path") or ""))
            if not source_path.is_file():
                missing_asset_count += 1
                continue
            arcname = str(row.get("zip_path") or source_path.name)
            try:
                zf.write(source_path, arcname)
                asset_count += 1
            except Exception as exc:
                error_count += 1
                print(f"{TRACE_PREFIX}[ZIP_WARN] asset={source_path} error={exc}", file=sys.stderr)
    return {
        "zip_path": str(zip_path),
        "report_file_count": report_count,
        "asset_file_count": asset_count,
        "missing_asset_count": missing_asset_count,
        "zip_error_count": error_count,
        "zip_size_bytes": zip_path.stat().st_size if zip_path.is_file() else 0,
    }


def _write_readme(
    path: Path,
    outputs: Mapping[str, Path],
    args: argparse.Namespace,
    start_dt: datetime,
    end_dt: datetime,
    *,
    zip_path: Optional[Path] = None,
) -> None:
    content = [
        "infer-cache 视频处理耗时离线汇总说明",
        "",
        f"生成时间：{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        f"环境：{args.env}",
        f"时间范围：{start_dt.strftime('%Y-%m-%d %H:%M:%S')} ~ {end_dt.strftime('%Y-%m-%d %H:%M:%S')}",
        f"CSV only：{bool(args.csv_only)}",
        "",
        "文件说明：",
        "00_总览.csv：核心总览，优先看视频数、alarm 数、失败数、累计/平均/P90/P最大耗时。",
        "01_alarm汇总表.csv：仅保留 alarm/NG 视频，含业务信息、耗时、告警图片/GIF/AVI 路径和回调状态。",
        "02_阶段耗时统计.csv：按 stage_key 聚合，定位慢在 1#、2#、规则、渲染、GIF、视频复制还是回调。",
        "03_视频明细.csv：一行一个视频，保留关键业务字段、关键耗时和产物路径。",
        "04_阶段耗时明细.csv：仅 --include-detail 时输出；一行一个阶段，用 trace_id 钻取单条慢视频。",
        "05_alarm资产清单.csv：仅 --include-detail 时输出；记录每个 alarm 的 JPG/GIF/AVI 是否存在以及 ZIP 内路径。",
        "06_按机台腔室汇总.csv：仅 --include-detail 时输出；按 machine_type/eqp_id/chamber 聚合。",
        "",
        "耗时字段说明：",
        "*_time：默认现场查看字段，单位为秒；超过 1 分钟显示为 xminxs。",
        "*_ms：原始毫秒值，保留用于排序、筛选、二次分析。",
        "source_video_read_decode_time：源 AVI 读取+OpenCV/FFmpeg 解码耗时，不等于纯 NAS 网络延迟。",
        "stage1/stage2/provider_source_video_read_decode_time：分别对应 1#、2#、协议产物按需取原图的源视频读取+解码耗时。",
        "source_video_provider_read：诊断型 stage_key，duration_ms 固定为 0，只承载 provider 二次读取源 AVI 的统计，避免重复放大真实总耗时。",
        "",
        "时间过滤口径：",
        "视频汇总 video_summary：优先按 started_at 过滤，也就是单视频开始处理时间。",
        "阶段明细 video_stage：优先按阶段 started_at 过滤；如果该阶段没有 started_at，则按 created_at，即记录写入时间过滤。",
        "读取文件范围：脚本会先按 start/end 覆盖到的日期目录读取 JSONL，并额外扫描结束日期后 1 天，用于覆盖跨零点结束的视频 summary；随后再按上述记录时间做二次过滤。",
        "",
        "建议现场优先查看顺序：",
        "1. 00_总览.csv 看统计时间段内视频数、alarm 数、失败数、P90/P最大耗时。",
        "2. 02_阶段耗时统计.csv 看慢在 1#、2#、规则、渲染、GIF、视频复制还是回调。",
        "3. 01_alarm汇总表.csv 复核 alarm 视频、JPG/GIF/AVI 路径和回调状态。",
        "4. 03_视频明细.csv 按 video_total_ms 倒序查慢视频。",
        "",
        "输出文件：",
    ]
    for name, file_path in outputs.items():
        content.append(f"- {name}: {file_path}")
    if zip_path is not None:
        content.extend(
            [
                "",
                f"ZIP 打包文件：{zip_path}",
                "ZIP 内容：CSV/README 在根目录；alarm 资产按 机台号/原文件名 保存，包含 JPG、GIF、AVI。",
            ]
        )
    path.write_text("\n".join(content) + "\n", encoding="utf-8")


def _build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="汇总 infer-cache video_trace JSONL，生成现场可用 CSV 报表。",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument("--env", choices=("online", "test"), default="online", help="运行环境，用于选择默认 trace 根目录")
    parser.add_argument("--date", default="", help="选择某一天，支持 YYYY-MM-DD / YYYYMMDD；未传则默认今天")
    parser.add_argument("--start", default="", help="开始时间；可传完整时间 YYYY-MM-DD HH:MM:SS，也可配合 --date 只传 HH:MM:SS")
    parser.add_argument("--end", default="", help="结束时间；可传完整时间 YYYY-MM-DD HH:MM:SS，也可配合 --date 只传 HH:MM:SS")
    parser.add_argument("--trace-root", default="", help="手工指定 JSONL 根目录；不传则按 --env 自动选择")
    parser.add_argument("--output-root", default="", help="输出根目录；不传则写到脚本目录 output/<env>/ 下")
    parser.add_argument("--output-dir", default="", help="手工指定本次 report 目录；不传则自动命名")
    parser.add_argument("--pattern", default=DEFAULT_PATTERN, help="JSONL 文件名匹配模式")
    parser.add_argument("--encoding", default="utf-8-sig", help="CSV 编码；默认 utf-8-sig 便于 Excel 直接打开中文")
    parser.add_argument("--csv-only", action="store_true", help="只输出 CSV/README，不打包 alarm GIF/视频 ZIP")
    parser.add_argument("--keep-report", action="store_true", help="默认打包 ZIP 后删除未压缩 report 目录；加此参数保留 report 原始目录")
    parser.add_argument("--include-detail", action="store_true", help="额外输出阶段耗时明细、alarm 资产清单、按机台腔室汇总")
    parser.add_argument("--zip-path", default="", help="手工指定 ZIP 输出路径；默认与 output_dir 同名并加 .zip")
    return parser


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = _build_arg_parser()
    args = parser.parse_args(argv)
    try:
        start_dt, end_dt = _resolve_time_range(args)
    except ValueError as exc:
        print(f"{TRACE_PREFIX}[ERROR] {exc}", file=sys.stderr)
        return 2

    trace_root = Path(args.trace_root) if args.trace_root else DEFAULT_TRACE_ROOTS[args.env]
    export_dt = datetime.now()
    report_name = _safe_output_name(
        f"{args.env}_{start_dt.strftime('%Y%m%d%H%M%S')}-{end_dt.strftime('%Y%m%d%H%M%S')}_export{export_dt.strftime('%Y%m%d%H%M%S')}"
    )
    # [视频处理耗时复盘JSONL][离线汇总03-宿主机一键汇总]
    # 修改人: Shiver; 修改时间: 2026-06-24;
    # 修改逻辑: 默认输出到脚本目录 output/<online|test>/，宿主机 python3 直接运行即可，不再要求进入 docker bash。
    output_root_base = Path(args.output_root) if args.output_root else DEFAULT_OUTPUT_ROOT
    output_root = output_root_base / args.env
    output_dir = Path(args.output_dir) if args.output_dir else output_root / report_name
    zip_path = Path(args.zip_path) if args.zip_path else output_dir.parent / f"{report_name}.zip"
    files = _find_input_files(trace_root, start_dt, end_dt, args.pattern)
    if not files:
        print(f"{TRACE_PREFIX}[WARN] 未找到 JSONL 文件：root={trace_root} pattern={args.pattern}", file=sys.stderr)

    summaries, stages, stats = _load_records(files, start_dt, end_dt)
    summary_rows = _sort_summary_rows([_summary_row(record) for record in summaries])
    stage_rows = _sort_stage_rows([_stage_row(record) for record in stages])
    alarm_rows = [row for row in summary_rows if str(row.get("is_alarm")).lower() == "true"]

    outputs = OrderedDict(
        [
            ("总览", output_dir / "00_总览.csv"),
            ("alarm汇总表", output_dir / "01_alarm汇总表.csv"),
            ("阶段耗时统计", output_dir / "02_阶段耗时统计.csv"),
            ("视频明细", output_dir / "03_视频明细.csv"),
        ]
    )
    if args.include_detail:
        outputs.update(
            [
                ("阶段耗时明细", output_dir / "04_阶段耗时明细.csv"),
                ("alarm资产清单", output_dir / "05_alarm资产清单.csv"),
                ("按机台腔室汇总", output_dir / "06_按机台腔室汇总.csv"),
            ]
        )

    overview_rows = _summary_metric_rows(
        env=args.env,
        trace_root=trace_root,
        start_dt=start_dt,
        end_dt=end_dt,
        files=files,
        stats=stats,
        summary_rows=summary_rows,
        stage_rows=stage_rows,
    )
    stage_agg_rows = _stage_aggregate_rows(stage_rows)
    asset_manifest_rows = _alarm_asset_manifest_rows(alarm_rows)

    row_counts = OrderedDict()
    row_counts["总览"] = _write_csv(outputs["总览"], ["metric", "value", "description"], overview_rows, args.encoding)
    row_counts["alarm汇总表"] = _write_csv(outputs["alarm汇总表"], ALARM_COLUMNS, alarm_rows, args.encoding)
    row_counts["阶段耗时统计"] = _write_csv(outputs["阶段耗时统计"], STAGE_AGG_COLUMNS, stage_agg_rows, args.encoding)
    row_counts["视频明细"] = _write_csv(outputs["视频明细"], VIDEO_KEY_COLUMNS, summary_rows, args.encoding)
    if args.include_detail:
        machine_rows = _machine_aggregate_rows(summary_rows)
        row_counts["阶段耗时明细"] = _write_csv(outputs["阶段耗时明细"], STAGE_COLUMNS, stage_rows, args.encoding)
        row_counts["alarm资产清单"] = _write_csv(outputs["alarm资产清单"], ASSET_MANIFEST_COLUMNS, asset_manifest_rows, args.encoding)
        row_counts["按机台腔室汇总"] = _write_csv(outputs["按机台腔室汇总"], MACHINE_COLUMNS, machine_rows, args.encoding)
    readme_path = output_dir / "README_汇总说明.txt"
    _write_readme(readme_path, outputs, args, start_dt, end_dt, zip_path=None if args.csv_only else zip_path)

    zip_stats: Optional[Dict[str, object]] = None
    report_dir_removed = False
    if not args.csv_only:
        zip_stats = _write_package_zip(
            zip_path=zip_path,
            report_files=[*outputs.values(), readme_path],
            asset_rows=asset_manifest_rows,
        )
        if not args.keep_report and zip_path.is_file() and output_dir.is_dir():
            # [视频处理耗时复盘JSONL][离线汇总03-宿主机一键汇总]
            # 修改人: Shiver; 修改时间: 2026-06-24;
            # 修改逻辑: 默认只交付 ZIP，压缩成功后删除未压缩 report 目录，避免现场目录残留两份内容。
            if _path_is_inside(zip_path, output_dir):
                print(f"{TRACE_PREFIX}[WARN] zip_path 位于 report 目录内部，为避免误删 ZIP，本次保留 report_dir：{output_dir}", file=sys.stderr)
            else:
                shutil.rmtree(output_dir)
                report_dir_removed = True

    print(f"{TRACE_PREFIX}[DONE] output_dir={output_dir}")
    print(f"{TRACE_PREFIX}[DONE] video_count={len(summary_rows)} alarm_count={len(alarm_rows)} stage_count={len(stage_rows)} input_files={len(files)}")
    for name, path in outputs.items():
        if report_dir_removed:
            print(f"{TRACE_PREFIX}[DONE] {name} rows={row_counts.get(name, 0)} path_in_zip={path.name}")
        else:
            print(f"{TRACE_PREFIX}[DONE] {name} rows={row_counts.get(name, 0)} path={path}")
    if zip_stats is not None:
        print(
            f"{TRACE_PREFIX}[DONE] zip_path={zip_stats.get('zip_path')} "
            f"report_files={zip_stats.get('report_file_count')} "
            f"alarm_assets={zip_stats.get('asset_file_count')} "
            f"missing_assets={zip_stats.get('missing_asset_count')} "
            f"zip_errors={zip_stats.get('zip_error_count')} "
            f"zip_size_bytes={zip_stats.get('zip_size_bytes')}"
        )
    else:
        print(f"{TRACE_PREFIX}[DONE] csv_only=true zip_skipped=true")
    if report_dir_removed:
        print(f"{TRACE_PREFIX}[DONE] report_dir_removed=true keep_report=false")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
