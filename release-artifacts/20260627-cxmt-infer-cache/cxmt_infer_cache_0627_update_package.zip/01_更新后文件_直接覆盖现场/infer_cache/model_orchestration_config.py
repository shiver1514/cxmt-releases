# -*- coding: utf-8 -*-
"""Editable model orchestration config for infer_cache HTTP service.

修改本文件后需要重启 infer-cache 服务才会生效。
模型路径仍由环境变量 INFER_CACHE_MODEL_PATHS 提供，顺序固定为：

    1. 第 1 个模型：单图模型，输入单张 PNG 帧。
    2. 第 2 个模型：多图/组合图模型，输入固定窗口内多张 PNG 帧。
"""

# True 表示启用 1# 单图 + 2# 多图固定编排；False 则使用旧版所有模型逐帧单图推理逻辑。
ENABLE_MODEL_ORCHESTRATION = True

# True 表示启用编排时必须正好配置两个模型路径。
REQUIRE_TWO_MODELS = True

# 多图窗口配置。默认对齐 comboVideo：前2 + 当前 + 后2 = 5 张。
MULTI_IMAGE_BEFORE_FRAMES = 2
MULTI_IMAGE_AFTER_FRAMES = 2

# 中间过程存储模式：
# - "memory"：推理帧、推理输出、规则输出、渲染图全部保存在内存中，只把最终协议图片/GIF/日志写到 result_root。
# - "disk"：保持旧链路，在 output_root/cache 下写帧 PNG、SQLite 和 rendered_rules。
INTERMEDIATE_STORAGE_MODE = "memory"

# [1.内存模型预加载整段视频全部帧][生产迭代02-有界流式]
# 修改人: Shiver; 修改时间: 2026-06-22;
# 修改逻辑: True时内存模式不再预加载整段视频BGR帧；1#模型边解码边推理，
# 2#模型按目标区间二次流式读取，规则/渲染通过有界读取器按需取原图。
# 如现场回归异常，可改为False并重启，立即回到原legacy_full_frames路径。
ENABLE_BOUNDED_FRAME_STREAMING = True

# 惰性原图读取器最多缓存多少张BGR帧。仅用于规则明确读取像素、渲染和告警产物。
BOUNDED_FRAME_PROVIDER_CACHE_SIZE = 16

# True 时保存 2# 多图模型实际使用的窗口文件，便于排查输入是否正确。
SAVE_MULTI_IMAGE_WINDOWS = False

# True 时使用 1# 单图模型的某个 RegionList 输出筛选 2# 多图模型推理区间。
TARGET_FILTER_ENABLED = True

# 需要填写 /models 返回的 outputs[].key 中属于 1# 单图模型的输出 key。
# 只有该输出存在任意 region 时，才认为这一帧命中目标。
# "cxmt-ph-avi-detection/检测-arm/pred"
TARGET_OUTPUT_KEY = "cxmt-ph-avi-detection/检测-arm/pred"

# 目标区间要求连续命中的最小帧数，以及区间前/后扩展秒数。
TARGET_MIN_CONSECUTIVE_FRAMES = 3
TARGET_PRE_EXPAND_SEC = 0.5
TARGET_POST_EXPAND_SEC = 0.5

# [1#稀疏补推][生产迭代01]
# 修改人: Shiver; 修改时间: 2026-06-27;
# 修改逻辑: 默认关闭。开启后1#模型先按全局frame_index固定步长稀疏扫描，
# 再基于稀疏预判规则seed按缺陷类型补推；最终仍重新跑完整规则链。
STAGE1_SPARSE_ENABLED = False

# 1#稀疏扫描步长。3表示全视频仅推 frame_index % 3 == 0 的基础锚点。
STAGE1_SPARSE_STRIDE = 3

# 1#稀疏预判命中后按缺陷类型补推半径，单位：采样帧。
STAGE1_SPARSE_DROPLET_REFINE_RADIUS = 6
STAGE1_SPARSE_LEAK_REFINE_RADIUS = 3
STAGE1_SPARSE_SPREAD_REFINE_RADIUS = 12

# 1#补推比例过高时回退全量1#，避免高密度异常视频在稀疏路径下结果不稳定。
# 0表示关闭自动回退；0.60表示待补推帧数达到全视频60%时回退。
STAGE1_SPARSE_FALLBACK_REFINE_RATIO = 0.60

# [2#稀疏补推][生产迭代01]
# 修改人: Shiver; 修改时间: 2026-06-25;
# 修改逻辑: 默认关闭。开启后 2# 多图模型先按固定步长做稀疏扫描，
# 只有扫描命中漏滴输出时再补推附近中心帧，以减少 2# 推理帧数。
# 规则链路不改；未被 2# 推理的帧仍写入空输出，因此必须通过 A/C 对比确认召回。
STAGE2_SPARSE_ENABLED = False

# 稀疏扫描步长。3 表示目标区间内大约每 3 个中心帧推理 1 个窗口。
STAGE2_SPARSE_STRIDE = 3

# 2#稀疏中心帧选取方式：
# - "target_position"：旧逻辑，按目标区间内位置 position%stride 选帧。
# - "global_frame_index"：按全视频 frame_index%stride 选帧，用于和1#稀疏锚点对齐。
STAGE2_SPARSE_INDEX_MODE = "target_position"

# 稀疏扫描命中后，补推中心帧前后半径。5帧窗口默认前2+后2，因此默认补推 ±2。
STAGE2_SPARSE_REFINE_RADIUS = 2

# 目标区间首尾各多少个中心帧保持全量推理，用于保护规则首尾窗口。
STAGE2_SPARSE_BOUNDARY_DENSE_RADIUS = 10

# 触发补推的 2# 输出 key。漏滴来自 2# 多通道分割输出。
STAGE2_SPARSE_TRIGGER_OUTPUT_KEY = "cxmt-ph-avi-detection_multi_channels/分割_漏滴/pred"

# 稀疏扫描命中触发模式：
# - "model_raw"：2#原始漏滴输出有region就补推（备选模式，最保守，补推量较多）。
# - "rule3_filtered"：稀疏2#输出先跑到rule3，rule3后仍有漏滴才补推（C组，减少无效补推）。
STAGE2_SPARSE_TRIGGER_MODE = "rule3_filtered"

# 稀疏扫描命中率过高时回退全量2#推理，避免高密度疑似场景下为了省推理牺牲稳定性。
# 0 表示不启用自动回退；0.60 表示稀疏扫描命中率 >=60% 时回退全量。
STAGE2_SPARSE_FALLBACK_HIT_RATE = 0.60

# True 时保存带 testoutput-{后缀} 标签帧的原始图到当前视频 cache 目录。
SAVE_TESTOUTPUT_ORIGINAL_IMAGES = True

# 每个视频最多保存多少张 testoutput 原始图；超过后不再保存。
MAX_TESTOUTPUT_ORIGINAL_IMAGES_PER_VIDEO = 20

# testoutput 标签前缀。summary 规则产生 testoutput-{后缀} 时会按后缀保存。
TESTOUTPUT_LABEL_PREFIX = "testoutput-"

# 协议告警/存图代表帧选择优先级。越靠前优先级越高。
ALARM_FRAME_PRIORITY_LABELS = [
    "综合结果-漏滴",
    "综合结果-分布不均",
    "综合结果-挂滴",
]

# GIF 代表帧前后窗口。默认前7 + 当前 + 后7。
ALARM_GIF_BEFORE_FRAMES = 7
ALARM_GIF_AFTER_FRAMES = 7
