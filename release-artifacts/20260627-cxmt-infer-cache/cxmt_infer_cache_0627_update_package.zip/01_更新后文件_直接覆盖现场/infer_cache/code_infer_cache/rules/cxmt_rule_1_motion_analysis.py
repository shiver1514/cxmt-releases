# -*- coding: utf-8 -*-
"""
================================================================================
规则名称：cxmt_rule_1_motion_analysis
功能描述：视频级规则，分析喷头运动状态、方向及作业阶段。
         1. 双锚点竞争（左下角 & 右下角），自适应左右臂，抗遮挡与进出画面误判。
         2. 对称窗口速度计算，利用未来帧实现无滞后运动状态判定。
         3. 运动/静止使用固定基础阈值，并基于目标框面积自适应微调。
         4. 液柱检测（大/小喷嘴挂滴分割模型），结合垂直运动划分区间，
            判定每个臂是否处于“作业中”阶段。
         5. 渲染中文状态/方向/速度及作业标识，CSV 导出英文以防乱码。

算法流程：
    - 第一遍：逐帧收集双锚点原始坐标、EMA平滑坐标、液柱标记。
    - 第二遍：基于完整平滑序列，以对称窗口计算速度（双锚点取最大），
              并计算瞬时速度（用于模糊判定），同时用固定阈值+面积自适应得到候选状态。
    - 第三遍：对候选状态序列进行后处理（中值滤波、短状态合并、边界提前/延后）。
    - 第四遍：根据最终状态与速度分量计算运动方向，并基于垂直运动区间
              判定作业阶段（每个臂独立）。
    - 第五遍：逐帧渲染输出（状态、速度、方向、作业标记），可选导出 CSV。

================================================================================
"""

import math
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np
from visionflow import props
from cxmt_public_function import create_point_region


# ============================================================
# 参数配置（所有可调参数集中于此，按功能分组，附调整建议）
# ============================================================

# -------------------- 丢失帧清理 --------------------
# 当某个臂连续未被检测到的帧数超过此阈值时，清除其全部历史轨迹。
# 增大可保留更长时间的记忆（对短暂遮挡不敏感），但可能残留无效数据。
# 减小可更快遗忘，但可能误将短暂丢失当作新目标。
no_arm_count_th = 3

# -------------------- 运动分析核心参数 --------------------
# 方向判定使用的平滑锚点窗口长度（帧数）。窗口越大，方向越稳定但响应略慢。
DIRECTION_HISTORY_LEN = 8
# 坐标平滑系数（EMA），用于抑制AI检测框的抖动。范围 (0, 1]，值越大对当前帧越敏感。
# 若抖动明显可适当降低（如0.2），若运动快速且需要及时响应可略微提高（如0.4）。
SMOOTH_ALPHA = 0.3
# 对称速度计算窗口半长基数，实际窗口总长 = 2 * (STATUS_HISTORY_LEN // 2) + 1。
# 增大可让速度更平滑但切换延迟增加；减小可提高对瞬时运动的响应。
STATUS_HISTORY_LEN = 8

# -------------------- 速度阈值 --------------------
# 基础运动/静止速度阈值（像素/帧 *10），该值将根据目标框面积自适应调整。
# 若整体判定偏“静止”可适当降低此值；若噪声误判为“运动”则适当提高。
base_speed_th = 20.0
# 参考目标框面积（宽×高），用于自适应阈值的缩放基准。
# 可根据典型喷头框大小校准。若喷头普遍较大/较小，可相应调整此基准。
BASE_AREA = 150 * 160
# 方向输出的最小速度阈值，低于此速度时不显示方向（避免静止时的方向抖动）。
MIN_DIRECTION_SPEED = 15

# -------------------- 模糊阈值 --------------------
# 瞬时速度（相邻帧平滑锚点差）超过此值判定为“模糊”。
# 小喷嘴通常面积小，像素位移相对较小，故阈值较低；大喷嘴反之。
# 若误将正常运动判为模糊，可适当提高对应阈值；若模糊未被识别可降低。
small_arm_motion_blur_th = 300
large_arm_motion_blur_th = 1000

# -------------------- 液柱与作业阶段 --------------------
# 判断一个区间为“作业中”所需的最小液柱帧数。
# 若液柱出现频繁可适当增大以提高抗干扰；若液柱稀少但确是作业则可减小。
MIN_DROPLET_FRAMES = 3
# 液柱检测使用的分割模型 key 列表（可按需扩展）
DROPLET_MODEL_KEYS = [
    "cxmt-ph-avi-detection/分割_大喷嘴挂滴/pred",
    "cxmt-ph-avi-detection/分割_小喷嘴挂滴/pred",
]

# -------------------- 显示控制 --------------------
show_speed_region = True        # 是否显示原始臂检测框
show_speed_infor = True         # 是否在左下角显示状态/方向/速度文本
show_working_status = True      # 是否在左下角额外显示“作业中”全局标识

# -------------------- CSV 导出 --------------------
EXPORT_TRACKS = False           # 是否导出轨迹 CSV 文件
EXPORT_PATH = Path("C:/test/arm_tracks.csv")   # 导出路径


# ============================================================
# 辅助函数
# ============================================================
def get_anchor_points(region):
    """
    返回检测框的左下角和右下角坐标作为双锚点。
    左下角用于捕捉左向运动，右下角用于捕捉右向运动。
    """
    bbox = region.polygon().bounding_box()
    return bbox.xmin_ymax(), bbox.xmax_ymax()


def compute_direction(dx: float, dy: float, total_speed: float) -> str:
    """
    根据速度分量计算运动方向（中文）。
    角度区间映射：[-45°, 45°] → 右，(45°, 135°] → 下，
    (-135°, -45°) → 上，其余 → 左。
    速度低于 MIN_DIRECTION_SPEED 时返回空字符串。
    """
    if total_speed < MIN_DIRECTION_SPEED:
        return ""
    angle = math.degrees(math.atan2(dy, dx))
    if -45 <= angle <= 45:
        return "右"
    elif 45 < angle <= 135:
        return "下"
    elif angle > 135 or angle <= -135:
        return "左"
    else:
        return "上"


# ============================================================
# 视频级规则入口
# ============================================================
def process_video(ctx):
    total_frames = ctx.total_frames
    image_w = 0
    image_h = 0

    # ---- 双锚点平滑历史（A = 左下角，B = 右下角） ----
    arm_smoothed_A: Dict[str, List[Tuple[float, float]]] = {}
    arm_smoothed_B: Dict[str, List[Tuple[float, float]]] = {}
    arm_last_raw_A: Dict[str, Tuple[float, float]] = {}
    arm_last_raw_B: Dict[str, Tuple[float, float]] = {}
    # [1#稀疏补推][生产迭代01-rule1时间归一]
    # 修改人: Shiver; 修改时间: 2026-06-27;
    # 修改逻辑: 记录每个臂的真实frame_idx，稀疏推理时速度/作业阶段按原视频帧间隔归一，
    # 避免把相邻稀疏点误当作相邻视频帧导致速度放大。
    arm_frame_indices: Dict[str, List[int]] = {}

    # 存储所有帧中每个臂的详细数据
    frames_data = []   # list of dict

    # ========================================================
    # 第一遍：收集臂数据 + 液柱标记
    # ========================================================
    for frame_idx in range(total_frames):
        sample = ctx.get_frame(frame_idx)
        if sample is None:
            frames_data.append({})
            continue

        cur_w, cur_h = sample.image_size()
        if cur_w > 0 and cur_h > 0:
            image_w, image_h = cur_w, cur_h

        # --- 液柱检测（全局帧级标记） ---
        has_droplet = False
        for key in DROPLET_MODEL_KEYS:
            region_list = sample.get_optional(key)
            if region_list:
                for _, region in region_list:
                    if region.name() == "液柱":
                        has_droplet = True
                        break
            if has_droplet:
                break

        # --- 臂检测（自动识别所有以 "arm" 开头的标签） ---
        det_arm_region_list = sample.get("cxmt-ph-avi-detection/检测-arm/pred")
        unique_arms = {}
        for _, region in det_arm_region_list:
            name = region.name()
            if not name or not name.startswith("arm"):
                continue
            if name not in unique_arms:
                unique_arms[name] = region

        frame_arm_data = {}
        for name, curr_region in unique_arms.items():
            # 初始化该臂的双锚点历史（首次出现时）
            if name not in arm_smoothed_A:
                arm_smoothed_A[name] = []
                arm_smoothed_B[name] = []
                arm_last_raw_A[name] = None
                arm_last_raw_B[name] = None
                arm_frame_indices[name] = []

            # 获取两个原始锚点
            anchorA, anchorB = get_anchor_points(curr_region)
            raw_Ax, raw_Ay = anchorA.x, anchorA.y
            raw_Bx, raw_By = anchorB.x, anchorB.y

            # 大跳变重置：若 x 方向位移超过150像素，认为臂被更换或大幅度摆动，清空平滑历史
            last_A = arm_last_raw_A[name]
            last_B = arm_last_raw_B[name]
            reset_history = (
                (last_A is not None and abs(last_A[0] - raw_Ax) > 150)
                or (last_B is not None and abs(last_B[0] - raw_Bx) > 150)
            )
            if reset_history:
                # [1#稀疏补推][生产迭代01-rule1历史对齐]
                # 修改人: Shiver; 修改时间: 2026-06-27;
                # 修改逻辑: rule1后续用同一个anchor_idx同步读取A/B锚点和真实frame_idx；
                # 任一锚点大跳变时必须同步清空A/B历史和frame_idx历史，避免稀疏时间归一错位。
                arm_smoothed_A[name].clear()
                arm_smoothed_B[name].clear()
                arm_frame_indices[name].clear()
            arm_last_raw_A[name] = (raw_Ax, raw_Ay)
            arm_last_raw_B[name] = (raw_Bx, raw_By)

            # EMA 平滑锚点 A
            seqA = arm_smoothed_A[name]
            if not seqA:
                smooth_Ax, smooth_Ay = raw_Ax, raw_Ay
            else:
                prev = seqA[-1]
                smooth_Ax = prev[0] * (1 - SMOOTH_ALPHA) + raw_Ax * SMOOTH_ALPHA
                smooth_Ay = prev[1] * (1 - SMOOTH_ALPHA) + raw_Ay * SMOOTH_ALPHA
            seqA.append((smooth_Ax, smooth_Ay))

            # EMA 平滑锚点 B
            seqB = arm_smoothed_B[name]
            if not seqB:
                smooth_Bx, smooth_By = raw_Bx, raw_By
            else:
                prev = seqB[-1]
                smooth_Bx = prev[0] * (1 - SMOOTH_ALPHA) + raw_Bx * SMOOTH_ALPHA
                smooth_By = prev[1] * (1 - SMOOTH_ALPHA) + raw_By * SMOOTH_ALPHA
            seqB.append((smooth_Bx, smooth_By))

            # 保存本帧数据（速度字段稍后计算）
            arm_frame_indices[name].append(frame_idx)
            frame_arm_data[name] = {
                "region": curr_region,
                "raw_Ax": raw_Ax, "raw_Ay": raw_Ay,
                "raw_Bx": raw_Bx, "raw_By": raw_By,
                "smooth_Ax": smooth_Ax, "smooth_Ay": smooth_Ay,
                "smooth_Bx": smooth_Bx, "smooth_By": smooth_By,
                "total_speed": 0.0,
                "dx_speed": 0.0,
                "dy_speed": 0.0,
                "candidate_state": "",
            }
        frame_arm_data["__global__"] = {"has_droplet": has_droplet}
        frames_data.append(frame_arm_data)

    # ========================================================
    # 第二遍：对称窗口速度计算（双锚点取最大值） + 候选状态
    # ========================================================
    SYMM_WINDOW_RADIUS = max(1, STATUS_HISTORY_LEN // 2)   # 对称窗口半径
    for arm_name in arm_smoothed_A.keys():
        anchorsA = arm_smoothed_A[arm_name]  # 臂A的完整平滑序列
        anchorsB = arm_smoothed_B[arm_name]  # 臂B的完整平滑序列
        anchor_frames = arm_frame_indices.get(arm_name, list(range(len(anchorsA))))
        anchor_idx = 0
        for fi, fdata in enumerate(frames_data):
            if arm_name in fdata:
                # [1#稀疏补推][生产迭代01-rule1历史对齐] 防御A/B锚点和frame_idx历史长度异常，避免规则直接中断。
                if anchor_idx < len(anchorsA) and anchor_idx < len(anchorsB) and anchor_idx < len(anchor_frames):
                    left = max(0, anchor_idx - SYMM_WINDOW_RADIUS)
                    right = min(len(anchorsA) - 1, anchor_idx + SYMM_WINDOW_RADIUS)

                    # 局部函数：根据锚点列表计算对称窗口速度
                    def calc_speed(anchors):
                        if right > left:
                            sx, sy = anchors[left]
                            ex, ey = anchors[right]
                            dx = ex - sx
                            dy = ey - sy
                            dist = math.hypot(dx, dy)
                            frame_delta = max(1, int(anchor_frames[right]) - int(anchor_frames[left]))
                            avg_speed = dist / frame_delta
                            return avg_speed * 10, (dx / frame_delta) * 10, (dy / frame_delta) * 10
                        return 0.0, 0.0, 0.0

                    totalA, dxA, dyA = calc_speed(anchorsA)
                    totalB, dxB, dyB = calc_speed(anchorsB)

                    # 双锚点竞争：取速度最大者作为当前帧的最终速度
                    if totalA >= totalB:
                        total_speed = totalA
                        dx_speed = dxA
                        dy_speed = dyA
                    else:
                        total_speed = totalB
                        dx_speed = dxB
                        dy_speed = dyB

                    # 瞬时速度（用于模糊判定）：取两个锚点瞬时速度的最大值
                    inst_speed = 0
                    if anchor_idx >= 1:
                        prevA = anchorsA[anchor_idx - 1]
                        currA = anchorsA[anchor_idx]
                        frame_delta = max(1, int(anchor_frames[anchor_idx]) - int(anchor_frames[anchor_idx - 1]))
                        instA = (math.hypot(currA[0]-prevA[0], currA[1]-prevA[1]) / frame_delta) * 10
                        prevB = anchorsB[anchor_idx - 1]
                        currB = anchorsB[anchor_idx]
                        instB = (math.hypot(currB[0]-prevB[0], currB[1]-prevB[1]) / frame_delta) * 10
                        inst_speed = max(instA, instB)

                    # 自适应速度阈值（基于目标框面积动态调整）
                    region = fdata[arm_name]["region"]
                    bbox = region.polygon().bounding_box()
                    area = (bbox.xmax_ymin().x - bbox.xmin_ymin().x) * (bbox.xmin_ymax().y - bbox.xmin_ymin().y)
                    area_ratio = area / BASE_AREA if BASE_AREA > 0 else 1.0
                    adaptive_speed_th = base_speed_th * (1.0 + area_ratio * 0.5)

                    # 模糊阈值（根据臂类型选择）
                    motion_blur_th = small_arm_motion_blur_th if arm_name.startswith("arm0") else large_arm_motion_blur_th

                    # 候选状态判定：模糊优先，然后是运动/静止
                    if inst_speed > motion_blur_th:
                        candidate_state = "模糊"
                    elif total_speed > adaptive_speed_th:
                        candidate_state = "运动"
                    else:
                        candidate_state = "静止"

                    fdata[arm_name].update({
                        "total_speed": total_speed,
                        "dx_speed": dx_speed,
                        "dy_speed": dy_speed,
                        "candidate_state": candidate_state,
                    })
                    anchor_idx += 1

    # ========================================================
    # 第三遍：后处理（中值滤波、合并短状态、边界调整）
    # ========================================================
    MIN_STATE_DURATION = 2        # 状态最短持续帧数，低于此将被合并
    BOUNDARY_LOOKAHEAD = 2        # 边界提前/延后检查的帧数
    for arm_name in arm_smoothed_A.keys():
        # 提取该臂在所有帧中的连续序列
        seq = []
        for fi, fdata in enumerate(frames_data):
            if arm_name in fdata:
                seq.append((fi, fdata[arm_name]))
        if len(seq) < 3:
            continue

        # 辅助函数：状态与数值互转
        def state_to_val(s):
            return {"静止": 0, "运动": 1, "模糊": 2}.get(s, 0)
        def val_to_state(v):
            return ["静止", "运动", "模糊"][v]

        # 3.1 中值滤波（边缘保持）：仅平滑连续相同状态的内部帧，不改变切换边界
        raw_states = [state_to_val(d["candidate_state"]) for _, d in seq]
        smoothed_states = raw_states.copy()
        for i in range(1, len(seq)-1):
            if raw_states[i] != raw_states[i-1] or raw_states[i] != raw_states[i+1]:
                continue  # 可能是边界，跳过
            window = raw_states[i-1:i+2]
            smoothed_states[i] = max(set(window), key=window.count)
        for (_, d), s in zip(seq, smoothed_states):
            d["candidate_state"] = val_to_state(s)

        # 3.2 合并持续时间过短的孤立状态
        i = 0
        while i < len(seq):
            state = seq[i][1]["candidate_state"]
            j = i
            while j < len(seq) and seq[j][1]["candidate_state"] == state:
                j += 1
            run_len = j - i
            if run_len < MIN_STATE_DURATION:
                left_state = seq[i-1][1]["candidate_state"] if i > 0 else None
                right_state = seq[j][1]["candidate_state"] if j < len(seq) else None
                replace_state = left_state if left_state is not None else right_state
                if replace_state is None:
                    replace_state = state
                for k in range(i, j):
                    seq[k][1]["candidate_state"] = replace_state
            i = j

        # 3.3 边界提前/延后：在状态切换点附近，如果速度已满足条件则提前改变状态
        for i in range(len(seq)-1):
            curr_state = seq[i][1]["candidate_state"]
            next_state = seq[i+1][1]["candidate_state"]
            if curr_state != next_state:
                # 静止 -> 运动：向前看，若速度超过阈值*0.8则提前改为运动
                if curr_state == "静止" and next_state == "运动":
                    for look in range(1, BOUNDARY_LOOKAHEAD+1):
                        idx = i - look
                        if idx >= 0:
                            d = seq[idx][1]
                            bbox = d["region"].polygon().bounding_box()
                            area = (bbox.xmax_ymin().x - bbox.xmin_ymin().x) * (bbox.xmin_ymax().y - bbox.xmin_ymin().y)
                            area_ratio = area / BASE_AREA if BASE_AREA > 0 else 1.0
                            th = base_speed_th * (1.0 + area_ratio * 0.5)
                            if d["total_speed"] > th * 0.8:
                                d["candidate_state"] = "运动"
                # 运动 -> 静止：向后看，若速度低于阈值*1.2则提前改为静止
                elif curr_state == "运动" and next_state == "静止":
                    for look in range(1, BOUNDARY_LOOKAHEAD+1):
                        idx = i + 1 + look
                        if idx < len(seq):
                            d = seq[idx][1]
                            bbox = d["region"].polygon().bounding_box()
                            area = (bbox.xmax_ymin().x - bbox.xmin_ymin().x) * (bbox.xmin_ymax().y - bbox.xmin_ymin().y)
                            area_ratio = area / BASE_AREA if BASE_AREA > 0 else 1.0
                            th = base_speed_th * (1.0 + area_ratio * 0.5)
                            if d["total_speed"] < th * 1.2:
                                d["candidate_state"] = "静止"

    # ========================================================
    # 第四遍：方向计算 + 作业阶段判定
    # ========================================================
    # 4.1 计算每帧每个臂的运动方向
    for fi, fdata in enumerate(frames_data):
        for arm_name in list(fdata.keys()):
            if arm_name == "__global__":
                continue
            d = fdata[arm_name]
            state = d["candidate_state"]
            dx = d["dx_speed"]
            dy = d["dy_speed"]
            total = d["total_speed"]
            if state in ("运动", "模糊"):
                dir_str = compute_direction(dx, dy, total)
            else:
                dir_str = ""
            d["dir"] = dir_str

    # 4.2 作业阶段判定（每个臂独立）
    for arm_name in arm_smoothed_A.keys():
        seq = []
        for fi, fdata in enumerate(frames_data):
            if arm_name in fdata:
                seq.append((fi, fdata[arm_name], frames_data[fi].get("__global__", {}).get("has_droplet", False)))
        if not seq:
            continue

        # 找出所有垂直运动帧的索引（方向为“上”或“下”）
        vertical_indices = []
        for i, (fi, d, _) in enumerate(seq):
            if d["dir"] in ("上", "下"):
                vertical_indices.append(i)

        def mark_segment(start_i, end_i, is_working):
            for k in range(start_i, end_i + 1):
                seq[k][1]["is_working"] = is_working

        def droplet_weight(start_i, end_i):
            # [1#稀疏补推][生产迭代01-rule1液柱计数]
            # 修改人: Shiver; 修改时间: 2026-06-27;
            # 修改逻辑: 稀疏点上的一次液柱命中代表其覆盖的原视频帧间隔；
            # 全量推理时权重仍为1，不改变旧结果。
            total = 0
            if start_i > end_i:
                return total
            for j in range(start_i, end_i + 1):
                if not seq[j][2]:
                    continue
                if j + 1 < len(seq):
                    weight = max(1, int(seq[j + 1][0]) - int(seq[j][0]))
                elif j > 0:
                    weight = max(1, int(seq[j][0]) - int(seq[j - 1][0]))
                else:
                    weight = 1
                total += weight
            return total

        # 初始化所有帧为非作业
        for _, d, _ in seq:
            d["is_working"] = False

        if not vertical_indices:
            # 整段视频无垂直运动 → 整个序列作为一个区间
            droplet_count = droplet_weight(0, len(seq) - 1)
            if droplet_count >= MIN_DROPLET_FRAMES:
                mark_segment(0, len(seq)-1, True)
        else:
            # 区间1：从开始到第一个垂直运动之前
            first_vert = vertical_indices[0]
            if first_vert > 0:
                droplet_count = droplet_weight(0, first_vert - 1)
                if droplet_count >= MIN_DROPLET_FRAMES:
                    mark_segment(0, first_vert-1, True)
            # 中间区间：每两个垂直运动之间
            for i in range(len(vertical_indices)-1):
                start = vertical_indices[i] + 1
                end = vertical_indices[i+1] - 1
                if start <= end:
                    droplet_count = droplet_weight(start, end)
                    if droplet_count >= MIN_DROPLET_FRAMES:
                        mark_segment(start, end, True)
            # 区间N：最后一个垂直运动之后
            last_vert = vertical_indices[-1]
            if last_vert + 1 < len(seq):
                droplet_count = droplet_weight(last_vert + 1, len(seq) - 1)
                if droplet_count >= MIN_DROPLET_FRAMES:
                    mark_segment(last_vert+1, len(seq)-1, True)

    # ========================================================
    # 第五遍：渲染 + CSV 导出
    # ========================================================
    state_en = {"静止": "still", "运动": "moving", "模糊": "blur"}
    dir_en = {"左": "left", "右": "right", "上": "up", "下": "down"}

    export_lines = []
    if EXPORT_TRACKS:
        export_lines.append("frameIndex,armName,raw_Ax,raw_Ay,raw_Bx,raw_By,smooth_Ax,smooth_Ay,smooth_Bx,smooth_By,state,total_speed,dx_speed,dy_speed,direction,is_working,has_droplet")

    for frame_idx, frame_arm_data in enumerate(frames_data):
        ply_region_list = ctx.empty_regions()
        global_has_droplet = frame_arm_data.get("__global__", {}).get("has_droplet", False)

        arm_items = [(name, data) for name, data in frame_arm_data.items() if name != "__global__"]
        if not arm_items:
            result_region = create_point_region([0, image_h], 5, 0, "无目标")
            ply_region_list.add(result_region)
            ctx.add_output(frame_idx, ply_region_list)
            continue

        # 按臂中心 X 坐标从左到右排序，保证显示顺序稳定
        sorted_arms = sorted(arm_items, key=lambda item: item[1]["region"].polygon().centroid().x)
        margin_left = 5
        margin_bottom = 20
        line_height = 22
        start_y = image_h - margin_bottom

        for i, (name, data) in enumerate(sorted_arms):
            y_pos = start_y - i * line_height
            if y_pos < 10:
                break
            state = data["candidate_state"]
            total_speed = data["total_speed"]
            dx_speed = data["dx_speed"]
            dy_speed = data["dy_speed"]
            dir_str = data.get("dir", "")
            is_working = data.get("is_working", False)

            if show_speed_region:
                vis_region = data["region"].clone()
                vis_region.set_name(name)
                ply_region_list.add(vis_region)
            if show_speed_infor:
                info_parts = [f"{state}"]
                if dir_str:
                    info_parts.append(f"({dir_str})")
                info_parts.append(f": {name}")
                info_parts.append(f"| speed: [{int(total_speed)}, {int(dx_speed)}, {int(dy_speed)}]")
                if is_working:
                    info_parts.append("[作业中]")
                info_str = " ".join(info_parts)
                info_region = create_point_region([margin_left, y_pos], 5, 0, name)
                info_region.set_name(info_str)
                ply_region_list.add(info_region)

            if EXPORT_TRACKS:
                export_lines.append(
                    f"{frame_idx},{name},"
                    f"{data['raw_Ax']:.2f},{data['raw_Ay']:.2f},{data['raw_Bx']:.2f},{data['raw_By']:.2f},"
                    f"{data['smooth_Ax']:.2f},{data['smooth_Ay']:.2f},{data['smooth_Bx']:.2f},{data['smooth_By']:.2f},"
                    f"{state_en[state]},{total_speed:.1f},{dx_speed:.1f},{dy_speed:.1f},"
                    f"{dir_en.get(dir_str, '')},{is_working},{global_has_droplet}"
                )

        # 左下角全局“作业中”标识
        if show_working_status and any(data.get("is_working", False) for name, data in sorted_arms):
            working_region = create_point_region(
                [margin_left, start_y - len(sorted_arms)*line_height], 5, 0, "作业中"
            )
            working_region.set_name("作业中")
            ply_region_list.add(working_region)

        ctx.add_output(frame_idx, ply_region_list)

    if EXPORT_TRACKS:
        EXPORT_PATH.parent.mkdir(parents=True, exist_ok=True)
        with open(EXPORT_PATH, "w", encoding="utf-8") as f:
            f.write("\n".join(export_lines))
        print(f"轨迹数据已保存至: {EXPORT_PATH}")


# ============================================================
# 规则注册
# ============================================================
RULES = [
    {
        "name": "cxmt_rule_1_motion_analysis",
        "video_func": process_video,
        "labels": ["静止", "运动", "模糊"],
        "description": "双锚点竞争版运动分析，固定阈值+面积自适应，液柱检测，作业阶段判定。",
        "depends_on": [],
    }
]
