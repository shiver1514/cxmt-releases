# -*- coding: utf-8 -*-
"""Orchestrate model inspection, inference cache generation and rule execution."""

from __future__ import annotations

import csv
import inspect
import json
import os
import subprocess
import sys
import shutil
import threading
import time
import traceback
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from pathlib import Path
from typing import Callable, Dict, List, Optional, Tuple

try:
    from .callback import build_protocol_payload, post_json
    from .config import ServiceConfig
    from .nas_client import resolve_input_video
    from .paths import ensure_runtime_paths
    from .protocol_adapter import (
        build_internal_error_result,
        build_protocol_result,
        is_customer_protocol,
        parse_protocol_input,
        protocol_output_paths,
    )
    from .result_reader import NG_LABEL, merge_rule_results, read_memory_rule_result, read_rule_result
    from .task_callback import TaskCallbackBatcher
    from .timezone_utils import app_compact_timestamp, app_strftime, app_today, get_app_timezone_name
    from .video_filter import apply_video_filter
    from .video_trace import VIDEO_TRACE_LOG_PREFIX, VideoTraceLogger
    from . import model_orchestration_config as orchestration_config
except ImportError:
    from callback import build_protocol_payload, post_json
    from config import ServiceConfig
    from nas_client import resolve_input_video
    from paths import ensure_runtime_paths
    from protocol_adapter import (
        build_internal_error_result,
        build_protocol_result,
        is_customer_protocol,
        parse_protocol_input,
        protocol_output_paths,
    )
    from result_reader import NG_LABEL, merge_rule_results, read_memory_rule_result, read_rule_result
    from task_callback import TaskCallbackBatcher
    from timezone_utils import app_compact_timestamp, app_strftime, app_today, get_app_timezone_name
    from video_filter import apply_video_filter
    from video_trace import VIDEO_TRACE_LOG_PREFIX, VideoTraceLogger
    import model_orchestration_config as orchestration_config

ensure_runtime_paths()

from infer_cache_core import (  # noqa: E402
    MediaSource,
    prepare_inference_context,
    render_cache_batch,
    render_rule_images_memory,
    run_inference_cache_prepared,
    run_inference_memory_prepared,
)
from rule_pipeline import run_rules, run_rules_memory  # noqa: E402


# [1.内存模型预加载整段视频全部帧][生产迭代01-日志]
# 修改人: Shiver; 修改时间: 2026-06-22;
# 修改逻辑: 本问题所有新增诊断日志使用统一前缀，方便现场按一条grep命令提取。
MEMORY_FIX_LOG_PREFIX = "[1.内存模型预加载整段视频全部帧]"
SPECIAL_LOG_PREFIX = "专项日志"


def _format_duration_cn_ms(value: object) -> str:
    try:
        ms = float(value)
    except Exception:
        return "未知"
    if ms < 0:
        return "未知"
    seconds = ms / 1000.0
    if seconds < 1.0:
        return f"{ms:.0f}毫秒"
    if seconds < 60.0:
        return f"{seconds:.2f}秒"
    minutes = int(seconds // 60)
    remain = seconds - minutes * 60
    if minutes < 60:
        return f"{minutes}分{remain:.1f}秒"
    hours = int(minutes // 60)
    remain_minutes = minutes % 60
    return f"{hours}小时{remain_minutes}分{remain:.0f}秒"


def _format_percent_cn(value: object) -> str:
    try:
        return f"{float(value):.2f}%"
    except Exception:
        return "未知"


def _format_future_time_cn(epoch_seconds: Optional[float]) -> str:
    if not epoch_seconds or epoch_seconds <= 0:
        return "暂无法估算"
    try:
        return datetime.fromtimestamp(float(epoch_seconds)).strftime("%Y-%m-%d %H:%M:%S")
    except Exception:
        return "暂无法估算"


def _trace_resource_snapshot() -> Dict[str, object]:
    memory = _container_memory_snapshot()
    return {
        "memory_usage_bytes": memory.get("usage_bytes"),
        "memory_usage_text": memory.get("usage_text"),
        "pids": _container_pids_snapshot(),
        "python_threads": threading.active_count(),
    }


def _file_size_bytes(path_text: object) -> int:
    text = str(path_text or "").strip()
    if not text:
        return 0
    try:
        path = Path(text)
        return int(path.stat().st_size) if path.exists() and path.is_file() else 0
    except Exception:
        return 0


def _orchestration_summary() -> Dict[str, object]:
    before = max(0, int(getattr(orchestration_config, "MULTI_IMAGE_BEFORE_FRAMES", 2) or 0))
    after = max(0, int(getattr(orchestration_config, "MULTI_IMAGE_AFTER_FRAMES", 2) or 0))
    return {
        "enabled": bool(getattr(orchestration_config, "ENABLE_MODEL_ORCHESTRATION", True)),
        "require_two_models": bool(getattr(orchestration_config, "REQUIRE_TWO_MODELS", True)),
        "multi_image_before_frames": before,
        "multi_image_after_frames": after,
        "multi_image_window_size": before + 1 + after,
        "intermediate_storage_mode": str(getattr(orchestration_config, "INTERMEDIATE_STORAGE_MODE", "disk") or "disk").strip().lower(),
        # [1.内存模型预加载整段视频全部帧][生产迭代02-有界流式]
        # 修改人: Shiver; 修改时间: 2026-06-22;
        # 修改逻辑: 显式暴露流式开关和惰性原图缓存上限，便于/health与日志核验。
        "bounded_frame_streaming": bool(getattr(orchestration_config, "ENABLE_BOUNDED_FRAME_STREAMING", False)),
        "bounded_frame_provider_cache_size": max(1, int(getattr(orchestration_config, "BOUNDED_FRAME_PROVIDER_CACHE_SIZE", 16) or 1)),
        "save_multi_image_windows": bool(getattr(orchestration_config, "SAVE_MULTI_IMAGE_WINDOWS", False)),
        "target_filter_enabled": bool(getattr(orchestration_config, "TARGET_FILTER_ENABLED", False)),
        "target_output_key": str(getattr(orchestration_config, "TARGET_OUTPUT_KEY", "") or ""),
        "target_min_consecutive_frames": max(1, int(getattr(orchestration_config, "TARGET_MIN_CONSECUTIVE_FRAMES", 3) or 1)),
        "target_pre_expand_sec": max(0.0, float(getattr(orchestration_config, "TARGET_PRE_EXPAND_SEC", 0.0) or 0.0)),
        "target_post_expand_sec": max(0.0, float(getattr(orchestration_config, "TARGET_POST_EXPAND_SEC", 0.0) or 0.0)),
        # [1#稀疏补推][生产迭代01]
        # 修改人: Shiver; 修改时间: 2026-06-27;
        # 修改逻辑: 服务启动时固化1#稀疏扫描/按缺陷补推配置，默认关闭，便于现场A/B。
        "stage1_sparse_enabled": bool(getattr(orchestration_config, "STAGE1_SPARSE_ENABLED", False)),
        "stage1_sparse_stride": max(1, int(getattr(orchestration_config, "STAGE1_SPARSE_STRIDE", 3) or 1)),
        "stage1_sparse_droplet_refine_radius": max(0, int(getattr(orchestration_config, "STAGE1_SPARSE_DROPLET_REFINE_RADIUS", 6) or 0)),
        "stage1_sparse_leak_refine_radius": max(0, int(getattr(orchestration_config, "STAGE1_SPARSE_LEAK_REFINE_RADIUS", 3) or 0)),
        "stage1_sparse_spread_refine_radius": max(0, int(getattr(orchestration_config, "STAGE1_SPARSE_SPREAD_REFINE_RADIUS", 12) or 0)),
        "stage1_sparse_fallback_refine_ratio": max(0.0, float(getattr(orchestration_config, "STAGE1_SPARSE_FALLBACK_REFINE_RATIO", 0.60) or 0.0)),
        # [2#稀疏补推][生产迭代01]
        # 修改人: Shiver; 修改时间: 2026-06-25;
        # 修改逻辑: 服务启动时固化2#稀疏扫描/命中补推配置，统一透传到底层推理和trace日志。
        "stage2_sparse_enabled": bool(getattr(orchestration_config, "STAGE2_SPARSE_ENABLED", False)),
        "stage2_sparse_stride": max(1, int(getattr(orchestration_config, "STAGE2_SPARSE_STRIDE", 3) or 1)),
        "stage2_sparse_refine_radius": max(0, int(getattr(orchestration_config, "STAGE2_SPARSE_REFINE_RADIUS", 2) or 0)),
        "stage2_sparse_boundary_dense_radius": max(0, int(getattr(orchestration_config, "STAGE2_SPARSE_BOUNDARY_DENSE_RADIUS", 10) or 0)),
        "stage2_sparse_trigger_output_key": str(getattr(orchestration_config, "STAGE2_SPARSE_TRIGGER_OUTPUT_KEY", "") or ""),
        "stage2_sparse_trigger_mode": str(getattr(orchestration_config, "STAGE2_SPARSE_TRIGGER_MODE", "model_raw") or "model_raw").strip().lower(),
        "stage2_sparse_index_mode": str(getattr(orchestration_config, "STAGE2_SPARSE_INDEX_MODE", "target_position") or "target_position").strip().lower(),
        "stage2_sparse_fallback_hit_rate": max(0.0, float(getattr(orchestration_config, "STAGE2_SPARSE_FALLBACK_HIT_RATE", 0.0) or 0.0)),
        "save_testoutput_original_images": bool(getattr(orchestration_config, "SAVE_TESTOUTPUT_ORIGINAL_IMAGES", False)),
        "max_testoutput_original_images_per_video": max(0, int(getattr(orchestration_config, "MAX_TESTOUTPUT_ORIGINAL_IMAGES_PER_VIDEO", 100) or 0)),
        "testoutput_label_prefix": str(getattr(orchestration_config, "TESTOUTPUT_LABEL_PREFIX", "testoutput-") or "testoutput-"),
        "alarm_frame_priority_labels": [str(label) for label in (getattr(orchestration_config, "ALARM_FRAME_PRIORITY_LABELS", None) or ["综合结果-漏滴", "综合结果-分布不均", "综合结果-挂滴"])],
        "alarm_gif_before_frames": max(0, int(getattr(orchestration_config, "ALARM_GIF_BEFORE_FRAMES", 7) or 0)),
        "alarm_gif_after_frames": max(0, int(getattr(orchestration_config, "ALARM_GIF_AFTER_FRAMES", 7) or 0)),
    }


class RunLogger:
    """Small file logger that also keeps recent messages in memory."""

    def __init__(self, path: Path) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.messages: List[str] = []
        self._lock = threading.Lock()

    def __call__(self, text: str) -> None:
        self.write(text)

    def write(self, text: str) -> None:
        line = str(text)
        stamped = f"[{_now()}] {line}"
        with self._lock:
            self.messages.append(stamped)
            with self.path.open("a", encoding="utf-8") as f:
                f.write(stamped + "\n")
        print(stamped)

    def progress(self, cur: int, total: int, label: str) -> None:
        if total <= 0:
            self.write(f"{label}: {cur}/{total}")
            return
        percent = min(100.0, max(0.0, float(cur) * 100.0 / float(total)))
        self.write(f"{label}: {cur}/{total} ({percent:.1f}%)")


class SpecialLogger:
    """Chinese-only focused log stream for field operation.

    [专项日志][生产迭代01-中文专项日志]
    修改人: Shiver; 修改时间: 2026-06-25;
    修改逻辑: 新增独立专项日志，统一前缀、中文字段名，同时写 Docker 输出和按天落盘文件。
    """

    def __init__(self, *, log_dir: Path, instance_id: str, enabled: bool = True) -> None:
        self.log_dir = Path(log_dir)
        self.instance_id = _instance_log_prefix(instance_id)
        self.enabled = bool(enabled)
        self._lock = threading.Lock()

    def _path(self) -> Path:
        return _instance_log_path(self.log_dir, self.instance_id, "专项日志.log")

    def write(self, category: str, message: str) -> None:
        if not self.enabled:
            return
        stamped = f"[{_now()}] [{SPECIAL_LOG_PREFIX}-{str(category).strip() or '未分类'}] {str(message)}"
        with self._lock:
            try:
                path = self._path()
                path.parent.mkdir(parents=True, exist_ok=True)
                with path.open("a", encoding="utf-8") as f:
                    f.write(stamped + "\n")
            except Exception as exc:
                print(f"[{_now()}] [{SPECIAL_LOG_PREFIX}-写入失败] 错误={exc}", file=sys.stderr)
        print(stamped)


class _ProviderImageMap:
    """Minimal dict-like adapter that retrieves source frames lazily."""

    def __init__(self, provider) -> None:
        # [1.内存模型预加载整段视频全部帧][生产迭代02-有界流式]
        # 修改人: Shiver; 修改时间: 2026-06-22;
        # 修改逻辑: 告警图/GIF/testoutput继续使用原有mapping.get接口，但不构造全量原图字典。
        self.provider = provider

    def get(self, sample_index: object, default=None):
        getter = getattr(self.provider, "get_image", None)
        if not callable(getter):
            return default
        try:
            normalized_index = int(sample_index)
        except (TypeError, ValueError):
            return default
        # [1.内存模型预加载整段视频全部帧][通篇审查-异常透明]
        # 修改人: Shiver; 修改时间: 2026-06-23;
        # 修改逻辑: 仅兼容无效索引；源视频读取异常必须上抛，禁止静默丢失告警图/GIF。
        image = getter(normalized_index)
        return image if image is not None else default


def _safe_run_id(value: str) -> str:
    text = str(value or "").strip()
    if not text:
        text = app_compact_timestamp()
    cleaned = "".join(ch if ch.isalnum() or ch in {"-", "_", "."} else "_" for ch in text)
    return cleaned[:100] or app_compact_timestamp()


def _run_id_with_instance(base_run_id: str, instance_id: str) -> str:
    base = _safe_run_id(base_run_id)
    instance = _safe_run_id(instance_id).strip("._-")
    if not instance:
        return base
    suffix = f"--{instance}"
    if base.endswith(suffix):
        return base
    max_base_len = max(1, 100 - len(suffix))
    return f"{base[:max_base_len]}{suffix}"


def _video_output_name(value: object) -> str:
    text = str(value or "").strip().strip('"').replace("\\", "/")
    if not text:
        return ""
    name = Path(text).stem or text
    return _safe_run_id(name)


def _input_output_name(input_info: Dict[str, object]) -> str:
    first_item = (input_info.get("video_items") or [{}])[0]
    if isinstance(first_item, dict):
        for key in ("raw_video_path", "video_path", "local_video_path"):
            name = _video_output_name(first_item.get(key))
            if name:
                return name
    first_rejected = (input_info.get("rejected_video_items") or [{}])[0]
    if isinstance(first_rejected, dict):
        name = _video_output_name(first_rejected.get("raw_video_path") or first_rejected.get("video_path"))
        if name:
            return name
    for key in ("raw_video_path", "video_path", "local_video_path"):
        name = _video_output_name(input_info.get(key))
        if name:
            return name
    return _safe_run_id(str(input_info.get("task_id") or app_compact_timestamp()))


def _item_video_path(item: Dict[str, object]) -> str:
    return str(item.get("raw_video_path") or item.get("video_path") or item.get("local_video_path") or "").strip()


def _item_video_index(item: Dict[str, object], fallback: int) -> int:
    try:
        return int(item.get("index", fallback) or fallback)
    except Exception:
        return int(fallback)


def _task_video_callback_entry(
    input_info: Dict[str, object],
    item: Dict[str, object],
    *,
    status: str,
    processing_time_ms: int,
) -> Dict[str, object]:
    return {
        "machine_type": str(input_info.get("machine_type") or "").strip(),
        "eqp_id": str(input_info.get("eqp_id") or "").strip(),
        "video_path": _item_video_path(item),
        "status": str(status or "").strip(),
        "algorithm_source": str(input_info.get("algorithm_source") or "aqiu").strip() or "aqiu",
        "algorithm_type": str(input_info.get("algorithm_type") or "").strip(),
        "processing_time": int(processing_time_ms),
    }


def _build_task_callback_task(input_info: Dict[str, object], result: Dict[str, object]) -> Dict[str, object]:
    videos: List[Dict[str, object]] = []
    default_status = "success" if str(result.get("status") or "") == "success" else "failed"
    default_processing_time = int(result.get("processing_time") or 0)
    protocol_status_by_index: Dict[int, str] = {}
    processing_time_by_index: Dict[int, int] = {}
    for index, protocol_result in enumerate(result.get("protocol_results", []) or []):
        if not isinstance(protocol_result, dict):
            continue
        try:
            video_index = int(protocol_result.get("video_index", index) or index)
        except Exception:
            video_index = index
        protocol_status = str(protocol_result.get("status") or "").strip()
        protocol_status_by_index[video_index] = "failed" if protocol_status == "internal_error" else default_status
        try:
            processing_time_by_index[video_index] = int(protocol_result.get("processing_time") or default_processing_time)
        except Exception:
            processing_time_by_index[video_index] = default_processing_time
    for fallback, item in enumerate(input_info.get("video_items", [])):
        if not isinstance(item, dict):
            continue
        video_index = _item_video_index(item, fallback)
        videos.append(
            _task_video_callback_entry(
                input_info,
                item,
                status=protocol_status_by_index.get(video_index, default_status),
                processing_time_ms=processing_time_by_index.get(video_index, default_processing_time),
            )
        )
    for item in input_info.get("rejected_video_items", []):
        if not isinstance(item, dict):
            continue
        videos.append(
            _task_video_callback_entry(
                input_info,
                item,
                status="rejected",
                processing_time_ms=default_processing_time,
            )
        )
    return {"task_id": str(input_info.get("task_id") or "").strip(), "videos": videos}


def _noop_rejected_result(
    *,
    run_id: str,
    request_id: str,
    input_info: Dict[str, object],
    json_path: Path,
    log_path: Path,
    started: float,
) -> Dict[str, object]:
    processing_time_ms = int((time.monotonic() - started) * 1000)
    return {
        "request_id": request_id,
        "run_id": run_id,
        "status": "success",
        "overall_result": "REJECTED",
        "has_ng": False,
        "ng_labels": [],
        "input": input_info,
        "models": [],
        "outputs": [],
        "infer_dbs": [],
        "rule_dbs": [],
        "frames": [],
        "per_db_results": [],
        "summary": {"rejected_video_count": len(input_info.get("rejected_video_items", []))},
        "artifacts": {"original_frame_dirs": [], "rule_render_dirs": [], "infer_dbs": [], "rule_dbs": []},
        "logs": {"result_json": str(json_path), "text_log": str(log_path)},
        "callback": {"attempted": False, "url": "", "status_code": None, "error": "所有视频均被过滤配置拒绝，跳过告警回调", "response_text": ""},
        "alarm_callback": {"attempted": False, "url": "", "status_code": None, "error": "所有视频均被过滤配置拒绝，跳过告警回调", "response_text": ""},
        "protocol_result": None,
        "protocol_results": [],
        "processing_time": processing_time_ms,
    }

def _output_spec_to_dict(spec) -> Dict[str, object]:
    return {
        "index": int(spec.index),
        "key": spec.key,
        "tool_id": spec.tool_id,
        "node_id": spec.node_id,
        "edge_type": spec.edge_type,
        "labels": list(spec.labels),
        "column": spec.column,
        "model_index": int(getattr(spec, "model_index", 0) or 0),
        "model_name": str(getattr(spec, "model_name", "") or ""),
    }


def _now() -> str:
    return app_strftime("%Y-%m-%d %H:%M:%S")


def _today() -> str:
    return app_today()


def _date_part(value: object) -> str:
    return str(value or "").strip()[:10]


def _safe_int(value: object, default: int = 0) -> int:
    try:
        return int(value)
    except Exception:
        return int(default)


def _safe_float(value: object, default: float = 0.0) -> float:
    try:
        return float(value)
    except Exception:
        return float(default)


# [专项日志][生产迭代02-瓶颈拆分]
# 修改人: Shiver; 修改时间: 2026-06-25;
# 修改逻辑: 专项日志新增“阶段均值/模型调用均值/等待/runtime等待/视频读取解码”拆分，便于并发压测快速定位卡点。
def _avg_ms_per_count(total_ms: object, count: object) -> float:
    item_count = _safe_int(count, 0)
    if item_count <= 0:
        return 0.0
    return float(_safe_float(total_ms, 0.0)) / float(item_count)


def _format_avg_ms_per_frame_cn(total_ms: object, count: object) -> str:
    item_count = _safe_int(count, 0)
    if item_count <= 0:
        return "未知"
    return f"{_avg_ms_per_count(total_ms, item_count):.2f}毫秒/帧"


def _yes_no_cn(value: object) -> str:
    return "是" if bool(value) else "否"


def _source_video_io_total_ms(detail: Dict[str, object]) -> float:
    return (
        _safe_float(detail.get("source_video_safe_path_ms"), 0.0)
        + _safe_float(detail.get("source_video_open_ms"), 0.0)
        + _safe_float(detail.get("source_video_metadata_ms"), 0.0)
        + _safe_float(detail.get("source_video_seek_ms"), 0.0)
        + _safe_float(detail.get("source_video_read_decode_ms"), 0.0)
    )


def _stage_bottleneck_guess_cn(stage_ms: object, frame_count: object, detail: Dict[str, object]) -> str:
    stage_total = max(0.0, _safe_float(stage_ms, 0.0))
    frames = _safe_int(frame_count, 0)
    runtime_sum = max(0.0, _safe_float(detail.get("runtime_sum_ms"), 0.0))
    runtime_acquire = max(0.0, _safe_float(detail.get("runtime_acquire_wait_ms"), 0.0))
    wait_sum = max(0.0, _safe_float(detail.get("wait_ms"), 0.0))
    video_io = max(0.0, _source_video_io_total_ms(detail))
    if stage_total <= 0:
        return "未知"
    reasons: List[str] = []
    if runtime_acquire >= max(500.0, stage_total * 0.15):
        reasons.append("runtime池等待")
    if video_io >= max(500.0, stage_total * 0.15):
        reasons.append("视频读取/解码")
    runtime_avg = _avg_ms_per_count(runtime_sum, frames)
    if runtime_sum >= max(500.0, stage_total * 0.55) or runtime_avg >= 20.0:
        reasons.append("模型调用")
    if wait_sum >= max(500.0, stage_total * 0.30) and "runtime池等待" not in reasons and "模型调用" not in reasons:
        reasons.append("Future等待/线程调度")
    return "、".join(reasons) if reasons else "暂无明显单点"


def _format_infer_stage_bottleneck_cn(
    *,
    label: str,
    stage_ms: object,
    frame_count: object,
    detail: Dict[str, object],
) -> str:
    frames = _safe_int(frame_count, 0)
    read_frames = _safe_int(detail.get("source_video_read_frame_count"), 0)
    read_avg_denominator = read_frames if read_frames > 0 else frames
    read_decode_ms = _safe_float(detail.get("source_video_read_decode_ms"), 0.0)
    runtime_sum_ms = _safe_float(detail.get("runtime_sum_ms"), 0.0)
    runtime_acquire_ms = _safe_float(detail.get("runtime_acquire_wait_ms"), 0.0)
    wait_ms = _safe_float(detail.get("wait_ms"), 0.0)
    append_output_ms = _safe_float(detail.get("append_output_ms"), 0.0)
    window_build_ms = _safe_float(detail.get("window_build_ms"), 0.0)
    empty_output_fill_ms = _safe_float(detail.get("empty_output_fill_ms"), 0.0)
    trigger_eval_ms = _safe_float(detail.get("stage2_sparse_trigger_eval_ms"), 0.0)
    other_io_ms = (
        _safe_float(detail.get("source_video_safe_path_ms"), 0.0)
        + _safe_float(detail.get("source_video_open_ms"), 0.0)
        + _safe_float(detail.get("source_video_metadata_ms"), 0.0)
        + _safe_float(detail.get("source_video_seek_ms"), 0.0)
    )
    parts = [
        f"{label}阶段总耗时={_format_duration_cn_ms(stage_ms)}",
        f"{label}阶段均值={_format_avg_ms_per_frame_cn(stage_ms, frames)}",
        f"{label}模型调用总耗时={_format_duration_cn_ms(runtime_sum_ms)}",
        f"{label}模型调用均值={_format_avg_ms_per_frame_cn(runtime_sum_ms, frames)}",
        f"{label}runtime池等待={_format_duration_cn_ms(runtime_acquire_ms)}",
        f"{label}runtime池等待均值={_format_avg_ms_per_frame_cn(runtime_acquire_ms, frames)}",
        f"{label}Future等待={_format_duration_cn_ms(wait_ms)}",
        f"{label}Future等待均值={_format_avg_ms_per_frame_cn(wait_ms, frames)}",
        f"{label}视频读取解码={_format_duration_cn_ms(read_decode_ms)}",
        f"{label}视频读取解码均值={_format_avg_ms_per_frame_cn(read_decode_ms, read_avg_denominator)}",
        f"{label}视频打开/定位/元数据耗时={_format_duration_cn_ms(other_io_ms)}",
        f"{label}输出整理耗时={_format_duration_cn_ms(append_output_ms)}",
    ]
    if window_build_ms > 0:
        parts.append(f"{label}窗口构建耗时={_format_duration_cn_ms(window_build_ms)}")
    if empty_output_fill_ms > 0:
        parts.append(f"{label}空结果填充耗时={_format_duration_cn_ms(empty_output_fill_ms)}")
    if trigger_eval_ms > 0:
        parts.append(f"{label}稀疏命中规则评估耗时={_format_duration_cn_ms(trigger_eval_ms)}")
    parts.extend(
        [
            f"{label}处理帧数={frames}",
            f"{label}视频读帧次数={_safe_int(detail.get('source_video_read_call_count'), 0)}",
            f"{label}视频读到帧数={read_frames}",
            f"{label}视频产出帧数={_safe_int(detail.get('source_video_yield_frame_count'), 0)}",
            f"{label}单次读帧最大耗时={_format_duration_cn_ms(detail.get('source_video_read_decode_max_ms'))}",
            f"{label}首帧读取耗时={_format_duration_cn_ms(detail.get('source_video_first_frame_read_ms'))}",
            f"{label}疑似NAS={_yes_no_cn(detail.get('source_is_probable_nas'))}",
            f"{label}挂载类型={detail.get('source_mount_type') or '未知'}",
            f"{label}疑似卡点={_stage_bottleneck_guess_cn(stage_ms, frames, detail)}",
        ]
    )
    return "，".join(parts)


TASK_TIMING_STAGES = (
    "task_total_ms",
    "input_prepare_ms",
    "infer_total_ms",
    "video_post_total_ms",
    "merge_summary_ms",
    "alarm_callback_ms",
    "cleanup_ms",
    "json_write_ms",
)

VIDEO_TIMING_STAGES = (
    "video_total_ms",
    "infer_ms",
    "post_infer_total_ms",
    "rule_execute_ms",
    "rule_render_ms",
    "rule_result_read_ms",
    "frame_assembly_ms",
    "testoutput_save_ms",
    "protocol_materialize_ms",
    "video_release_ms",
)

PROGRESS_TIMING_FIELDS = (
    ("avg_task_total_ms", "task_total_ms"),
    ("avg_task_infer_total_ms", "infer_total_ms"),
    ("avg_task_video_post_total_ms", "video_post_total_ms"),
    ("avg_task_alarm_callback_ms", "alarm_callback_ms"),
    ("avg_task_json_write_ms", "json_write_ms"),
    ("avg_video_total_ms", "video_total_ms"),
    ("avg_video_infer_ms", "infer_ms"),
    ("avg_video_post_infer_total_ms", "post_infer_total_ms"),
    ("avg_video_rule_execute_ms", "rule_execute_ms"),
    ("avg_video_rule_render_ms", "rule_render_ms"),
    ("avg_video_protocol_materialize_ms", "protocol_materialize_ms"),
)


def _elapsed_ms(started: float) -> int:
    return max(0, int((time.monotonic() - started) * 1000))


def _zero_timing(stage_order) -> Dict[str, int]:
    return {str(stage): 0 for stage in stage_order}


def _format_timing_fields(stage_ms: Dict[str, object], stage_order) -> str:
    parts = []
    for stage in stage_order:
        parts.append(f"{stage}={_safe_int(stage_ms.get(stage), 0)}")
    return "，".join(parts)


class _TimingStats:
    """Thread-safe daily timing totals with fixed stage keys only."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._date = _today()
        self._task_count = 0
        self._video_count = 0
        self._task_totals = _zero_timing(TASK_TIMING_STAGES)
        self._video_totals = _zero_timing(VIDEO_TIMING_STAGES)

    def _reset_if_needed(self) -> None:
        today = _today()
        if self._date == today:
            return
        self._date = today
        self._task_count = 0
        self._video_count = 0
        self._task_totals = _zero_timing(TASK_TIMING_STAGES)
        self._video_totals = _zero_timing(VIDEO_TIMING_STAGES)

    def record_task(self, stage_ms: Dict[str, object]) -> None:
        with self._lock:
            self._reset_if_needed()
            self._task_count += 1
            for stage in TASK_TIMING_STAGES:
                self._task_totals[stage] += max(0, _safe_int(stage_ms.get(stage), 0))

    def record_video(self, stage_ms: Dict[str, object]) -> None:
        with self._lock:
            self._reset_if_needed()
            self._video_count += 1
            for stage in VIDEO_TIMING_STAGES:
                self._video_totals[stage] += max(0, _safe_int(stage_ms.get(stage), 0))

    def snapshot(self) -> Dict[str, int]:
        with self._lock:
            self._reset_if_needed()
            task_count = int(self._task_count)
            video_count = int(self._video_count)
            task_totals = dict(self._task_totals)
            video_totals = dict(self._video_totals)
        snapshot: Dict[str, int] = {
            "timing_task_count": task_count,
            "timing_video_count": video_count,
        }
        for output_key, stage in PROGRESS_TIMING_FIELDS:
            if stage in task_totals:
                count = task_count
                total = task_totals.get(stage, 0)
            else:
                count = video_count
                total = video_totals.get(stage, 0)
            snapshot[output_key] = int(total / count) if count > 0 else 0
        return snapshot


def _format_progress_timing_fields(timing: Dict[str, int]) -> str:
    keys = ["timing_task_count", "timing_video_count"] + [key for key, _stage in PROGRESS_TIMING_FIELDS]
    return " ".join(f"{key}={_safe_int(timing.get(key), 0)}" for key in keys)


def _daily_log_dir(log_dir: Path, date_text: Optional[str] = None) -> Path:
    return Path(log_dir) / str(date_text or _today())


def _instance_log_prefix(instance_id: str) -> str:
    prefix = _safe_run_id(instance_id).strip("._-")
    return prefix or "infer-cache"


def _instance_log_path(log_dir: Path, instance_id: str, suffix: str, date_text: Optional[str] = None) -> Path:
    return _daily_log_dir(log_dir, date_text=date_text) / f"{_instance_log_prefix(instance_id)}_{suffix}"


def _append_video_timing_log(log_dir: Path, instance_id: str, line: str) -> None:
    path = _instance_log_path(log_dir, instance_id, "video_timing.log")
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as f:
            f.write(f"[{_now()}] {line}\n")
    except Exception as exc:
        print(f"[{_now()}] [耗时日志] 写入滚动视频耗时日志失败：{exc}", file=sys.stderr)


def _append_task_timing_log(log_dir: Path, instance_id: str, line: str) -> None:
    path = _instance_log_path(log_dir, instance_id, "task_timing.log")
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as f:
            f.write(f"[{_now()}] {line}\n")
    except Exception as exc:
        print(f"[{_now()}] [耗时日志] 写入滚动任务耗时日志失败：{exc}", file=sys.stderr)


def _read_int_file(path: str) -> Optional[int]:
    try:
        text = Path(path).read_text(encoding="utf-8").strip()
        if not text or text == "max":
            return None
        return int(text)
    except Exception:
        return None


def _format_bytes(value: Optional[int]) -> str:
    if value is None or value < 0:
        return "unknown"
    units = ["B", "KiB", "MiB", "GiB", "TiB"]
    size = float(value)
    unit = units[0]
    for unit in units:
        if size < 1024.0 or unit == units[-1]:
            break
        size /= 1024.0
    if unit == "B":
        return f"{int(size)}{unit}"
    return f"{size:.1f}{unit}"


def _container_memory_snapshot() -> Dict[str, object]:
    usage = _read_int_file("/sys/fs/cgroup/memory.current")
    limit = _read_int_file("/sys/fs/cgroup/memory.max")
    if usage is None:
        usage = _read_int_file("/sys/fs/cgroup/memory/memory.usage_in_bytes")
    if limit is None:
        limit = _read_int_file("/sys/fs/cgroup/memory/memory.limit_in_bytes")
    # Docker may expose a huge sentinel when memory is unlimited; avoid printing a misleading percentage.
    if limit is not None and limit >= (1 << 60):
        limit = None
    percent = None
    if usage is not None and limit and limit > 0:
        percent = min(999.9, max(0.0, float(usage) * 100.0 / float(limit)))
    return {
        "usage_bytes": usage,
        "limit_bytes": limit,
        "usage_text": _format_bytes(usage),
        "limit_text": _format_bytes(limit),
        "percent": percent,
    }


def _container_pids_snapshot() -> Optional[int]:
    """Read current container task/thread count from cgroup when available."""
    # [1.内存模型预加载整段视频全部帧][生产迭代01-日志]
    # 修改人: Shiver; 修改时间: 2026-06-22;
    # 修改逻辑: 同步记录PIDS，区分图像内存峰值与HTTP/SMB线程持续累积。
    value = _read_int_file("/sys/fs/cgroup/pids.current")
    if value is None:
        value = _read_int_file("/sys/fs/cgroup/pids/pids.current")
    return value


def _parse_number(value: object) -> Optional[float]:
    text = str(value or "").strip()
    if not text or text.lower() in {"n/a", "na", "none", "null", "unknown", "[not supported]"}:
        return None
    try:
        return float(text)
    except (TypeError, ValueError):
        return None


def _parse_int_number(value: object) -> Optional[int]:
    number = _parse_number(value)
    return int(number) if number is not None else None


def _read_proc_status_kib(*keys: str) -> Dict[str, int]:
    wanted = set(keys)
    values: Dict[str, int] = {}
    try:
        for line in Path("/proc/self/status").read_text(encoding="utf-8", errors="replace").splitlines():
            if ":" not in line:
                continue
            key, raw_value = line.split(":", 1)
            if key not in wanted:
                continue
            parts = raw_value.strip().split()
            if not parts:
                continue
            values[key] = int(parts[0]) * 1024
    except Exception:
        return {}
    return values


def _process_memory_snapshot() -> Dict[str, object]:
    values = _read_proc_status_kib("VmRSS", "VmSize")
    if not values:
        return {"available": False, "error": "process memory status unavailable"}
    rss = values.get("VmRSS")
    vms = values.get("VmSize")
    return {
        "available": True,
        "rss_bytes": rss,
        "rss_text": _format_bytes(rss),
        "vms_bytes": vms,
        "vms_text": _format_bytes(vms),
    }


def _system_memory_snapshot() -> Dict[str, object]:
    values: Dict[str, int] = {}
    try:
        for line in Path("/proc/meminfo").read_text(encoding="utf-8", errors="replace").splitlines():
            if ":" not in line:
                continue
            key, raw_value = line.split(":", 1)
            if key not in {"MemTotal", "MemAvailable", "MemFree"}:
                continue
            parts = raw_value.strip().split()
            if parts:
                values[key] = int(parts[0]) * 1024
    except Exception:
        return {"available": False, "error": "system memory status unavailable"}
    total = values.get("MemTotal")
    available = values.get("MemAvailable", values.get("MemFree"))
    free = values.get("MemFree")
    used = total - available if total is not None and available is not None else None
    percent = None
    if total and used is not None:
        percent = min(999.9, max(0.0, float(used) * 100.0 / float(total)))
    return {
        "available": total is not None,
        "total_bytes": total,
        "total_text": _format_bytes(total),
        "available_bytes": available,
        "available_text": _format_bytes(available),
        "free_bytes": free,
        "free_text": _format_bytes(free),
        "used_bytes": used,
        "used_text": _format_bytes(used),
        "percent": percent,
    }


def _cpu_quota_snapshot() -> Dict[str, object]:
    try:
        text = Path("/sys/fs/cgroup/cpu.max").read_text(encoding="utf-8").strip()
        parts = text.split()
        if len(parts) >= 2:
            period_us = int(parts[1])
            if parts[0] == "max":
                return {"available": True, "limited": False, "quota_us": None, "period_us": period_us, "quota_cores": None}
            quota_us = int(parts[0])
            quota_cores = float(quota_us) / float(period_us) if period_us > 0 else None
            return {"available": True, "limited": True, "quota_us": quota_us, "period_us": period_us, "quota_cores": quota_cores}
    except Exception:
        pass
    quota_us = _read_int_file("/sys/fs/cgroup/cpu/cpu.cfs_quota_us")
    period_us = _read_int_file("/sys/fs/cgroup/cpu/cpu.cfs_period_us")
    if quota_us is None or period_us is None:
        return {"available": False, "limited": None, "quota_us": None, "period_us": None, "quota_cores": None}
    if quota_us < 0:
        return {"available": True, "limited": False, "quota_us": quota_us, "period_us": period_us, "quota_cores": None}
    quota_cores = float(quota_us) / float(period_us) if period_us > 0 else None
    return {"available": True, "limited": True, "quota_us": quota_us, "period_us": period_us, "quota_cores": quota_cores}


def _read_proc_stat_cpu() -> Optional[Tuple[int, int]]:
    try:
        first_line = Path("/proc/stat").read_text(encoding="utf-8", errors="replace").splitlines()[0]
        parts = first_line.split()
        if not parts or parts[0] != "cpu":
            return None
        numbers = [int(value) for value in parts[1:]]
    except Exception:
        return None
    total = sum(numbers)
    idle = numbers[3] + (numbers[4] if len(numbers) > 4 else 0)
    return total, idle


def _host_cpu_percent_snapshot(sample_sec: float = 0.05) -> Dict[str, object]:
    before = _read_proc_stat_cpu()
    if before is None:
        return {"available": False, "error": "host cpu status unavailable"}
    time.sleep(max(0.01, min(0.2, float(sample_sec))))
    after = _read_proc_stat_cpu()
    if after is None:
        return {"available": False, "error": "host cpu status unavailable"}
    total_delta = after[0] - before[0]
    idle_delta = after[1] - before[1]
    percent = None
    if total_delta > 0:
        percent = min(100.0, max(0.0, (1.0 - float(idle_delta) / float(total_delta)) * 100.0))
    return {"available": percent is not None, "percent": percent}


def _read_container_cpu_usage_ns() -> Optional[int]:
    try:
        for line in Path("/sys/fs/cgroup/cpu.stat").read_text(encoding="utf-8", errors="replace").splitlines():
            parts = line.split()
            if len(parts) == 2 and parts[0] == "usage_usec":
                return int(parts[1]) * 1000
    except Exception:
        pass
    return _read_int_file("/sys/fs/cgroup/cpuacct/cpuacct.usage")


def _container_cpu_percent_snapshot(sample_sec: float = 0.05) -> Dict[str, object]:
    before = _read_container_cpu_usage_ns()
    if before is None:
        return {"available": False, "error": "container cpu usage unavailable"}
    started = time.monotonic()
    time.sleep(max(0.01, min(0.2, float(sample_sec))))
    after = _read_container_cpu_usage_ns()
    elapsed = time.monotonic() - started
    if after is None or elapsed <= 0:
        return {"available": False, "error": "container cpu usage unavailable"}
    usage_delta_sec = max(0.0, float(after - before) / 1_000_000_000.0)
    percent_of_one_core = usage_delta_sec * 100.0 / elapsed
    quota = _cpu_quota_snapshot()
    quota_cores = quota.get("quota_cores") if isinstance(quota, dict) else None
    percent_of_quota = None
    if isinstance(quota_cores, (int, float)) and quota_cores > 0:
        percent_of_quota = percent_of_one_core / float(quota_cores)
    return {
        "available": True,
        "usage_delta_ns": max(0, int(after - before)),
        "sample_ms": int(elapsed * 1000),
        "percent_of_one_core": percent_of_one_core,
        "percent_of_quota": percent_of_quota,
    }


def _load_average_snapshot() -> Dict[str, object]:
    try:
        one, five, fifteen = os.getloadavg()
    except Exception:
        return {"available": False, "error": "load average unavailable"}
    return {"available": True, "load1": one, "load5": five, "load15": fifteen}


def _gpu_snapshot() -> Dict[str, object]:
    nvidia_smi = shutil.which("nvidia-smi")
    if not nvidia_smi:
        return {"available": False, "error": "nvidia-smi not found", "gpus": []}
    query = "index,name,utilization.gpu,utilization.memory,memory.used,memory.total,temperature.gpu,power.draw"
    try:
        completed = subprocess.run(
            [nvidia_smi, f"--query-gpu={query}", "--format=csv,noheader,nounits"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=1.0,
            shell=False,
        )
    except subprocess.TimeoutExpired:
        return {"available": False, "error": "nvidia-smi timed out", "gpus": []}
    except Exception as exc:
        return {"available": False, "error": str(exc), "gpus": []}
    if completed.returncode != 0:
        error = (completed.stderr or completed.stdout or "nvidia-smi failed").strip()
        return {"available": False, "error": error, "gpus": []}
    gpus = []
    try:
        for row in csv.reader(completed.stdout.splitlines()):
            if len(row) < 8:
                continue
            index, name, gpu_util, memory_util, memory_used, memory_total, temperature, power_draw = [item.strip() for item in row[:8]]
            used_mib = _parse_int_number(memory_used)
            total_mib = _parse_int_number(memory_total)
            gpus.append(
                {
                    "index": _parse_int_number(index),
                    "name": name,
                    "gpu_util_percent": _parse_number(gpu_util),
                    "memory_util_percent": _parse_number(memory_util),
                    "memory_used_mib": used_mib,
                    "memory_total_mib": total_mib,
                    "memory_used_text": _format_bytes(used_mib * 1024 * 1024 if used_mib is not None else None),
                    "memory_total_text": _format_bytes(total_mib * 1024 * 1024 if total_mib is not None else None),
                    "temperature_c": _parse_number(temperature),
                    "power_draw_w": _parse_number(power_draw),
                }
            )
    except Exception as exc:
        return {"available": False, "error": f"failed to parse nvidia-smi output: {exc}", "gpus": []}
    return {"available": bool(gpus), "gpus": gpus, "error": None if gpus else "no gpu rows returned"}


def _gpu_status_text_from_snapshot(snapshot: Dict[str, object], device_ids: List[int]) -> str:
    # [专项日志][生产迭代01-GPU健康状态]
    # 修改人: Shiver; 修改时间: 2026-06-25;
    # 修改逻辑: 专项健康日志只输出当前实例配置的GPU，便于多容器场景快速核对CUDA利用率和显存占用。
    if not snapshot.get("available"):
        return f"GPU状态=不可用，原因={snapshot.get('error') or '未知'}"
    configured_ids = {int(value) for value in (device_ids or [0])}
    all_gpus = [item for item in (snapshot.get("gpus") or []) if isinstance(item, dict)]
    selected = [item for item in all_gpus if item.get("index") in configured_ids]
    if not selected:
        visible_ids = ",".join(str(item.get("index")) for item in all_gpus) or "无"
        return f"配置GPU={','.join(str(item) for item in sorted(configured_ids))}，GPU状态=未找到配置GPU，可见GPU={visible_ids}"
    parts = []
    for item in selected:
        gpu_index = item.get("index")
        cuda_util = item.get("gpu_util_percent")
        memory_util = item.get("memory_util_percent")
        used_text = item.get("memory_used_text") or "未知"
        total_text = item.get("memory_total_text") or "未知"
        temperature = item.get("temperature_c")
        power = item.get("power_draw_w")
        detail = (
            f"GPU{gpu_index}：CUDA利用率={_format_percent_cn(cuda_util)}，"
            f"显存={used_text}/{total_text}，显存占用率={_format_percent_cn(memory_util)}"
        )
        if temperature is not None:
            detail += f"，温度={temperature}℃"
        if power is not None:
            detail += f"，功耗={power}W"
        parts.append(detail)
    return "；".join(parts)


def _gpu_status_text_for_devices(device_ids: List[int]) -> str:
    return _gpu_status_text_from_snapshot(_gpu_snapshot(), device_ids)


def _resource_snapshot() -> Dict[str, object]:
    return {
        "timestamp": _now(),
        "memory": {
            "container": _container_memory_snapshot(),
            "system": _system_memory_snapshot(),
            "process": _process_memory_snapshot(),
        },
        "cpu": {
            "cpu_count": os.cpu_count(),
            "load_avg": _load_average_snapshot(),
            "quota": _cpu_quota_snapshot(),
            "host": _host_cpu_percent_snapshot(),
            "container": _container_cpu_percent_snapshot(),
        },
        "gpu": _gpu_snapshot(),
        "pids": {
            "container_current": _container_pids_snapshot(),
            "python_threads": threading.active_count(),
        },
    }


def _memory_fix_snapshot_text() -> str:
    memory = _container_memory_snapshot()
    pids = _container_pids_snapshot()
    return (
        f"memory_usage={memory.get('usage_text')} "
        f"memory_bytes={memory.get('usage_bytes')} "
        f"pids={pids if pids is not None else 'unknown'} "
        f"python_threads={threading.active_count()}"
    )


def _cleanup_old_log_dirs(log_dir: Path, retention_days: int) -> None:
    root = Path(log_dir)
    if not root.exists():
        return
    cutoff = time.time() - max(1, int(retention_days or 7)) * 86400
    for child in root.iterdir():
        try:
            if not child.is_dir():
                continue
            # Only remove day-split directories such as 2026-06-16.
            if len(child.name) != 10 or child.name[4] != "-" or child.name[7] != "-":
                continue
            if child.stat().st_mtime < cutoff:
                shutil.rmtree(child)
                print(f"[{_now()}] [日志清理] 删除过期日志目录：{child}")
        except Exception as exc:
            print(f"[{_now()}] [日志清理] 删除过期日志失败：{child}，error={exc}", file=sys.stderr)


def _cleanup_old_log_files(log_dir: Path, retention_days: int) -> None:
    root = Path(log_dir)
    if not root.exists():
        return
    cutoff = time.time() - max(1, int(retention_days or 7)) * 86400
    for pattern in ("*.log", "*.json"):
        for child in root.glob(pattern):
            try:
                if child.is_file() and child.stat().st_mtime < cutoff:
                    child.unlink()
                    print(f"[{_now()}] [日志清理] 删除过期日志文件：{child}")
            except Exception as exc:
                print(f"[{_now()}] [日志清理] 删除过期日志失败：{child}，error={exc}", file=sys.stderr)


def _copy_if_exists(src: object, dst: object) -> bool:
    src_path = Path(str(src or ""))
    if not src_path.exists() or not src_path.is_file():
        return False
    dst_path = Path(str(dst))
    dst_path.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src_path, dst_path)
    return True


def _alarm_source_video_path(input_info: Dict[str, object]) -> str:
    candidates = [
        input_info.get("local_video_path"),
        input_info.get("video_path"),
        input_info.get("raw_video_path"),
    ]
    video_paths = input_info.get("video_paths")
    if isinstance(video_paths, list) and video_paths:
        first = video_paths[0]
        if isinstance(first, dict):
            candidates.extend([
                first.get("local_video_path"),
                first.get("video_path"),
                first.get("raw_video_path"),
                first.get("avi_path"),
            ])
    for value in candidates:
        text = str(value or "").strip()
        if text:
            return text
    return ""


def _copy_alarm_original_video(*, source_video_path: str, target_video_path: str, logger: RunLogger) -> bool:
    if not str(source_video_path or "").strip():
        logger.write("告警原始视频源路径为空，跳过视频落盘")
        return False
    src_path = Path(str(source_video_path))
    if not src_path.exists() or not src_path.is_file():
        logger.write(f"告警原始视频源文件不存在，跳过视频落盘：{src_path}")
        return False
    if not str(target_video_path or "").strip():
        logger.write("告警原始视频目标路径为空，跳过视频落盘")
        return False
    dst_path = Path(str(target_video_path))
    try:
        dst_path.parent.mkdir(parents=True, exist_ok=True)
        if dst_path.exists() and os.path.samefile(str(src_path), str(dst_path)):
            size = src_path.stat().st_size
            logger.write(f"告警原始视频已在目标路径：{dst_path}，size={size}")
            return True
        shutil.copy2(src_path, dst_path)
        size = dst_path.stat().st_size
        logger.write(f"告警原始视频已写入：source={src_path}，target={dst_path}，size={size}")
        return True
    except Exception as exc:
        logger.write(f"告警原始视频写入失败：source={src_path}，target={dst_path}，error={exc}")
        return False


def _save_jpg_if_exists(src: object, dst: object) -> bool:
    src_path = Path(str(src or ""))
    if not src_path.exists() or not src_path.is_file():
        return False
    dst_path = Path(str(dst))
    dst_path.parent.mkdir(parents=True, exist_ok=True)
    try:
        from PIL import Image

        with Image.open(str(src_path)) as img:
            img.convert("RGB").save(str(dst_path), format="JPEG", quality=95)
        return True
    except Exception:
        shutil.copy2(src_path, dst_path)
        return True


def _safe_file_part(value: object, default: str = "output") -> str:
    text = str(value or "").strip() or default
    for ch in '<>:"/\\|?*':
        text = text.replace(ch, "_")
    text = "".join(ch if ch.isprintable() else "_" for ch in text).strip(" .")
    return text[:80] or default


def _frame_labels(frame: Dict[str, object]) -> List[str]:
    labels = frame.get("labels") if isinstance(frame, dict) else []
    if not isinstance(labels, list):
        return []
    return [str(label) for label in labels]


def _frame_sample_index(frame: Dict[str, object], fallback: int = 0) -> int:
    # [规则渲染按需落盘][生产迭代01-按告警帧渲染]
    # 修改人: Shiver; 修改时间: 2026-06-24;
    # 修改逻辑: sample_index=0 是合法首帧，不能用 “or fallback” 判断，否则部分边界场景会错取帧。
    value = frame.get("sample_index", fallback) if isinstance(frame, dict) else fallback
    if value is None or value == "":
        value = fallback
    try:
        return int(value)
    except Exception:
        return int(fallback)


def _select_alarm_representative_frame(frames: List[Dict[str, object]], priority_labels: List[str]) -> Dict[str, object]:
    candidates: List[Tuple[int, int, int, Dict[str, object], str]] = []
    priorities = [str(label) for label in priority_labels if str(label).strip()]
    for index, frame in enumerate(frames):
        if not isinstance(frame, dict):
            continue
        labels = set(_frame_labels(frame))
        sample_index = _frame_sample_index(frame, index)
        for rank, label in enumerate(priorities):
            if label in labels:
                candidates.append((rank, sample_index, index, frame, label))
                break
    if not candidates:
        for index, frame in enumerate(frames):
            if not isinstance(frame, dict):
                continue
            labels = set(_frame_labels(frame))
            if NG_LABEL in labels:
                sample_index = _frame_sample_index(frame, index)
                candidates.append((len(priorities), sample_index, index, frame, NG_LABEL))
    if candidates:
        rank, sample_index, _index, frame, label = sorted(candidates, key=lambda item: (item[0], item[1], item[2]))[0]
        return {
            "frame": frame,
            "frame_index": sample_index,
            "sample_index": sample_index,
            "matched_label": label,
            "priority_rank": rank,
            "image_path": str(frame.get("image_path") or ""),
            "rendered_rule_image_path": str(frame.get("rendered_rule_image_path") or ""),
        }
    if frames:
        frame = frames[0]
        sample_index = _frame_sample_index(frame, 0) if isinstance(frame, dict) else 0
        return {
            "frame": frame if isinstance(frame, dict) else {},
            "frame_index": sample_index,
            "sample_index": sample_index,
            "matched_label": "",
            "priority_rank": -1,
            "image_path": str(frame.get("image_path") or "") if isinstance(frame, dict) else "",
            "rendered_rule_image_path": str(frame.get("rendered_rule_image_path") or "") if isinstance(frame, dict) else "",
        }
    return {"frame": {}, "frame_index": 0, "sample_index": 0, "matched_label": "", "priority_rank": -1}


def _alarm_gif_frames(frames: List[Dict[str, object]], center_sample_index: int, before: int, after: int) -> List[Dict[str, object]]:
    ordered = [frame for frame in frames if isinstance(frame, dict)]
    ordered.sort(key=lambda frame: _frame_sample_index(frame, 0))
    start = int(center_sample_index) - max(0, int(before))
    end = int(center_sample_index) + max(0, int(after))
    return [frame for frame in ordered if start <= _frame_sample_index(frame, 0) <= end]


def _empty_ng_alarm_gif_frame_plan(before: int, after: int) -> Dict[str, object]:
    return {
        "frames": [],
        "center_sample_indexes": [],
        "segments": [],
        "before_frames": max(0, int(before)),
        "after_frames": max(0, int(after)),
    }


def _ng_alarm_gif_frame_plan(frames: List[Dict[str, object]], center_sample_index: int, before: int, after: int) -> Dict[str, object]:
    before_count = max(0, int(before))
    after_count = max(0, int(after))
    center = int(center_sample_index)
    start = center - before_count
    end = center + after_count
    ordered = [frame for frame in frames if isinstance(frame, dict)]
    ordered.sort(key=lambda frame: _frame_sample_index(frame, 0))
    gif_frames = [frame for frame in ordered if start <= _frame_sample_index(frame, 0) <= end]
    segment_sample_indexes = [_frame_sample_index(frame, 0) for frame in gif_frames]
    segments = [
        {
            "center_sample_index": center,
            "start_sample_index": start,
            "end_sample_index": end,
            "sample_indexes": segment_sample_indexes,
            "frame_count": len(gif_frames),
        }
    ]

    return {
        "frames": gif_frames,
        "center_sample_indexes": [center],
        "segments": segments,
        "before_frames": before_count,
        "after_frames": after_count,
    }


def _protocol_gif_frame_selection(gif_plan: Dict[str, object], gif_frame_count: int) -> Dict[str, object]:
    return {
        "mode": "representative_priority_window",
        "ng_label": NG_LABEL,
        "before_frames": int(gif_plan.get("before_frames") or 0),
        "after_frames": int(gif_plan.get("after_frames") or 0),
        "center_sample_indexes": list(gif_plan.get("center_sample_indexes") or []),
        "segments": list(gif_plan.get("segments") or []),
        "total_gif_frame_count": int(gif_frame_count),
        "deduplicated": False,
    }


def _log_gif_frame_selection(logger: RunLogger, gif_plan: Dict[str, object], gif_frame_count: int) -> None:
    logger.write(
        "告警 GIF 帧选择："
        "mode=representative_priority_window，"
        f"center={list(gif_plan.get('center_sample_indexes') or [])}，"
        f"segments={len(list(gif_plan.get('segments') or []))}，"
        f"frames={gif_frame_count}"
    )

def _save_alarm_gif(
    *,
    frames: List[Dict[str, object]],
    gif_path: object,
    image_key: str,
    logger: RunLogger,
    label: str,
) -> bool:
    try:
        from PIL import Image
    except Exception as exc:
        logger.write(f"Pillow 不可用，跳过告警 {label} GIF 生成：{exc}")
        return False

    images = []
    target_size = None
    for frame in frames:
        path_text = str(frame.get(image_key) or "")
        path = Path(path_text)
        if not path.exists() or not path.is_file():
            logger.write(f"跳过 {label} GIF 帧：{path} 不存在")
            continue
        try:
            img = Image.open(str(path)).convert("RGB")
            if target_size is None:
                target_size = img.size
            elif img.size != target_size:
                img = img.resize(target_size)
            images.append(img)
        except Exception as exc:
            logger.write(f"跳过 {label} GIF 帧：{path}，{exc}")
    if not images:
        logger.write(f"没有可用帧，跳过告警 {label} GIF 生成。")
        return False
    out_path = Path(str(gif_path))
    out_path.parent.mkdir(parents=True, exist_ok=True)
    try:
        images[0].save(str(out_path), save_all=True, append_images=images[1:], duration=120, loop=0)
    finally:
        for img in images:
            try:
                img.close()
            except Exception:
                pass
    sample_indexes = [_frame_sample_index(frame, 0) for frame in frames]
    logger.write(f"告警 {label} GIF 已写入：{out_path}，帧数={len(images)}，sample_indexes={sample_indexes}")
    return True


def _save_testoutput_original_images(
    *,
    frames: List[Dict[str, object]],
    cache_dir: Path,
    enabled: bool,
    max_count: int,
    label_prefix: str,
    logger: RunLogger,
) -> Dict[str, object]:
    if not enabled or max_count <= 0:
        return {"dir": "", "images": []}
    prefix = str(label_prefix or "testoutput-")
    out_dir = Path(cache_dir) / "testoutput_originals"
    saved: List[str] = []
    for frame in frames:
        if len(saved) >= max_count:
            break
        if not isinstance(frame, dict):
            continue
        labels = _frame_labels(frame)
        sample_index = _frame_sample_index(frame, 0)
        for label in labels:
            if len(saved) >= max_count:
                break
            if not label.startswith(prefix):
                continue
            suffix = label[len(prefix):] or "output"
            filename = f"{prefix}{_safe_file_part(suffix)}-{sample_index}.jpg"
            dst = out_dir / filename
            if _save_jpg_if_exists(frame.get("image_path"), dst):
                saved.append(str(dst))
                logger.write(f"testoutput 原图已保存：{dst}")
    if len(saved) >= max_count:
        logger.write(f"testoutput 原图保存达到上限：{max_count}")
    return {"dir": str(out_dir) if saved else "", "images": saved}


def _array_to_pil_image(image):
    from PIL import Image
    try:
        import cv2
    except Exception:
        cv2 = None
    if image is None:
        return None
    arr = image
    try:
        if len(arr.shape) == 2:
            return Image.fromarray(arr).convert("RGB")
        if len(arr.shape) >= 3 and arr.shape[2] >= 3 and cv2 is not None:
            arr = cv2.cvtColor(arr, cv2.COLOR_BGR2RGB)
        return Image.fromarray(arr).convert("RGB")
    except Exception:
        return None


def _write_image_array(image, dst: object) -> bool:
    if image is None:
        return False
    dst_path = Path(str(dst))
    dst_path.parent.mkdir(parents=True, exist_ok=True)
    try:
        import cv2
        ok = cv2.imencode(dst_path.suffix or ".jpg", image)[1]
        if ok is not None:
            ok.tofile(str(dst_path))
            return True
    except Exception:
        pass
    pil_img = _array_to_pil_image(image)
    if pil_img is None:
        return False
    pil_img.save(str(dst_path))
    return True


def _save_alarm_gif_from_arrays(
    *,
    frames: List[Dict[str, object]],
    images_by_sample_index: Dict[int, object],
    gif_path: object,
    logger: RunLogger,
    label: str,
) -> bool:
    try:
        from PIL import Image
    except Exception as exc:
        logger.write(f"Pillow 不可用，跳过告警 {label} GIF 生成：{exc}")
        return False
    images: List[object] = []
    target_size = None
    for frame in frames:
        sample_index = _frame_sample_index(frame, 0)
        pil_img = _array_to_pil_image(images_by_sample_index.get(sample_index))
        if pil_img is None:
            logger.write(f"跳过 {label} GIF 帧：sample_index={sample_index} 无可用内存图像")
            continue
        if target_size is None:
            target_size = pil_img.size
        elif pil_img.size != target_size:
            pil_img = pil_img.resize(target_size)
        images.append(pil_img)
    if not images:
        logger.write(f"没有可用帧，跳过告警 {label} GIF 生成。")
        return False
    out_path = Path(str(gif_path))
    out_path.parent.mkdir(parents=True, exist_ok=True)
    try:
        images[0].save(str(out_path), save_all=True, append_images=images[1:], duration=120, loop=0)
    finally:
        for img in images:
            try:
                img.close()
            except Exception:
                pass
    sample_indexes = [_frame_sample_index(frame, 0) for frame in frames]
    logger.write(f"告警 {label} GIF 已写入：{out_path}，帧数={len(images)}，sample_indexes={sample_indexes}")
    return True


def _save_testoutput_original_images_memory(
    *,
    frames: List[Dict[str, object]],
    images_by_sample_index: Dict[int, object],
    output_dir: Path,
    enabled: bool,
    max_count: int,
    label_prefix: str,
    logger: RunLogger,
) -> Dict[str, object]:
    if not enabled or max_count <= 0:
        return {"dir": "", "images": []}
    prefix = str(label_prefix or "testoutput-")
    out_dir = Path(output_dir) / "testoutput_originals"
    saved: List[str] = []
    for frame in frames:
        if len(saved) >= max_count:
            break
        if not isinstance(frame, dict):
            continue
        labels = _frame_labels(frame)
        sample_index = _frame_sample_index(frame, 0)
        image = images_by_sample_index.get(sample_index)
        for label in labels:
            if len(saved) >= max_count:
                break
            if not label.startswith(prefix):
                continue
            suffix = label[len(prefix):] or "output"
            dst = out_dir / f"{prefix}{_safe_file_part(suffix)}-{sample_index}.jpg"
            if _write_image_array(image, dst):
                saved.append(str(dst))
                logger.write(f"testoutput 原图已保存：{dst}")
    if len(saved) >= max_count:
        logger.write(f"testoutput 原图保存达到上限：{max_count}")
    return {"dir": str(out_dir) if saved else "", "images": saved}


def _single_video_input_info(input_info: Dict[str, object], video_item: Dict[str, object], video_index: int) -> Dict[str, object]:
    video_input = dict(input_info)
    video_input["video_index"] = int(video_index)
    video_input["raw_video_path"] = str(video_item.get("raw_video_path") or video_item.get("video_path") or "")
    video_input["video_path"] = str(video_item.get("video_path") or video_item.get("raw_video_path") or "")
    video_input["local_video_path"] = str(video_item.get("local_video_path") or "")
    video_input["wafer_info"] = dict(video_item.get("wafer_info") or {})
    original_video_paths = input_info.get("video_paths")
    if isinstance(original_video_paths, list) and 0 <= int(video_index) < len(original_video_paths):
        video_input["video_paths"] = [original_video_paths[int(video_index)]]
    else:
        video_input["video_paths"] = []
    video_input["video_items"] = [video_item]
    return video_input


def _protocol_artifact_summary(
    *,
    video_index: int,
    video_item: Dict[str, object],
    infer_db: Path,
    rule_db: Path,
    protocol_result: Dict[str, object],
    protocol_artifacts: Dict[str, object],
) -> Dict[str, object]:
    return {
        "video_index": int(video_index),
        "raw_video_path": str(video_item.get("raw_video_path") or video_item.get("video_path") or ""),
        "local_video_path": str(video_item.get("local_video_path") or ""),
        "infer_db": str(infer_db),
        "rule_db": str(rule_db),
        "status": str(protocol_result.get("status") or ""),
        "sample_index": int(protocol_artifacts.get("sample_index") or 0),
        "matched_label": str(protocol_artifacts.get("matched_label") or ""),
        "priority_rank": int(protocol_artifacts.get("priority_rank") or 0),
        "image_path": str(protocol_artifacts.get("image_path") or ""),
        "rendered_rule_image_path": str(protocol_artifacts.get("rendered_rule_image_path") or ""),
        "select_img_path": str(protocol_artifacts.get("select_img_path") or ""),
        "original_img_path": str(protocol_artifacts.get("original_img_path") or ""),
        "roi_img_path": str(protocol_artifacts.get("roi_img_path") or ""),
        "alarm_video_path": str(protocol_artifacts.get("alarm_video_path") or ""),
        "alarm_video_written": bool(protocol_artifacts.get("alarm_video_written")),
        "gif_path": str(protocol_artifacts.get("gif_path") or ""),
        "rendered_gif_path": str(protocol_artifacts.get("rendered_gif_path") or ""),
        "original_gif_path": str(protocol_artifacts.get("original_gif_path") or ""),
        "gif_sample_indexes": list(protocol_artifacts.get("gif_sample_indexes") or []),
        "gif_selection_mode": str(protocol_artifacts.get("gif_selection_mode") or ""),
        "gif_ng_center_sample_indexes": list(protocol_artifacts.get("gif_ng_center_sample_indexes") or []),
        "gif_segments": list(protocol_artifacts.get("gif_segments") or []),
        "gif_frame_count": int(protocol_artifacts.get("gif_frame_count") or 0),
        "video_processing_time_ms": int(protocol_artifacts.get("video_processing_time_ms") or protocol_result.get("video_processing_time_ms") or 0),
        "infer_elapsed_ms": int(protocol_artifacts.get("infer_elapsed_ms") or protocol_result.get("infer_elapsed_ms") or 0),
        "post_infer_elapsed_ms": int(protocol_artifacts.get("post_infer_elapsed_ms") or protocol_result.get("post_infer_elapsed_ms") or 0),
    }


def _select_compatible_protocol_result(protocol_results: List[Dict[str, object]], protocol_artifacts_by_video: List[Dict[str, object]]) -> Tuple[Dict[str, object], Dict[str, object]]:
    artifact_by_index = {
        int(item.get("video_index") or 0): item
        for item in protocol_artifacts_by_video
        if isinstance(item, dict)
    }
    candidates: List[Tuple[int, int, int, Dict[str, object], Dict[str, object]]] = []
    for index, protocol_result in enumerate(protocol_results):
        if not isinstance(protocol_result, dict):
            continue
        artifact = artifact_by_index.get(int(protocol_result.get("video_index", index) or index), {})
        if str(protocol_result.get("status") or "") == "alarm":
            candidates.append(
                (
                    int(artifact.get("priority_rank") if artifact.get("priority_rank") is not None else 9999),
                    int(artifact.get("sample_index") or 0),
                    int(protocol_result.get("video_index", index) or index),
                    protocol_result,
                    artifact,
                )
            )
    if candidates:
        _rank, _sample, _video_index, protocol_result, artifact = sorted(candidates, key=lambda item: (item[0], item[1], item[2]))[0]
        return protocol_result, artifact
    if protocol_results:
        protocol_result = protocol_results[0]
        artifact = artifact_by_index.get(int(protocol_result.get("video_index", 0) or 0), {})
        return protocol_result, artifact
    return {}, {}


def _materialize_protocol_outputs(
    *,
    input_info: Dict[str, object],
    frames: List[Dict[str, object]],
    result_root: Path,
    protocol_result: Dict[str, object],
    log_path: Path,
    json_path: Path,
    logger: RunLogger,
    priority_labels: List[str],
    gif_before_frames: int,
    gif_after_frames: int,
) -> Dict[str, object]:
    status = str(protocol_result.get("status") or "")
    selected_info = _select_alarm_representative_frame(frames, priority_labels)
    selected_frame = selected_info.get("frame") if isinstance(selected_info.get("frame"), dict) else {}
    frame_index = int(selected_info.get("frame_index") or 0)
    selected_sample_index = _frame_sample_index(selected_info, frame_index)

    paths = protocol_output_paths(input_info, result_root, frame_index=frame_index)
    gif_written = False
    rendered_gif_written = False
    original_gif_written = False
    video_written = False
    gif_sample_indexes: List[int] = []
    gif_plan: Dict[str, object] = _empty_ng_alarm_gif_frame_plan(gif_before_frames, gif_after_frames)
    gif_selection_mode = ""
    if status == "alarm":
        relative = paths["relative"]
        protocol_result.update(relative)
        protocol_result["alarm_representative_frame"] = {
            "sample_index": selected_sample_index,
            "matched_label": str(selected_info.get("matched_label") or ""),
            "priority_rank": int(selected_info.get("priority_rank") or 0),
        }
        logger.write(
            "告警代表帧："
            f"sample_index={protocol_result['alarm_representative_frame']['sample_index']}，"
            f"label={protocol_result['alarm_representative_frame']['matched_label']}，"
            f"priority={protocol_result['alarm_representative_frame']['priority_rank']}"
        )

        video_written = _copy_alarm_original_video(
            source_video_path=_alarm_source_video_path(input_info),
            target_video_path=str(paths.get("video_path") or ""),
            logger=logger,
        )
        rendered = selected_frame.get("rendered_rule_image_path") if selected_frame else ""
        original = selected_frame.get("image_path") if selected_frame else ""
        if _copy_if_exists(rendered, paths["select_img_path"]):
            logger.write(f"协议标注图已写入：{paths['select_img_path']}")
        if _copy_if_exists(original, paths["original_img_path"]):
            logger.write(f"协议原图已写入：{paths['original_img_path']}")
        if _copy_if_exists(rendered, paths["roi_img_path"]):
            logger.write(f"协议 ROI 图暂用渲染图写入：{paths['roi_img_path']}")
        gif_plan = _ng_alarm_gif_frame_plan(
            frames=frames,
            center_sample_index=selected_sample_index,
            before=gif_before_frames,
            after=gif_after_frames,
        )
        gif_frames = list(gif_plan.get("frames") or [])
        gif_sample_indexes = [_frame_sample_index(frame, 0) for frame in gif_frames]
        gif_selection_mode = "representative_priority_window"
        protocol_result["alarm_gif_frame_selection"] = _protocol_gif_frame_selection(gif_plan, len(gif_frames))
        _log_gif_frame_selection(logger, gif_plan, len(gif_frames))
        rendered_gif_written = _save_alarm_gif(
            frames=gif_frames,
            gif_path=paths["rendered_gif_path"],
            image_key="rendered_rule_image_path",
            logger=logger,
            label="渲染图",
        )
        original_gif_written = _save_alarm_gif(
            frames=gif_frames,
            gif_path=paths["original_gif_path"],
            image_key="image_path",
            logger=logger,
            label="原图",
        )
        gif_written = original_gif_written
        if original_gif_written:
            protocol_result["gif_save_path"] = relative.get("original_gif_save_path") or relative.get("gif_save_path") or ""
        if rendered_gif_written:
            logger.write(f"协议渲染 GIF 已写入：{paths['rendered_gif_path']}")
        if original_gif_written:
            logger.write(f"协议原图 GIF 已写入：{paths['original_gif_path']}")

    log_dir = Path(result_root) / "logs" / str(paths["date_dir"])
    log_dir.mkdir(parents=True, exist_ok=True)
    protocol_log = log_dir / "log.txt"
    with protocol_log.open("a", encoding="utf-8") as f:
        f.write(json.dumps({
            "time": _now(),
            "task_id": input_info.get("task_id", ""),
            "status": status,
            "eqp_id": input_info.get("eqp_id", ""),
            "video_paths": input_info.get("video_paths", []),
            "protocol_result": protocol_result,
            "result_json": str(json_path),
            "text_log": str(log_path),
        }, ensure_ascii=False) + "\n")
    return {
        "sample_index": selected_sample_index,
        "matched_label": str(selected_info.get("matched_label") or ""),
        "priority_rank": int(selected_info.get("priority_rank") or 0),
        "image_path": str(selected_info.get("image_path") or ""),
        "rendered_rule_image_path": str(selected_info.get("rendered_rule_image_path") or ""),
        "select_img_path": str(paths.get("select_img_path") or ""),
        "original_img_path": str(paths.get("original_img_path") or ""),
        "roi_img_path": str(paths.get("roi_img_path") or ""),
        "alarm_video_path": str(paths.get("video_path") or "") if video_written else "",
        "alarm_video_written": bool(video_written),
        "gif_path": str(paths.get("gif_path") or "") if gif_written else "",
        "rendered_gif_path": str(paths.get("rendered_gif_path") or "") if rendered_gif_written else "",
        "original_gif_path": str(paths.get("original_gif_path") or "") if original_gif_written else "",
        "gif_sample_indexes": gif_sample_indexes,
        "gif_selection_mode": gif_selection_mode,
        "gif_ng_center_sample_indexes": list(gif_plan.get("center_sample_indexes") or []),
        "gif_segments": list(gif_plan.get("segments") or []),
        "gif_frame_count": len(gif_sample_indexes),
    }


def _materialize_protocol_outputs_memory(
    *,
    input_info: Dict[str, object],
    frames: List[Dict[str, object]],
    original_images_by_sample_index: Dict[int, object],
    rendered_images_by_sample_index: Dict[int, object],
    result_root: Path,
    protocol_result: Dict[str, object],
    log_path: Path,
    json_path: Path,
    logger: RunLogger,
    priority_labels: List[str],
    gif_before_frames: int,
    gif_after_frames: int,
) -> Dict[str, object]:
    status = str(protocol_result.get("status") or "")
    protocol_trace_stages: List[Dict[str, object]] = []

    def _begin_protocol_stage() -> Tuple[float, str]:
        return time.monotonic(), _now()

    def _finish_protocol_stage(
        *,
        started: Tuple[float, str],
        stage_order: int,
        stage_key: str,
        stage_name: str,
        status_text: str = "success",
        workload: Optional[Dict[str, object]] = None,
        detail: Optional[Dict[str, object]] = None,
        error_message: str = "",
    ) -> None:
        protocol_trace_stages.append(
            {
                "stage_order": int(stage_order),
                "stage_key": str(stage_key),
                "stage_name": str(stage_name),
                "status": str(status_text or "success"),
                "started_at": started[1],
                "ended_at": _now(),
                "duration_ms": _elapsed_ms(started[0]),
                "workload": workload or {},
                "detail": detail or {},
                "error_message": str(error_message or ""),
            }
        )

    stage_marker = _begin_protocol_stage()
    selected_info = _select_alarm_representative_frame(frames, priority_labels)
    frame_index = int(selected_info.get("frame_index") or 0)
    selected_sample_index = _frame_sample_index(selected_info, frame_index)
    paths = protocol_output_paths(input_info, result_root, frame_index=frame_index)
    _finish_protocol_stage(
        started=stage_marker,
        stage_order=1000,
        stage_key="protocol_select_frame",
        stage_name="告警代表帧选择",
        workload={"frame_count": len(frames)},
        detail={
            "selected_sample_index": selected_sample_index,
            "matched_label": str(selected_info.get("matched_label") or ""),
            "priority_rank": int(selected_info.get("priority_rank") or 0),
            "priority_labels": list(priority_labels or []),
        },
    )
    gif_written = False
    rendered_gif_written = False
    original_gif_written = False
    video_written = False
    gif_sample_indexes: List[int] = []
    gif_plan: Dict[str, object] = _empty_ng_alarm_gif_frame_plan(gif_before_frames, gif_after_frames)
    gif_selection_mode = ""
    if status == "alarm":
        relative = paths["relative"]
        protocol_result.update(relative)
        protocol_result["alarm_representative_frame"] = {
            "sample_index": selected_sample_index,
            "matched_label": str(selected_info.get("matched_label") or ""),
            "priority_rank": int(selected_info.get("priority_rank") or 0),
        }
        logger.write(
            "告警代表帧："
            f"sample_index={protocol_result['alarm_representative_frame']['sample_index']}，"
            f"label={protocol_result['alarm_representative_frame']['matched_label']}，"
            f"priority={protocol_result['alarm_representative_frame']['priority_rank']}"
        )
        stage_marker = _begin_protocol_stage()
        video_written = _copy_alarm_original_video(
            source_video_path=_alarm_source_video_path(input_info),
            target_video_path=str(paths.get("video_path") or ""),
            logger=logger,
        )
        _finish_protocol_stage(
            started=stage_marker,
            stage_order=1040,
            stage_key="protocol_copy_alarm_video",
            stage_name="告警原视频复制",
            status_text="success" if video_written else "failed",
            workload={"copy_bytes": _file_size_bytes(paths.get("video_path")) if video_written else 0},
            detail={
                "source_video_path": _alarm_source_video_path(input_info),
                "target_video_path": str(paths.get("video_path") or ""),
                "source_size_bytes": _file_size_bytes(_alarm_source_video_path(input_info)),
                "target_size_bytes": _file_size_bytes(paths.get("video_path")),
                "copy_success": bool(video_written),
            },
        )
        sample_index = selected_sample_index
        original_img = original_images_by_sample_index.get(sample_index)
        rendered_img = rendered_images_by_sample_index.get(sample_index)
        if rendered_img is None:
            rendered_img = original_img
        stage_marker = _begin_protocol_stage()
        select_img_written = _write_image_array(rendered_img, paths["select_img_path"])
        original_img_written = _write_image_array(original_img, paths["original_img_path"])
        roi_img_written = _write_image_array(rendered_img, paths["roi_img_path"])
        if select_img_written:
            logger.write(f"协议标注图已写入：{paths['select_img_path']}")
        if original_img_written:
            logger.write(f"协议原图已写入：{paths['original_img_path']}")
        if roi_img_written:
            logger.write(f"协议 ROI 图暂用渲染图写入：{paths['roi_img_path']}")
        _finish_protocol_stage(
            started=stage_marker,
            stage_order=1010,
            stage_key="protocol_save_images",
            stage_name="协议图片落盘",
            status_text="success" if any([select_img_written, original_img_written, roi_img_written]) else "failed",
            workload={"image_write_count": sum(1 for item in [select_img_written, original_img_written, roi_img_written] if item)},
            detail={
                "select_img_path": str(paths.get("select_img_path") or ""),
                "original_img_path": str(paths.get("original_img_path") or ""),
                "roi_img_path": str(paths.get("roi_img_path") or ""),
                "select_img_written": bool(select_img_written),
                "original_img_written": bool(original_img_written),
                "roi_img_written": bool(roi_img_written),
                "select_img_size_bytes": _file_size_bytes(paths.get("select_img_path")),
                "original_img_size_bytes": _file_size_bytes(paths.get("original_img_path")),
                "roi_img_size_bytes": _file_size_bytes(paths.get("roi_img_path")),
            },
        )
        gif_plan = _ng_alarm_gif_frame_plan(
            frames=frames,
            center_sample_index=selected_sample_index,
            before=gif_before_frames,
            after=gif_after_frames,
        )
        gif_frames = list(gif_plan.get("frames") or [])
        gif_sample_indexes = [_frame_sample_index(frame, 0) for frame in gif_frames]
        gif_selection_mode = "representative_priority_window"
        protocol_result["alarm_gif_frame_selection"] = _protocol_gif_frame_selection(gif_plan, len(gif_frames))
        _log_gif_frame_selection(logger, gif_plan, len(gif_frames))
        stage_marker = _begin_protocol_stage()
        rendered_gif_written = _save_alarm_gif_from_arrays(
            frames=gif_frames,
            images_by_sample_index=rendered_images_by_sample_index,
            gif_path=paths["rendered_gif_path"],
            logger=logger,
            label="渲染图",
        )
        _finish_protocol_stage(
            started=stage_marker,
            stage_order=1030,
            stage_key="protocol_save_rendered_gif",
            stage_name="渲染GIF生成",
            status_text="success" if rendered_gif_written else "failed",
            workload={"gif_frame_count": len(gif_frames), "gif_written": bool(rendered_gif_written)},
            detail={
                "rendered_gif_path": str(paths.get("rendered_gif_path") or ""),
                "rendered_gif_size_bytes": _file_size_bytes(paths.get("rendered_gif_path")),
                "gif_sample_indexes": gif_sample_indexes,
            },
        )
        stage_marker = _begin_protocol_stage()
        original_gif_written = _save_alarm_gif_from_arrays(
            frames=gif_frames,
            images_by_sample_index=original_images_by_sample_index,
            gif_path=paths["original_gif_path"],
            logger=logger,
            label="原图",
        )
        _finish_protocol_stage(
            started=stage_marker,
            stage_order=1020,
            stage_key="protocol_save_original_gif",
            stage_name="原图GIF生成",
            status_text="success" if original_gif_written else "failed",
            workload={"gif_frame_count": len(gif_frames), "gif_written": bool(original_gif_written)},
            detail={
                "original_gif_path": str(paths.get("original_gif_path") or ""),
                "original_gif_size_bytes": _file_size_bytes(paths.get("original_gif_path")),
                "gif_selection_mode": gif_selection_mode,
                "center_sample_indexes": list(gif_plan.get("center_sample_indexes") or []),
                "gif_sample_indexes": gif_sample_indexes,
            },
        )
        gif_written = original_gif_written
        if original_gif_written:
            protocol_result["gif_save_path"] = relative.get("original_gif_save_path") or relative.get("gif_save_path") or ""
        if rendered_gif_written:
            logger.write(f"协议渲染 GIF 已写入：{paths['rendered_gif_path']}")
        if original_gif_written:
            logger.write(f"协议原图 GIF 已写入：{paths['original_gif_path']}")
    else:
        for order, key, name in (
            (1010, "protocol_save_images", "协议图片落盘"),
            (1020, "protocol_save_original_gif", "原图GIF生成"),
            (1030, "protocol_save_rendered_gif", "渲染GIF生成"),
            (1040, "protocol_copy_alarm_video", "告警原视频复制"),
        ):
            marker = _begin_protocol_stage()
            _finish_protocol_stage(started=marker, stage_order=order, stage_key=key, stage_name=name, status_text="skipped")

    stage_marker = _begin_protocol_stage()
    log_dir = Path(result_root) / "logs" / str(paths["date_dir"])
    log_dir.mkdir(parents=True, exist_ok=True)
    protocol_log = log_dir / "log.txt"
    with protocol_log.open("a", encoding="utf-8") as f:
        f.write(json.dumps({
            "time": _now(),
            "task_id": input_info.get("task_id", ""),
            "status": status,
            "eqp_id": input_info.get("eqp_id", ""),
            "video_paths": input_info.get("video_paths", []),
            "protocol_result": protocol_result,
            "result_json": str(json_path),
            "text_log": str(log_path),
        }, ensure_ascii=False) + "\n")
    _finish_protocol_stage(
        started=stage_marker,
        stage_order=1050,
        stage_key="protocol_write_log",
        stage_name="协议log写入",
        workload={"line_count": 1},
        detail={
            "protocol_log_path": str(protocol_log),
            "result_json_path": str(json_path),
            "text_log_path": str(log_path),
        },
    )
    return {
        "sample_index": selected_sample_index,
        "matched_label": str(selected_info.get("matched_label") or ""),
        "priority_rank": int(selected_info.get("priority_rank") or 0),
        "image_path": f"memory://sample/{selected_sample_index}/original",
        "rendered_rule_image_path": f"memory://sample/{selected_sample_index}/rendered",
        "select_img_path": str(paths.get("select_img_path") or ""),
        "original_img_path": str(paths.get("original_img_path") or ""),
        "roi_img_path": str(paths.get("roi_img_path") or ""),
        "alarm_video_path": str(paths.get("video_path") or "") if video_written else "",
        "alarm_video_written": bool(video_written),
        "gif_path": str(paths.get("gif_path") or "") if gif_written else "",
        "rendered_gif_path": str(paths.get("rendered_gif_path") or "") if rendered_gif_written else "",
        "original_gif_path": str(paths.get("original_gif_path") or "") if original_gif_written else "",
        "gif_sample_indexes": gif_sample_indexes,
        "gif_selection_mode": gif_selection_mode,
        "gif_ng_center_sample_indexes": list(gif_plan.get("center_sample_indexes") or []),
        "gif_segments": list(gif_plan.get("segments") or []),
        "gif_frame_count": len(gif_sample_indexes),
        "rendered_frame_count": len(rendered_images_by_sample_index),
        "protocol_trace_stages": protocol_trace_stages,
    }


class InferCacheService:
    """No-PyQt service facade that reuses the existing core pipeline."""

    def __init__(self, config: ServiceConfig) -> None:
        self.config = config
        self.config.validate_model_paths()
        self.config.output_root.mkdir(parents=True, exist_ok=True)
        self.config.log_dir.mkdir(parents=True, exist_ok=True)
        self.config.rolling_log_dir.mkdir(parents=True, exist_ok=True)
        # [专项日志][生产迭代01-中文专项日志]
        # 修改人: Shiver; 修改时间: 2026-06-25;
        # 修改逻辑: 专项日志独立于原有RunLogger，默认输出到 Docker 和 /app/log/YYYY-MM-DD/<实例>_专项日志.log。
        self._special_log = SpecialLogger(
            log_dir=self.config.rolling_log_dir,
            instance_id=self.config.instance_id,
            enabled=self.config.special_log_enabled,
        )
        self._special_stats_date = _today()
        self._special_first_request_time_text = ""
        self._special_first_request_epoch = 0.0
        self._special_log.write(
            "服务启动",
            (
                f"服务开始启动，实例={self.config.instance_id}，监听地址={self.config.host}:{self.config.port}，"
                f"模型数量={len(self.config.model_paths)}，配置GPU={','.join(str(item) for item in self.config.device_ids)}"
            ),
        )
        self._job_slots = threading.Semaphore(self.config.job_queue_size)
        self._job_executor = ThreadPoolExecutor(max_workers=self.config.job_workers, thread_name_prefix="infer-cache-job")
        self._task_callback_batcher = TaskCallbackBatcher(
            interval_sec=self.config.task_callback_interval_sec,
            batch_size=self.config.task_callback_batch_size,
            timeout_sec=self.config.callback_timeout_sec,
            log=lambda message: self._special_log.write("回调情况", message),
        )
        # [视频处理耗时复盘JSONL][第一版]
        # 修改人: Shiver; 修改时间: 2026-06-24;
        # 修改逻辑: 每个容器实例写自己的JSONL trace文件，后续离线汇总为服务器级总表。
        self._video_trace = VideoTraceLogger(
            root=self.config.video_trace_root,
            instance_id=self.config.instance_id,
            enabled=self.config.video_trace_enabled,
            log=print,
        )
        self._stats_lock = threading.Lock()
        self._stats_date = _today()
        self._stats: Dict[str, int] = {
            "accepted": 0,
            "running": 0,
            "success": 0,
            "failed": 0,
            # [专项日志][生产迭代03-请求/视频剩余口径]
            # 修改人: Shiver; 修改时间: 2026-06-27;
            # 修改逻辑: 请求是一个客户HTTP任务，视频是该请求内 video_items 数量；
            # 分开记录，专项汇总可同时输出剩余请求数和剩余视频数。
            "accepted_videos": 0,
            "completed_videos": 0,
        }
        self._timing_stats = _TimingStats()
        self._service_log_path = _instance_log_path(self.config.rolling_log_dir, self.config.instance_id, "service_progress.log")
        self._progress_log_stop = threading.Event()
        self._progress_log_lock = threading.Lock()
        if self.config.progress_log_enabled:
            self._progress_log_thread = threading.Thread(
                target=self._progress_log_loop,
                name="infer-cache-progress-log",
                daemon=True,
            )
            self._progress_log_thread.start()
        else:
            self._progress_log_thread = None
        self._special_health_stop = threading.Event()
        if self.config.special_log_enabled:
            self._special_health_thread = threading.Thread(
                target=self._special_health_loop,
                name="infer-cache-special-health-log",
                daemon=True,
            )
            self._special_health_thread.start()
        else:
            self._special_health_thread = None
        self.model_outputs = []
        self.initialized_at = ""
        self.inference_context = None
        self.model_orchestration = _orchestration_summary()
        _cleanup_old_log_dirs(self.config.rolling_log_dir, self.config.log_retention_days)
        _cleanup_old_log_files(self.config.rolling_log_dir, self.config.log_retention_days)
        self._inspect_models()

    def _inspect_models(self) -> None:
        self._special_log.write(
            "服务启动",
            f"模型预加载开始，实例={self.config.instance_id}，模型数量={len(self.config.model_paths)}，配置GPU={','.join(str(item) for item in self.config.device_ids)}",
        )
        self.inference_context = prepare_inference_context(
            self.config.model_paths,
            device_ids=self.config.device_ids,
            allow_cpu=self.config.allow_cpu,
            password=self.config.model_password,
            runtime_workers=self.config.preload_infer_workers,
            log=print,
        )
        self.model_outputs = [_output_spec_to_dict(spec) for spec in self.inference_context.output_specs]
        self._special_log.write(
            "服务启动",
            (
                f"模型预加载完成，实例={self.config.instance_id}，运行时数量={self.inference_context.runtime_count if self.inference_context else 0}，"
                f"输出节点数量={len(self.model_outputs)}"
            ),
        )
        # [1.内存模型预加载整段视频全部帧][生产迭代01-RGB]
        # 修改人: Shiver; 修改时间: 2026-06-22;
        # 修改逻辑: 启动时输出一次颜色边界，现场可确认新代码已加载。
        print(f"{MEMORY_FIX_LOG_PREFIX}[CONFIG] visionflow_numpy_color=RGB opencv_internal_color=BGR")
        print(
            f"{VIDEO_TRACE_LOG_PREFIX}[CONFIG] "
            f"enabled={self.config.video_trace_enabled} root={self.config.video_trace_root}"
        )
        if bool(self.model_orchestration.get("enabled")) and bool(self.model_orchestration.get("require_two_models")) and len(self.config.model_paths) != 2:
            raise RuntimeError("启用模型编排时，INFER_CACHE_MODEL_PATHS 必须按顺序配置 2 个模型：1#单图模型;2#多图模型。")
        self.initialized_at = _now()
        init_log = self.config.rolling_log_dir / f"{_instance_log_prefix(self.config.instance_id)}_model_outputs.json"
        init_log.write_text(
            json.dumps(
                {
                    "initialized_at": self.initialized_at,
                    "models": [str(path) for path in self.config.model_paths],
                    "outputs": self.model_outputs,
                    "model_orchestration": self.model_orchestration,
                    "preloaded_runtime_count": self.inference_context.runtime_count if self.inference_context else 0,
                },
                ensure_ascii=False,
                indent=2,
            ),
            encoding="utf-8",
        )

    def _reset_stats_if_needed(self) -> None:
        today = _today()
        if self._stats_date == today:
            return
        self._stats_date = today
        running = int(self._stats.get("running", 0))
        self._stats = {
            "accepted": 0,
            "running": running,
            "success": 0,
            "failed": 0,
            "accepted_videos": 0,
            "completed_videos": 0,
        }
        self._special_reset_if_needed_locked()

    def _bump_stats(self, key: str, delta: int = 1) -> None:
        with self._stats_lock:
            self._reset_stats_if_needed()
            self._stats[key] = max(0, int(self._stats.get(key, 0)) + int(delta))

    def _stats_snapshot(self) -> Dict[str, int]:
        with self._stats_lock:
            self._reset_stats_if_needed()
            accepted_today = int(self._stats.get("accepted", 0))
            running = int(self._stats.get("running", 0))
            success_today = int(self._stats.get("success", 0))
            failed_today = int(self._stats.get("failed", 0))
            accepted_videos_today = int(self._stats.get("accepted_videos", 0))
            completed_videos_today = int(self._stats.get("completed_videos", 0))
        completed_today = success_today + failed_today
        pending_requests = max(0, accepted_today - completed_today)
        queued_requests = max(0, pending_requests - running)
        pending_videos = max(0, accepted_videos_today - completed_videos_today)
        return {
            "queued": queued_requests,
            "running": running,
            "pending": pending_requests,
            "queued_requests_today": queued_requests,
            "running_requests_today": running,
            "pending_requests_today": pending_requests,
            "success_today": success_today,
            "failed_today": failed_today,
            "completed_today": completed_today,
            "accepted_today": accepted_today,
            "accepted_videos_today": accepted_videos_today,
            "completed_videos_today": completed_videos_today,
            "pending_videos_today": pending_videos,
        }

    def _input_video_count(self, input_info: Dict[str, object]) -> int:
        video_items = [item for item in (input_info.get("video_items") or []) if isinstance(item, dict)]
        return len(video_items)

    def _mark_video_completed_for_stats(self, input_info: Dict[str, object], count: int = 1) -> int:
        # [专项日志][生产迭代03-请求/视频剩余口径]
        # 修改人: Shiver; 修改时间: 2026-06-27;
        # 修改逻辑: 单个请求内每完成一个视频即更新视频完成数，汇总日志可反映大请求内部进度。
        add_count = max(0, int(count or 0))
        if add_count <= 0:
            return 0
        with self._stats_lock:
            self._reset_stats_if_needed()
            total_videos = self._input_video_count(input_info)
            already_done = max(0, int(input_info.get("_stats_completed_videos", 0) or 0))
            if total_videos > 0:
                add_count = min(add_count, max(0, total_videos - already_done))
            if add_count <= 0:
                return 0
            self._stats["completed_videos"] = max(0, int(self._stats.get("completed_videos", 0)) + add_count)
            input_info["_stats_completed_videos"] = already_done + add_count
            return add_count

    def _finalize_video_stats_for_request(self, input_info: Dict[str, object]) -> int:
        # [专项日志][生产迭代03-请求/视频剩余口径]
        # 修改人: Shiver; 修改时间: 2026-06-27;
        # 修改逻辑: 请求异常结束时，将该请求尚未逐个完成的视频也标记为终态；
        # 否则一个失败请求会让“剩余视频数”长期虚高。
        total_videos = self._input_video_count(input_info)
        already_done = max(0, int(input_info.get("_stats_completed_videos", 0) or 0))
        remaining = max(0, total_videos - already_done)
        if remaining:
            return self._mark_video_completed_for_stats(input_info, remaining)
        return 0

    def _format_progress_bar(self, done: int, total: int) -> str:
        width = max(5, int(self.config.progress_log_bar_width or 20))
        if total <= 0:
            return "[" + "-" * width + "] 0.0%"
        ratio = min(1.0, max(0.0, float(done) / float(total)))
        filled = int(round(ratio * width))
        return "[" + "#" * filled + "-" * (width - filled) + f"] {ratio * 100.0:.1f}%"

    def _write_service_progress_log(self) -> None:
        self._service_log_path = _instance_log_path(self.config.rolling_log_dir, self.config.instance_id, "service_progress.log")
        stats = self._stats_snapshot()
        memory = _container_memory_snapshot()
        memory_percent = memory.get("percent")
        memory_percent_text = f"{float(memory_percent):.1f}%" if memory_percent is not None else "unknown"
        timing = self._timing_stats.snapshot()
        timing_text = _format_progress_timing_fields(timing)
        bar = self._format_progress_bar(int(stats.get("completed_today", 0)), int(stats.get("accepted_today", 0)))
        stamped = (
            f"[{_now()}] [任务进度] {bar} "
            f"pending={stats.get('pending', 0)} "
            f"queued={stats.get('queued', 0)} "
            f"running={stats.get('running', 0)} "
            f"pending_requests_today={stats.get('pending_requests_today', 0)} "
            f"queued_requests_today={stats.get('queued_requests_today', 0)} "
            f"running_requests_today={stats.get('running_requests_today', 0)} "
            f"completed_today={stats.get('completed_today', 0)} "
            f"success_today={stats.get('success_today', 0)} "
            f"failed_today={stats.get('failed_today', 0)} "
            f"accepted_today={stats.get('accepted_today', 0)} "
            f"accepted_videos_today={stats.get('accepted_videos_today', 0)} "
            f"completed_videos_today={stats.get('completed_videos_today', 0)} "
            f"pending_videos_today={stats.get('pending_videos_today', 0)} "
            f"memory_usage={memory.get('usage_text')} "
            f"memory_limit={memory.get('limit_text')} "
            f"memory_percent={memory_percent_text} "
            f"{timing_text}"
        )
        with self._progress_log_lock:
            try:
                self._service_log_path.parent.mkdir(parents=True, exist_ok=True)
                with self._service_log_path.open("a", encoding="utf-8") as f:
                    f.write(stamped + "\n")
            except Exception as exc:
                print(f"[{_now()}] [任务进度] 写入服务进度日志失败：{exc}", file=sys.stderr)
        print(stamped)

    def _progress_log_loop(self) -> None:
        interval = max(0.5, float(self.config.progress_log_interval_sec or 5.0))
        while not self._progress_log_stop.wait(interval):
            self._write_service_progress_log()

    def special_log(self, category: str, message: str) -> None:
        self._special_log.write(category, message)

    def _special_reset_if_needed_locked(self) -> None:
        today = _today()
        if self._special_stats_date == today:
            return
        self._special_stats_date = today
        self._special_first_request_time_text = ""
        self._special_first_request_epoch = 0.0

    def _remember_special_first_request(self) -> None:
        with self._stats_lock:
            self._special_reset_if_needed_locked()
            if not self._special_first_request_time_text:
                self._special_first_request_time_text = _now()
                self._special_first_request_epoch = time.time()

    def _special_health_loop(self) -> None:
        interval = max(30.0, float(self.config.special_log_interval_sec or 300.0))
        while not self._special_health_stop.wait(interval):
            self._write_special_health_log()

    def _write_special_health_log(self) -> None:
        # [专项日志][生产迭代01-健康状态]
        # 修改人: Shiver; 修改时间: 2026-06-25;
        # 修改逻辑: 每5分钟输出容器资源与当前实例GPU状态，字段全部中文，便于现场只grep专项日志。
        stats = self._stats_snapshot()
        resource = _resource_snapshot()
        memory = ((resource.get("memory") or {}).get("container") if isinstance(resource.get("memory"), dict) else {}) or {}
        pids_info = resource.get("pids") if isinstance(resource.get("pids"), dict) else {}
        pids = pids_info.get("container_current") if isinstance(pids_info, dict) else None
        cpu_info = resource.get("cpu") if isinstance(resource.get("cpu"), dict) else {}
        cpu = cpu_info.get("container") if isinstance(cpu_info, dict) and isinstance(cpu_info.get("container"), dict) else {}
        cpu_text = _format_percent_cn(cpu.get("percent_of_one_core")) if cpu.get("available") else "未知"
        gpu_snapshot = resource.get("gpu") if isinstance(resource.get("gpu"), dict) else {"available": False, "error": "健康快照缺少GPU信息", "gpus": []}
        gpu_text = _gpu_status_text_from_snapshot(gpu_snapshot, self.config.device_ids)
        self._special_log.write(
            "健康状态",
            (
                f"当前资源，实例={self.config.instance_id}，内存={memory.get('usage_text')}，"
                f"内存上限={memory.get('limit_text')}，进程线程数={pids if pids is not None else '未知'}，"
                f"Python线程数={threading.active_count()}，CPU占用={cpu_text}，{gpu_text}，"
                f"运行中请求数={stats.get('running_requests_today', 0)}，排队请求数={stats.get('queued_requests_today', 0)}，"
                f"剩余请求数={stats.get('pending_requests_today', 0)}，已接收视频数={stats.get('accepted_videos_today', 0)}，"
                f"已完成视频数={stats.get('completed_videos_today', 0)}，剩余视频数={stats.get('pending_videos_today', 0)}，"
                f"今日完成请求数={stats.get('completed_today', 0)}，今日成功请求数={stats.get('success_today', 0)}，今日失败请求数={stats.get('failed_today', 0)}"
            ),
        )
        # [专项日志][生产迭代03-硬件状态跟踪]
        # 修改人: Shiver; 修改时间: 2026-06-27;
        # 修改逻辑: 健康状态同步写入结构化 video_trace，离线汇总脚本可按时间段输出硬件占用汇总和跟踪CSV。
        self._video_trace.write(
            {
                "record_type": "health_sample",
                "instance_id": self.config.instance_id,
                "stats": dict(stats),
                "resource": resource,
                "detail": {"configured_gpu_ids": list(self.config.device_ids or [])},
            }
        )

    def _request_summary_text(self, input_info: Dict[str, object]) -> str:
        video_items = [item for item in (input_info.get("video_items") or []) if isinstance(item, dict)]
        first_video = video_items[0] if video_items else {}
        first_wafer = first_video.get("wafer_info") if isinstance(first_video.get("wafer_info"), dict) else {}
        eqp_ids = set()
        for item in video_items:
            wafer = item.get("wafer_info") if isinstance(item.get("wafer_info"), dict) else {}
            eqp_ids.add(str(wafer.get("eqp_id") or item.get("eqp_id") or "").strip())
        eqp_ids.discard("")
        return (
            f"收到请求，实例={self.config.instance_id}，请求ID={input_info.get('task_id') or ''}，"
            f"视频数量={len(video_items)}，机型={input_info.get('machine_type') or ''}，"
            f"机台数量={len(eqp_ids)}，首个机台={first_wafer.get('eqp_id') or first_video.get('eqp_id') or ''}，"
            f"首个腔室={first_wafer.get('chamber') or ''}"
        )

    def _write_special_summary_log(self) -> None:
        stats = self._stats_snapshot()
        accepted = _safe_int(stats.get("accepted_today"), 0)
        completed = _safe_int(stats.get("completed_today"), 0)
        pending = _safe_int(stats.get("pending_requests_today"), max(0, accepted - completed))
        accepted_videos = _safe_int(stats.get("accepted_videos_today"), 0)
        completed_videos = _safe_int(stats.get("completed_videos_today"), 0)
        pending_videos = _safe_int(stats.get("pending_videos_today"), max(0, accepted_videos - completed_videos))
        completion_rate = (float(completed) * 100.0 / float(accepted)) if accepted > 0 else 0.0
        video_completion_rate = (float(completed_videos) * 100.0 / float(accepted_videos)) if accepted_videos > 0 else 0.0
        timing = self._timing_stats.snapshot()
        avg_task_ms = _safe_int(timing.get("avg_task_total_ms"), 0)
        avg_video_ms = _safe_int(timing.get("avg_video_total_ms"), 0)
        request_estimate_epoch: Optional[float] = None
        video_estimate_epoch: Optional[float] = None
        with self._stats_lock:
            first_text = self._special_first_request_time_text or "暂无"
            first_epoch = float(self._special_first_request_epoch or 0.0)
        if first_epoch > 0 and completed > 0 and pending > 0:
            elapsed_sec = max(1.0, time.time() - first_epoch)
            sec_per_completed = elapsed_sec / float(completed)
            request_estimate_epoch = time.time() + sec_per_completed * float(pending)
        elif pending <= 0 and accepted > 0:
            request_estimate_epoch = time.time()
        if first_epoch > 0 and completed_videos > 0 and pending_videos > 0:
            elapsed_sec = max(1.0, time.time() - first_epoch)
            sec_per_completed_video = elapsed_sec / float(completed_videos)
            video_estimate_epoch = time.time() + sec_per_completed_video * float(pending_videos)
        elif pending_videos <= 0 and accepted_videos > 0:
            video_estimate_epoch = time.time()
        self._special_log.write(
            "任务情况-汇总情况",
            (
                f"当前汇总，实例={self.config.instance_id}，请求总数={accepted}，已完成请求数={completed}，"
                f"运行中请求数={stats.get('running_requests_today', 0)}，排队请求数={stats.get('queued_requests_today', 0)}，"
                f"剩余请求数={pending}，请求完成比例={completion_rate:.2f}%，"
                f"视频总数={accepted_videos}，已完成视频数={completed_videos}，剩余视频数={pending_videos}，视频完成比例={video_completion_rate:.2f}%，"
                f"平均请求耗时={_format_duration_cn_ms(avg_task_ms)}，平均视频耗时={_format_duration_cn_ms(avg_video_ms)}，"
                f"首个请求时间={first_text}，按请求预计完成时间={_format_future_time_cn(request_estimate_epoch)}，"
                f"按视频预计完成时间={_format_future_time_cn(video_estimate_epoch)}"
            ),
        )

    def _write_special_video_completed(
        self,
        *,
        run_id: str,
        request_id: str,
        video_index: int,
        video_input_info: Dict[str, object],
        metadata: Dict[str, object],
        protocol_result: Dict[str, object],
        video_stage_ms: Dict[str, object],
    ) -> None:
        processing_info = metadata.get("processing_info") if isinstance(metadata.get("processing_info"), dict) else {}
        bounded = metadata.get("bounded_streaming") if isinstance(metadata.get("bounded_streaming"), dict) else {}
        wafer_info = video_input_info.get("wafer_info") if isinstance(video_input_info.get("wafer_info"), dict) else {}
        source_fps = _safe_float(processing_info.get("src_fps"), 0.0)
        source_frame_count = max(0, _safe_int(processing_info.get("end_frame"), 0) - _safe_int(processing_info.get("start_frame"), 0))
        video_duration_ms = (float(source_frame_count) / source_fps * 1000.0) if source_fps > 0 else 0.0
        stage1_frames = _safe_int(bounded.get("stage1_processed_frame_count"), _safe_int(bounded.get("stage1_frame_count"), 0))
        stage2_frames = _safe_int(bounded.get("stage2_processed_frame_count"), 0)
        trace_timings = metadata.get("trace_stage_timings_ms") if isinstance(metadata.get("trace_stage_timings_ms"), dict) else {}
        trace_detail_timings = metadata.get("trace_stage_timing_detail_ms") if isinstance(metadata.get("trace_stage_timing_detail_ms"), dict) else {}
        stage1_detail = trace_detail_timings.get("stage1_stream_infer") if isinstance(trace_detail_timings.get("stage1_stream_infer"), dict) else {}
        stage2_detail = trace_detail_timings.get("stage2_stream_infer") if isinstance(trace_detail_timings.get("stage2_stream_infer"), dict) else {}
        stage1_ms = _safe_int(trace_timings.get("stage1_stream_infer_ms"), 0)
        stage2_ms = _safe_int(trace_timings.get("stage2_stream_infer_ms"), 0)
        stage1_avg_ms = float(stage1_ms) / float(stage1_frames) if stage1_frames > 0 else 0.0
        stage2_avg_ms = float(stage2_ms) / float(stage2_frames) if stage2_frames > 0 else 0.0
        status_text = str(protocol_result.get("status") or "").lower()
        result_text = "告警" if status_text == "alarm" else "正常"
        # [2#稀疏补推][生产迭代01]
        # 修改人: Shiver; 修改时间: 2026-06-25;
        # 修改逻辑: 专项任务完成日志增加中文稀疏补推摘要，现场tail日志即可确认开关和节省量。
        stage1_sparse_text = "1#稀疏补推=未启用"
        if bool(bounded.get("stage1_sparse_enabled")):
            # [1#稀疏补推][生产迭代01]
            # 修改人: Shiver; 修改时间: 2026-06-27;
            # 修改逻辑: 专项任务完成日志增加1#稀疏扫描/seed/补推/节省摘要。
            stage1_sparse_text = (
                f"1#稀疏补推=已启用，稀疏步长={_safe_int(bounded.get('stage1_sparse_stride'), 0)}，"
                f"初始扫描帧数={_safe_int(bounded.get('stage1_sparse_initial_count'), 0)}，"
                f"挂滴seed={_safe_int(bounded.get('stage1_sparse_droplet_seed_count'), 0)}，"
                f"漏滴seed={_safe_int(bounded.get('stage1_sparse_leak_seed_count'), 0)}，"
                f"分布不均seed={_safe_int(bounded.get('stage1_sparse_spread_seed_count'), 0)}，"
                f"补推帧数={_safe_int(bounded.get('stage1_sparse_refine_count'), 0)}，"
                f"最终1#帧数={_safe_int(bounded.get('stage1_sparse_final_count'), stage1_frames)}，"
                f"节省1#帧数={_safe_int(bounded.get('stage1_sparse_saved_count'), 0)}，"
                f"是否回退全量={'是' if bool(bounded.get('stage1_sparse_fallback_full')) else '否'}"
            )
        sparse_text = "2#稀疏补推=未启用"
        if bool(bounded.get("stage2_sparse_enabled")):
            sparse_text = (
                f"2#稀疏补推=已启用，稀疏步长={_safe_int(bounded.get('stage2_sparse_stride'), 0)}，"
                f"索引模式={bounded.get('stage2_sparse_index_mode') or ''}，"
                f"稀疏扫描帧数={_safe_int(bounded.get('stage2_sparse_initial_count'), 0)}，"
                f"触发模式={bounded.get('stage2_sparse_trigger_mode') or ''}，"
                f"原始模型命中帧数={_safe_int(bounded.get('stage2_sparse_model_raw_hit_count'), 0)}，"
                f"rule3后命中帧数={_safe_int(bounded.get('stage2_sparse_rule3_hit_count'), 0)}，"
                f"最终触发补推命中帧数={_safe_int(bounded.get('stage2_sparse_hit_count'), 0)}，"
                f"补推帧数={_safe_int(bounded.get('stage2_sparse_refine_count'), 0)}，"
                f"最终2#帧数={_safe_int(bounded.get('stage2_sparse_final_count'), stage2_frames)}，"
                f"节省2#帧数={_safe_int(bounded.get('stage2_sparse_saved_count'), 0)}，"
                f"是否回退全量={'是' if bool(bounded.get('stage2_sparse_fallback_full')) else '否'}"
            )
        self._special_log.write(
            "任务情况-任务详情",
            (
                f"视频完成，实例={self.config.instance_id}，任务ID={run_id}，请求ID={request_id}，视频序号={video_index}，"
                f"机台={wafer_info.get('eqp_id') or video_input_info.get('eqp_id') or ''}，腔室={wafer_info.get('chamber') or ''}，"
                f"结果={result_text}，视频时长={_format_duration_cn_ms(video_duration_ms)}，源帧数={source_frame_count}，"
                f"1#推理帧数={stage1_frames}，2#推理帧数={stage2_frames}，总耗时={_format_duration_cn_ms(video_stage_ms.get('video_total_ms'))}，"
                f"视频准备耗时={_format_duration_cn_ms(trace_timings.get('video_prepare_ms'))}，"
                f"1#耗时={_format_duration_cn_ms(stage1_ms)}，目标筛选耗时={_format_duration_cn_ms(trace_timings.get('target_select_ms'))}，"
                f"2#耗时={_format_duration_cn_ms(stage2_ms)}，规则耗时={_format_duration_cn_ms(video_stage_ms.get('rule_execute_ms'))}，"
                f"渲染耗时={_format_duration_cn_ms(video_stage_ms.get('rule_render_ms'))}，落盘耗时={_format_duration_cn_ms(video_stage_ms.get('protocol_materialize_ms'))}，"
                f"1#单帧耗时={stage1_avg_ms:.2f}毫秒/帧，2#单帧耗时={stage2_avg_ms:.2f}毫秒/帧，{stage1_sparse_text}，{sparse_text}"
            ),
        )
        # [专项日志][生产迭代02-瓶颈拆分]
        # 修改人: Shiver; 修改时间: 2026-06-25;
        # 修改逻辑: 任务完成后补充1#/2#瓶颈拆分日志，现场并发测试可直接判断模型、runtime等待、Future等待、NAS/解码哪一项变慢。
        common_prefix = f"视频瓶颈拆分，实例={self.config.instance_id}，任务ID={run_id}，请求ID={request_id}，视频序号={video_index}"
        self._special_log.write(
            "任务情况-瓶颈拆分",
            (
                f"{common_prefix}，模型=1#，口径=阶段均值包含解码和等待，模型调用均值不包含解码和runtime池等待，"
                f"{_format_infer_stage_bottleneck_cn(label='1#', stage_ms=stage1_ms, frame_count=stage1_frames, detail=stage1_detail)}"
            ),
        )
        self._special_log.write(
            "任务情况-瓶颈拆分",
            (
                f"{common_prefix}，模型=2#，口径=阶段均值包含解码和等待，模型调用均值不包含解码和runtime池等待，"
                f"{_format_infer_stage_bottleneck_cn(label='2#', stage_ms=stage2_ms, frame_count=stage2_frames, detail=stage2_detail)}"
            ),
        )

    def _write_special_task_completed(
        self,
        *,
        run_id: str,
        request_id: str,
        status: str,
        overall_result: str,
        task_video_count: int,
        protocol_results: List[Dict[str, object]],
        task_stage_ms: Dict[str, object],
        error_text: str = "",
    ) -> None:
        alarm_count = sum(1 for item in protocol_results if isinstance(item, dict) and str(item.get("status") or "") == "alarm")
        message = (
            f"任务完成，实例={self.config.instance_id}，任务ID={run_id}，请求ID={request_id}，"
            f"状态={status}，整体结果={overall_result}，视频数量={task_video_count}，告警视频数量={alarm_count}，"
            f"总耗时={_format_duration_cn_ms(task_stage_ms.get('task_total_ms'))}，输入准备耗时={_format_duration_cn_ms(task_stage_ms.get('input_prepare_ms'))}，"
            f"推理总耗时={_format_duration_cn_ms(task_stage_ms.get('infer_total_ms'))}，视频后处理总耗时={_format_duration_cn_ms(task_stage_ms.get('video_post_total_ms'))}，"
            f"结果合并耗时={_format_duration_cn_ms(task_stage_ms.get('merge_summary_ms'))}，告警回调耗时={_format_duration_cn_ms(task_stage_ms.get('alarm_callback_ms'))}，"
            f"清理耗时={_format_duration_cn_ms(task_stage_ms.get('cleanup_ms'))}，JSON写入耗时={_format_duration_cn_ms(task_stage_ms.get('json_write_ms'))}"
        )
        if error_text:
            message += f"，错误={error_text}"
        self._special_log.write("任务情况-任务详情", message)

    def _video_trace_context(
        self,
        *,
        run_id: str,
        request_id: str,
        input_info: Dict[str, object],
        video_input_info: Dict[str, object],
        video_item: Dict[str, object],
        video_index: int,
    ) -> Dict[str, object]:
        # [视频处理耗时复盘JSONL][第一版]
        # 修改人: Shiver; 修改时间: 2026-06-24;
        # 修改逻辑: 所有video_stage/video_summary复用同一上下文字段，方便现场grep和离线汇总。
        wafer_info = video_input_info.get("wafer_info") if isinstance(video_input_info.get("wafer_info"), dict) else {}
        return {
            "trace_id": f"{run_id}#video_{int(video_index)}",
            "run_id": str(run_id),
            "task_id": str(input_info.get("task_id") or request_id or ""),
            "request_id": str(request_id or input_info.get("request_id") or ""),
            "instance_id": self.config.instance_id,
            "video_index": int(video_index),
            "machine_type": str(input_info.get("machine_type") or ""),
            "eqp_id": str(input_info.get("eqp_id") or wafer_info.get("eqp_id") or ""),
            "chamber": str(wafer_info.get("chamber") or ""),
            "wafer_id": str(wafer_info.get("wafer_id") or ""),
            "wafer_start_time": str(wafer_info.get("wafer_start_time") or ""),
            "send_time": str(input_info.get("send_time") or ""),
            "raw_video_path": str(video_item.get("raw_video_path") or video_item.get("video_path") or ""),
            "local_video_path": str(video_item.get("local_video_path") or ""),
        }

    def _write_video_trace_stage(
        self,
        context: Dict[str, object],
        *,
        stage_order: int,
        stage_key: str,
        stage_name: str,
        status: str = "success",
        duration_ms: int = 0,
        started_at: str = "",
        ended_at: str = "",
        workload: Optional[Dict[str, object]] = None,
        timing_detail_ms: Optional[Dict[str, object]] = None,
        detail: Optional[Dict[str, object]] = None,
        error_message: str = "",
        resource: Optional[Dict[str, object]] = None,
    ) -> None:
        self._video_trace.write_stage(
            context,
            stage_order=stage_order,
            stage_key=stage_key,
            stage_name=stage_name,
            status=status,
            started_at=started_at,
            ended_at=ended_at,
            duration_ms=duration_ms,
            workload=workload or {},
            timing_detail_ms=timing_detail_ms or {},
            resource=resource if resource is not None else _trace_resource_snapshot(),
            detail=detail or {},
            error_message=error_message,
        )

    def _write_inference_trace_stages(self, context: Dict[str, object], metadata: Dict[str, object]) -> None:
        processing_info = metadata.get("processing_info") if isinstance(metadata.get("processing_info"), dict) else {}
        bounded = metadata.get("bounded_streaming") if isinstance(metadata.get("bounded_streaming"), dict) else {}
        timings = metadata.get("trace_stage_timings_ms") if isinstance(metadata.get("trace_stage_timings_ms"), dict) else {}
        detail_timings = metadata.get("trace_stage_timing_detail_ms") if isinstance(metadata.get("trace_stage_timing_detail_ms"), dict) else {}
        expected_frames = _safe_int(processing_info.get("expected_frames"), 0)
        prepare_source_io = processing_info.get("source_video_io") if isinstance(processing_info.get("source_video_io"), dict) else {}
        self._write_video_trace_stage(
            context,
            stage_order=100,
            stage_key="video_prepare",
            stage_name="视频准备与基础信息读取",
            duration_ms=_safe_int(timings.get("video_prepare_ms") or metadata.get("video_prepare_ms"), 0),
            workload={"frame_count": expected_frames},
            timing_detail_ms={
                "source_is_probable_nas": bool(prepare_source_io.get("source_is_probable_nas")),
                "source_mount_type": str(prepare_source_io.get("source_mount_type") or ""),
                "source_mount_point": str(prepare_source_io.get("source_mount_point") or ""),
                "source_mount_source": str(prepare_source_io.get("source_mount_source") or ""),
                "source_video_safe_path_ms": prepare_source_io.get("video_safe_path_ms", 0),
                "source_video_open_ms": prepare_source_io.get("video_open_ms_sum", 0),
                "source_video_metadata_ms": prepare_source_io.get("video_metadata_ms_sum", 0),
            },
            detail={
                "source_path": str(processing_info.get("source_path") or metadata.get("input_path") or ""),
                "source_name": str(processing_info.get("source_name") or ""),
                "source_is_probable_nas": bool(prepare_source_io.get("source_is_probable_nas")),
                "source_mount_type": str(prepare_source_io.get("source_mount_type") or ""),
                "source_mount_point": str(prepare_source_io.get("source_mount_point") or ""),
                "source_mount_source": str(prepare_source_io.get("source_mount_source") or ""),
                "source_fps": processing_info.get("src_fps"),
                "target_fps": metadata.get("target_fps"),
                "actual_sample_fps": processing_info.get("actual_sample_fps"),
                "source_frame_count": max(0, _safe_int(processing_info.get("end_frame"), 0) - _safe_int(processing_info.get("start_frame"), 0)),
                "expected_sample_frames": expected_frames,
                "image_width": processing_info.get("image_width"),
                "image_height": processing_info.get("image_height"),
                "start_ms": metadata.get("start_ms"),
                "end_ms": metadata.get("end_ms"),
            },
        )
        self._write_video_trace_stage(
            context,
            stage_order=200,
            stage_key="stage1_stream_infer",
            stage_name="1#流式解码与单图推理",
            duration_ms=_safe_int(timings.get("stage1_stream_infer_ms"), 0),
            workload={
                "decoded_frame_count": _safe_int(bounded.get("stage1_frame_count"), expected_frames),
                "processed_frame_count": _safe_int(bounded.get("stage1_processed_frame_count"), 0),
                "stage1_hit_count": _safe_int(bounded.get("stage1_hit_count"), 0),
                # [1#稀疏补推][生产迭代01]
                # 修改人: Shiver; 修改时间: 2026-06-27;
                # 修改逻辑: trace直接记录1#稀疏扫描/补推核心计数，便于离线汇总A/B。
                "stage1_sparse_enabled": bool(bounded.get("stage1_sparse_enabled")),
                "stage1_sparse_stride": _safe_int(bounded.get("stage1_sparse_stride"), 0),
                "stage1_sparse_initial_count": _safe_int(bounded.get("stage1_sparse_initial_count"), 0),
                "stage1_sparse_droplet_seed_count": _safe_int(bounded.get("stage1_sparse_droplet_seed_count"), 0),
                "stage1_sparse_leak_seed_count": _safe_int(bounded.get("stage1_sparse_leak_seed_count"), 0),
                "stage1_sparse_spread_seed_count": _safe_int(bounded.get("stage1_sparse_spread_seed_count"), 0),
                "stage1_sparse_refine_count": _safe_int(bounded.get("stage1_sparse_refine_count"), 0),
                "stage1_sparse_final_count": _safe_int(bounded.get("stage1_sparse_final_count"), 0),
                "stage1_sparse_saved_count": _safe_int(bounded.get("stage1_sparse_saved_count"), 0),
                "stage1_sparse_fallback_full": bool(bounded.get("stage1_sparse_fallback_full")),
                "queue_limit": _safe_int(bounded.get("queue_limit"), 0),
                "pending_peak": _safe_int(bounded.get("stage1_peak_pending"), 0),
                "resident_raw_frames": _safe_int(bounded.get("resident_raw_frames"), 0),
            },
            timing_detail_ms=detail_timings.get("stage1_stream_infer") if isinstance(detail_timings.get("stage1_stream_infer"), dict) else {},
            detail={"target_output_key": str((metadata.get("model_orchestration") or {}).get("target_output_key") if isinstance(metadata.get("model_orchestration"), dict) else "")},
        )
        self._write_video_trace_stage(
            context,
            stage_order=300,
            stage_key="target_select",
            stage_name="1#目标区间筛选",
            duration_ms=_safe_int(timings.get("target_select_ms"), 0),
            status="skipped" if not bool((metadata.get("model_orchestration") or {}).get("target_filter_enabled") if isinstance(metadata.get("model_orchestration"), dict) else False) else "success",
            workload={
                "stage1_frame_count": _safe_int(bounded.get("stage1_frame_count"), expected_frames),
                "stage1_hit_count": _safe_int(bounded.get("stage1_hit_count"), 0),
                "stage2_target_frame_count": _safe_int(bounded.get("stage2_target_frame_count"), 0),
            },
            detail={
                "target_filter_enabled": bool((metadata.get("model_orchestration") or {}).get("target_filter_enabled") if isinstance(metadata.get("model_orchestration"), dict) else False),
                "target_output_key": str((metadata.get("model_orchestration") or {}).get("target_output_key") if isinstance(metadata.get("model_orchestration"), dict) else ""),
            },
        )
        stage2_target_count = _safe_int(bounded.get("stage2_target_frame_count"), 0)
        self._write_video_trace_stage(
            context,
            stage_order=400,
            stage_key="stage2_stream_infer",
            stage_name="2#流式解码与多图推理",
            status="skipped" if stage2_target_count <= 0 else "success",
            duration_ms=_safe_int(timings.get("stage2_stream_infer_ms"), 0),
            workload={
                "stage2_decode_frame_count": _safe_int(bounded.get("stage2_decode_frames"), 0),
                "stage2_target_frame_count": stage2_target_count,
                "stage2_processed_frame_count": _safe_int(bounded.get("stage2_processed_frame_count"), 0),
                "stage2_skipped_frame_count": _safe_int(bounded.get("stage2_skipped_frame_count"), 0),
                # [2#稀疏补推][生产迭代01]
                # 修改人: Shiver; 修改时间: 2026-06-25;
                # 修改逻辑: 2#阶段trace直接展开稀疏扫描/命中补推核心计数，现场不用解析detail_json。
                "stage2_sparse_enabled": bool(bounded.get("stage2_sparse_enabled")),
                "stage2_sparse_stride": _safe_int(bounded.get("stage2_sparse_stride"), 0),
                "stage2_sparse_index_mode": str(bounded.get("stage2_sparse_index_mode") or ""),
                "stage2_sparse_trigger_mode": str(bounded.get("stage2_sparse_trigger_mode") or ""),
                "stage2_sparse_initial_count": _safe_int(bounded.get("stage2_sparse_initial_count"), 0),
                "stage2_sparse_model_raw_hit_count": _safe_int(bounded.get("stage2_sparse_model_raw_hit_count"), 0),
                "stage2_sparse_rule3_hit_count": _safe_int(bounded.get("stage2_sparse_rule3_hit_count"), 0),
                "stage2_sparse_hit_count": _safe_int(bounded.get("stage2_sparse_hit_count"), 0),
                "stage2_sparse_refine_count": _safe_int(bounded.get("stage2_sparse_refine_count"), 0),
                "stage2_sparse_final_count": _safe_int(bounded.get("stage2_sparse_final_count"), 0),
                "stage2_sparse_saved_count": _safe_int(bounded.get("stage2_sparse_saved_count"), 0),
                "stage2_sparse_boundary_dense_count": _safe_int(bounded.get("stage2_sparse_boundary_dense_count"), 0),
                "stage2_sparse_fallback_full": bool(bounded.get("stage2_sparse_fallback_full")),
                "stage2_sparse_trigger_eval_ms": _safe_int(bounded.get("stage2_sparse_trigger_eval_ms"), 0),
                "stage2_sparse_trigger_fallback_model_raw": bool(bounded.get("stage2_sparse_trigger_fallback_model_raw")),
                "queue_limit": _safe_int(bounded.get("queue_limit"), 0),
                "pending_peak": _safe_int(bounded.get("stage2_peak_pending"), 0),
                "missing_count": _safe_int(bounded.get("stage2_missing_count"), 0),
            },
            timing_detail_ms=detail_timings.get("stage2_stream_infer") if isinstance(detail_timings.get("stage2_stream_infer"), dict) else {},
            detail={
                "window_before": (metadata.get("model_orchestration") or {}).get("multi_image_before_frames") if isinstance(metadata.get("model_orchestration"), dict) else None,
                "window_after": (metadata.get("model_orchestration") or {}).get("multi_image_after_frames") if isinstance(metadata.get("model_orchestration"), dict) else None,
                "stage2_sparse_trigger_output_key": str(bounded.get("stage2_sparse_trigger_output_key") or ""),
                "stage2_sparse_trigger_error": str(bounded.get("stage2_sparse_trigger_error") or ""),
            },
        )

    def _write_video_trace_summary(
        self,
        context: Dict[str, object],
        *,
        video_input_info: Dict[str, object],
        metadata: Dict[str, object],
        rule_result: Dict[str, object],
        video_stage_ms: Dict[str, object],
        protocol_result: Dict[str, object],
        protocol_artifacts: Dict[str, object],
        callback_status: Optional[Dict[str, object]],
        log_path: Path,
        json_path: Path,
    ) -> None:
        processing_info = metadata.get("processing_info") if isinstance(metadata.get("processing_info"), dict) else {}
        bounded = metadata.get("bounded_streaming") if isinstance(metadata.get("bounded_streaming"), dict) else {}
        timings = metadata.get("trace_stage_timings_ms") if isinstance(metadata.get("trace_stage_timings_ms"), dict) else {}
        # [视频处理耗时复盘JSONL][NAS读取诊断01]
        # 修改人: Shiver; 修改时间: 2026-06-24;
        # 修改逻辑: 汇总单视频源AVI读取+解码耗时，覆盖1#、2#以及协议产物按需取原图的二次读取成本。
        detail_timings = metadata.get("trace_stage_timing_detail_ms") if isinstance(metadata.get("trace_stage_timing_detail_ms"), dict) else {}
        stage1_detail = detail_timings.get("stage1_stream_infer") if isinstance(detail_timings.get("stage1_stream_infer"), dict) else {}
        stage2_detail = detail_timings.get("stage2_stream_infer") if isinstance(detail_timings.get("stage2_stream_infer"), dict) else {}
        prepare_source_io = processing_info.get("source_video_io") if isinstance(processing_info.get("source_video_io"), dict) else {}
        provider_source_io = metadata.get("provider_source_video_io") if isinstance(metadata.get("provider_source_video_io"), dict) else {}
        stage1_source_read_decode_ms = _safe_float(stage1_detail.get("source_video_read_decode_ms"), 0.0)
        stage2_source_read_decode_ms = _safe_float(stage2_detail.get("source_video_read_decode_ms"), 0.0)
        provider_source_read_decode_ms = _safe_float(provider_source_io.get("video_read_decode_ms_sum"), 0.0)
        source_video_read_decode_ms = round(stage1_source_read_decode_ms + stage2_source_read_decode_ms + provider_source_read_decode_ms, 3)
        source_video_read_call_count = (
            _safe_int(stage1_detail.get("source_video_read_call_count"), 0)
            + _safe_int(stage2_detail.get("source_video_read_call_count"), 0)
            + _safe_int(provider_source_io.get("video_read_call_count"), 0)
        )
        source_video_read_frame_count = (
            _safe_int(stage1_detail.get("source_video_read_frame_count"), 0)
            + _safe_int(stage2_detail.get("source_video_read_frame_count"), 0)
            + _safe_int(provider_source_io.get("video_read_frame_count"), 0)
        )
        source_video_yield_frame_count = (
            _safe_int(stage1_detail.get("source_video_yield_frame_count"), 0)
            + _safe_int(stage2_detail.get("source_video_yield_frame_count"), 0)
            + _safe_int(provider_source_io.get("video_yield_frame_count"), 0)
        )
        source_is_probable_nas = bool(
            stage1_detail.get("source_is_probable_nas")
            or stage2_detail.get("source_is_probable_nas")
            or provider_source_io.get("source_is_probable_nas")
            or prepare_source_io.get("source_is_probable_nas")
        )
        source_mount_type = str(stage1_detail.get("source_mount_type") or stage2_detail.get("source_mount_type") or provider_source_io.get("source_mount_type") or prepare_source_io.get("source_mount_type") or "")
        source_mount_point = str(stage1_detail.get("source_mount_point") or stage2_detail.get("source_mount_point") or provider_source_io.get("source_mount_point") or prepare_source_io.get("source_mount_point") or "")
        source_mount_source = str(stage1_detail.get("source_mount_source") or stage2_detail.get("source_mount_source") or provider_source_io.get("source_mount_source") or prepare_source_io.get("source_mount_source") or "")
        wafer_info = video_input_info.get("wafer_info") if isinstance(video_input_info.get("wafer_info"), dict) else {}
        source_fps = float(processing_info.get("src_fps") or 0.0)
        source_frame_count = max(0, _safe_int(processing_info.get("end_frame"), 0) - _safe_int(processing_info.get("start_frame"), 0))
        duration_sec = float(source_frame_count) / source_fps if source_fps > 0 else 0.0
        callback_status = callback_status if isinstance(callback_status, dict) else {}
        summary = {
            "video_status": "success" if str(protocol_result.get("status") or "") != "internal_error" else "failed",
            "overall_result": str(rule_result.get("overall_result") or ("NG" if bool(rule_result.get("has_ng")) else "OK")),
            "protocol_status": str(protocol_result.get("status") or ""),
            "business": {
                "machine_type": str(video_input_info.get("machine_type") or ""),
                "eqp_id": str(video_input_info.get("eqp_id") or wafer_info.get("eqp_id") or ""),
                "chamber": str(wafer_info.get("chamber") or ""),
                "wafer_id": str(wafer_info.get("wafer_id") or ""),
                "wafer_start_time": str(wafer_info.get("wafer_start_time") or ""),
                "send_time": str(video_input_info.get("send_time") or ""),
            },
            "video_info": {
                "raw_video_path": str(video_input_info.get("raw_video_path") or ""),
                "local_video_path": str(video_input_info.get("local_video_path") or ""),
                "video_suffix": Path(str(video_input_info.get("raw_video_path") or video_input_info.get("local_video_path") or "")).suffix.lower(),
                "video_size_bytes": _file_size_bytes(video_input_info.get("local_video_path") or video_input_info.get("raw_video_path")),
                "source_fps": source_fps,
                "target_fps": metadata.get("target_fps"),
                "actual_sample_fps": processing_info.get("actual_sample_fps"),
                "duration_sec": duration_sec,
                "source_frame_count": source_frame_count,
                "expected_sample_frames": _safe_int(processing_info.get("expected_frames"), 0),
                "sampled_frame_count": _safe_int(bounded.get("stage1_frame_count"), _safe_int(processing_info.get("expected_frames"), 0)),
                "image_width": processing_info.get("image_width"),
                "image_height": processing_info.get("image_height"),
                "source_is_probable_nas": source_is_probable_nas,
                "source_mount_type": source_mount_type,
                "source_mount_point": source_mount_point,
                "source_mount_source": source_mount_source,
            },
            "workload": {
                "stage1_frame_count": _safe_int(bounded.get("stage1_frame_count"), 0),
                "stage1_hit_count": _safe_int(bounded.get("stage1_hit_count"), 0),
                "stage2_target_frame_count": _safe_int(bounded.get("stage2_target_frame_count"), 0),
                "stage2_processed_frame_count": _safe_int(bounded.get("stage2_processed_frame_count"), 0),
                # [2#稀疏补推][生产迭代01]
                # 修改人: Shiver; 修改时间: 2026-06-25;
                # 修改逻辑: video_summary 同步输出稀疏补推计数，便于离线总览直接统计。
                "stage2_sparse_enabled": bool(bounded.get("stage2_sparse_enabled")),
                "stage2_sparse_stride": _safe_int(bounded.get("stage2_sparse_stride"), 0),
                "stage2_sparse_trigger_mode": str(bounded.get("stage2_sparse_trigger_mode") or ""),
                "stage2_sparse_initial_count": _safe_int(bounded.get("stage2_sparse_initial_count"), 0),
                "stage2_sparse_model_raw_hit_count": _safe_int(bounded.get("stage2_sparse_model_raw_hit_count"), 0),
                "stage2_sparse_rule3_hit_count": _safe_int(bounded.get("stage2_sparse_rule3_hit_count"), 0),
                "stage2_sparse_hit_count": _safe_int(bounded.get("stage2_sparse_hit_count"), 0),
                "stage2_sparse_refine_count": _safe_int(bounded.get("stage2_sparse_refine_count"), 0),
                "stage2_sparse_final_count": _safe_int(bounded.get("stage2_sparse_final_count"), 0),
                "stage2_sparse_saved_count": _safe_int(bounded.get("stage2_sparse_saved_count"), 0),
                "stage2_sparse_boundary_dense_count": _safe_int(bounded.get("stage2_sparse_boundary_dense_count"), 0),
                "stage2_sparse_fallback_full": bool(bounded.get("stage2_sparse_fallback_full")),
                "stage2_sparse_trigger_eval_ms": _safe_int(bounded.get("stage2_sparse_trigger_eval_ms"), 0),
                "stage2_sparse_trigger_fallback_model_raw": bool(bounded.get("stage2_sparse_trigger_fallback_model_raw")),
                "rule_frame_count": len(rule_result.get("frames", []) or []),
                "rendered_frame_count": _safe_int(protocol_artifacts.get("rendered_frame_count"), 0),
                "gif_frame_count": _safe_int(protocol_artifacts.get("gif_frame_count"), 0),
                "source_video_read_decode_ms": source_video_read_decode_ms,
                "stage1_source_video_read_decode_ms": round(stage1_source_read_decode_ms, 3),
                "stage2_source_video_read_decode_ms": round(stage2_source_read_decode_ms, 3),
                "provider_source_video_read_decode_ms": round(provider_source_read_decode_ms, 3),
                "source_video_read_call_count": source_video_read_call_count,
                "source_video_read_frame_count": source_video_read_frame_count,
                "source_video_yield_frame_count": source_video_yield_frame_count,
            },
            "timing_ms": {
                "video_total_ms": _safe_int(video_stage_ms.get("video_total_ms"), 0),
                "video_prepare_ms": _safe_int(timings.get("video_prepare_ms") or metadata.get("video_prepare_ms"), 0),
                "stage1_stream_infer_ms": _safe_int(timings.get("stage1_stream_infer_ms"), 0),
                "target_select_ms": _safe_int(timings.get("target_select_ms"), 0),
                "stage2_stream_infer_ms": _safe_int(timings.get("stage2_stream_infer_ms"), 0),
                "rule_execute_ms": _safe_int(video_stage_ms.get("rule_execute_ms"), 0),
                "rule_render_ms": _safe_int(video_stage_ms.get("rule_render_ms"), 0),
                "rule_result_read_ms": _safe_int(video_stage_ms.get("rule_result_read_ms"), 0),
                "frame_assembly_ms": _safe_int(video_stage_ms.get("frame_assembly_ms"), 0),
                "testoutput_save_ms": _safe_int(video_stage_ms.get("testoutput_save_ms"), 0),
                "protocol_materialize_ms": _safe_int(video_stage_ms.get("protocol_materialize_ms"), 0),
                "alarm_callback_ms": _safe_int(callback_status.get("duration_ms"), 0),
                "video_release_ms": _safe_int(video_stage_ms.get("video_release_ms"), 0),
            },
            "artifacts": {
                "result_json_path": str(json_path),
                "text_log_path": str(log_path),
                "select_img_path": str(protocol_artifacts.get("select_img_path") or ""),
                "original_img_path": str(protocol_artifacts.get("original_img_path") or ""),
                "roi_img_path": str(protocol_artifacts.get("roi_img_path") or ""),
                "original_gif_path": str(protocol_artifacts.get("original_gif_path") or ""),
                "rendered_gif_path": str(protocol_artifacts.get("rendered_gif_path") or ""),
                "alarm_video_path": str(protocol_artifacts.get("alarm_video_path") or ""),
            },
            "alarm_frame": {
                "sample_index": _safe_int(protocol_artifacts.get("sample_index"), 0),
                "matched_label": str(protocol_artifacts.get("matched_label") or ""),
                "priority_rank": _safe_int(protocol_artifacts.get("priority_rank"), 0),
            },
            "callback": {
                "alarm_callback_attempted": bool(callback_status.get("attempted")),
                "alarm_callback_status_code": callback_status.get("status_code"),
                "alarm_callback_error": str(callback_status.get("error") or ""),
            },
            "started_at": str((metadata.get("video_timing") or {}).get("started_at") if isinstance(metadata.get("video_timing"), dict) else ""),
            "ended_at": _now(),
            "error_message": "",
            "traceback": "",
        }
        self._video_trace.write_summary(context, summary)

    def health(self) -> Dict[str, object]:
        stats = self._stats_snapshot()
        return {
            "initialized": True,
            "initialized_at": self.initialized_at,
            "timezone": self.config.timezone or get_app_timezone_name(),
            "current_time": _now(),
            "model_count": len(self.config.model_paths),
            "output_count": len(self.model_outputs),
            "model_orchestration": self.model_orchestration,
            "host": self.config.host,
            "port": self.config.port,
            "instance_id": self.config.instance_id,
            "pending": stats.get("pending", 0),
            "queued": stats.get("queued", 0),
            "running": stats.get("running", 0),
            "completed_today": stats.get("completed_today", 0),
            "success_today": stats.get("success_today", 0),
            "failed_today": stats.get("failed_today", 0),
            "accepted_today": stats.get("accepted_today", 0),
            "progress_log_interval_sec": self.config.progress_log_interval_sec,
            "resources": _resource_snapshot(),
        }

    def models(self) -> Dict[str, object]:
        return {
            "models": [str(path) for path in self.config.model_paths],
            "outputs": self.model_outputs,
            "model_orchestration": self.model_orchestration,
        }

    def submit_request(self, payload: Dict[str, object]) -> Dict[str, object]:
        # ===== 客户现场协议适配点：创建异步任务的业务入口 =====
        # server.py 已经完成 HTTP 层 JSON 解析，这里的 payload 是业务字典。
        # 当前逻辑从协议 task_id 生成 run_id，并立即返回 accepted。
        # 如果客户要求 ACK 中返回固定字段、任务号使用客户流水号、或需要记录
        # 更多客户字段，可在这里调整 ACK 字典和 run_id 生成规则。
        input_info = self._parse_input(payload)
        if not self._job_slots.acquire(blocking=False):
            print("RuntimeError(", f"任务队列已满，请稍后重试。", ")")
            raise RuntimeError("任务队列已满，请稍后重试。")
        task_id = str(input_info.get("task_id") or "").strip()
        request_id = task_id
        output_name = _input_output_name(input_info)
        base_run_id = _run_id_with_instance(task_id or output_name or app_compact_timestamp(), self.config.instance_id)
        run_id = self._unique_run_id(base_run_id)
        current_log_dir = _daily_log_dir(self.config.log_dir)
        log_path = current_log_dir / f"{output_name}.log"
        json_path = current_log_dir / f"{output_name}.json"
        input_info["output_name"] = output_name
        created_at = _now()
        ack = {
            "status": "accepted",
            "run_id": run_id,
            "instance_id": self.config.instance_id,
            "request_id": request_id,
            "created_at": created_at,
            "logs": {"result_json": str(json_path), "text_log": str(log_path)},
            "message": "任务已接收，后台异步处理；结果请查看日志或回调。",
        }
        self._bump_stats("accepted", 1)
        # [专项日志][生产迭代03-请求/视频剩余口径]
        # 修改人: Shiver; 修改时间: 2026-06-27;
        # 修改逻辑: 请求入队时同步累计该请求包含的视频数，专项汇总可输出剩余视频数。
        self._bump_stats("accepted_videos", self._input_video_count(input_info))
        self._remember_special_first_request()
        self._special_log.write("请求情况", self._request_summary_text(input_info) + f"，任务ID={run_id}，接收结果=已入队")
        self._job_executor.submit(
            self._run_job,
            run_id,
            payload,
            input_info,
            log_path,
            json_path,
        )
        return ack

    def run_request(self, payload: Dict[str, object]) -> Dict[str, object]:
        """Synchronous compatibility helper; HTTP now uses submit_request()."""
        input_info = self._parse_input(payload)
        task_id = str(input_info.get("task_id") or "").strip()
        output_name = _input_output_name(input_info)
        input_info["output_name"] = output_name
        run_id = self._unique_run_id(_run_id_with_instance(task_id or output_name or app_compact_timestamp(), self.config.instance_id))
        current_log_dir = _daily_log_dir(self.config.log_dir)
        log_path = current_log_dir / f"{output_name}.log"
        json_path = current_log_dir / f"{output_name}.json"
        return self._execute_pipeline(run_id, task_id, payload, input_info, log_path, json_path)

    def _run_job(self, run_id: str, payload: Dict[str, object], input_info: Dict[str, object], log_path: Path, json_path: Path) -> None:
        task_id = str(input_info.get("task_id") or "").strip()
        final_result: Dict[str, object] = {}
        self._bump_stats("running", 1)
        try:
            result = self._execute_pipeline(run_id, task_id, payload, input_info, log_path, json_path)
            final_result = result
            final_status = "success" if result.get("status") == "success" else "failed"
            self._bump_stats(final_status, 1)
        except Exception as exc:
            err = traceback.format_exc()
            fallback = {
                "request_id": task_id,
                "run_id": run_id,
                "instance_id": self.config.instance_id,
                "status": "failed",
                "error": str(exc),
                "traceback": err,
                "input": input_info,
                "logs": {"result_json": str(json_path), "text_log": str(log_path)},
            }
            final_result = fallback
            json_path.write_text(json.dumps(fallback, ensure_ascii=False, indent=2), encoding="utf-8")
            self._bump_stats("failed", 1)
        finally:
            self._bump_stats("running", -1)
            try:
                self._finalize_video_stats_for_request(input_info)
            except Exception as exc:
                print(f"[专项日志][任务情况-汇总情况] 请求视频终态统计失败：run_id={run_id} error={exc}", file=sys.stderr)
            self._enqueue_task_callback(payload, input_info, final_result)
            self._job_slots.release()

    def _enqueue_task_callback(self, payload: Dict[str, object], input_info: Dict[str, object], result: Dict[str, object]) -> None:
        callback_url = str(payload.get("callback_url") or "").strip()
        if not callback_url:
            print(f"未配置任务完成 callback_url，跳过任务回调：task_id={input_info.get('task_id', '')}")
            self._special_log.write("回调情况", f"任务完成回调跳过，实例={self.config.instance_id}，请求ID={input_info.get('task_id', '')}，原因=未配置任务完成回调地址")
            return
        task_payload = _build_task_callback_task(input_info, result)
        self._task_callback_batcher.enqueue(callback_url, task_payload)
        self._special_log.write("回调情况", f"任务完成回调已入队，实例={self.config.instance_id}，请求ID={input_info.get('task_id', '')}，回调地址={callback_url}")

    def _execute_pipeline(
        self,
        run_id: str,
        request_id: str,
        payload: Dict[str, object],
        input_info: Dict[str, object],
        log_path: Path,
        json_path: Path,
    ) -> Dict[str, object]:
        # ===== 客户现场协议适配点：内部处理结果/最终 JSON 组装 =====
        # 这里把推理 DB、规则 DB、每帧标签、原图/渲染图路径、综合 OK/NG
        # 组装成最终 result JSON，并写入 logs/<video_name>.json。
        # 如果客户要求最终结果字段名、OK/NG 表达、图片路径、DB 路径或
        # 日志结构不同，主要改 result 初始结构、result.update(...) 和
        # artifacts/frames/summary 的组装逻辑。
        logger = RunLogger(log_path)
        callback_status = {"attempted": False, "url": "", "status_code": None, "error": "", "response_text": ""}
        result: Dict[str, object] = {
            "request_id": request_id,
            "run_id": run_id,
            "instance_id": self.config.instance_id,
            "status": "running",
            "overall_result": "UNKNOWN",
            "has_ng": False,
            "input": input_info,
            "models": [str(path) for path in self.config.model_paths],
            "outputs": self.model_outputs,
            "infer_dbs": [],
            "rule_dbs": [],
            "frames": [],
            "per_db_results": [],
            "summary": {},
            "artifacts": {
                "original_frame_dirs": [],
                "rule_render_dirs": [],
                "infer_dbs": [],
                "rule_dbs": [],
                "testoutput_original_dirs": [],
                "testoutput_original_images": [],
                "alarm_representative_frame": {},
                "alarm_gif_path": "",
                "alarm_rendered_gif_path": "",
                "alarm_original_gif_path": "",
                "alarm_video_path": "",
                "alarm_video_written": False,
                "protocol_artifacts_by_video": [],
            },
            "logs": {"result_json": str(json_path), "text_log": str(log_path)},
            "callback": callback_status,
            "alarm_callback": callback_status,
            "protocol_result": None,
            "protocol_results": [],
        }
        started = time.monotonic()
        task_stage_ms = _zero_timing(TASK_TIMING_STAGES)
        task_status_text = "unknown"
        task_overall_text = "UNKNOWN"
        task_error_text = ""
        task_video_count = 0
        # [1.内存模型预加载整段视频全部帧][生产迭代02-有界流式]
        # 修改人: Shiver; 修改时间: 2026-06-22;
        # 修改逻辑: 提前定义结果容器，确保成功、失败和早退路径都能在finally关闭provider。
        memory_infer_results = []
        protocol_results: List[Dict[str, object]] = []
        # [1.内存模型预加载整段视频全部帧][生产迭代01-日志]
        # 修改人: Shiver; 修改时间: 2026-06-22;
        # 修改逻辑: 为每个任务记录可对比的起始基线；当前迭代仍是legacy_full_frames，
        # 后续切换有界流式时会改为bounded_streaming，避免误判已完成内存重构。
        # [1.内存模型预加载整段视频全部帧][通篇审查-模式日志]
        # 修改人: Shiver; 修改时间: 2026-06-23;
        # 修改逻辑: 有界流式只适用于memory模式；disk模式不能误报mode=bounded_streaming。
        configured_memory_mode = str(self.model_orchestration.get("intermediate_storage_mode") or "disk").lower() == "memory"
        bounded_streaming_enabled = configured_memory_mode and bool(self.model_orchestration.get("bounded_frame_streaming"))
        logger.write(
            f"{MEMORY_FIX_LOG_PREFIX}[TASK_START] run_id={run_id} task_id={request_id} "
            f"mode={'bounded_streaming' if bounded_streaming_enabled else 'legacy_full_frames'} "
            f"video_count={len(input_info.get('video_items', []) or [])} "
            f"frame_queue_size={self.config.frame_queue_size} video_workers={self.config.video_workers} "
            f"{_memory_fix_snapshot_text()}"
        )
        self._special_log.write(
            "任务情况-任务详情",
            (
                f"任务开始，实例={self.config.instance_id}，任务ID={run_id}，请求ID={request_id}，"
                f"视频数量={len(input_info.get('video_items', []) or [])}，开始时间={_now()}，"
                f"帧队列上限={self.config.frame_queue_size}，视频并发数={self.config.video_workers}"
            ),
        )

        try:
            input_prepare_started = time.monotonic()
            logger.write("开始异步 HTTP 推理缓存流程。")
            logger.write(f"请求参数：{json.dumps(input_info, ensure_ascii=False)}")
            if not input_info.get("video_items"):
                logger.write("所有视频均被过滤配置拒绝，跳过推理流程。")
                result = _noop_rejected_result(
                    run_id=run_id,
                    request_id=request_id,
                    input_info=input_info,
                    json_path=json_path,
                    log_path=log_path,
                    started=started,
                )
                task_stage_ms["input_prepare_ms"] = _elapsed_ms(input_prepare_started)
                task_status_text = "success"
                task_overall_text = "REJECTED"
                task_video_count = 0
                return result
            end_ms = None if float(input_info["end_sec"]) <= 0 else float(input_info["end_sec"]) * 1000.0
            sources = [
                MediaSource(
                    Path(str(item["local_video_path"])),
                    "video",
                    output_name=_video_output_name(item.get("raw_video_path") or item.get("video_path") or item.get("local_video_path")),
                )
                for item in input_info.get("video_items", [])
            ]
            memory_mode = configured_memory_mode
            task_stage_ms["input_prepare_ms"] = _elapsed_ms(input_prepare_started)
            infer_started = time.monotonic()
            if memory_mode:
                memory_infer_kwargs = {
                    "sources": sources,
                    "prepared_context": self.inference_context,
                    "target_fps": float(input_info["target_fps"]),
                    "start_ms": float(input_info["start_sec"]) * 1000.0,
                    "end_ms": end_ms,
                    "infer_workers": self.config.infer_workers,
                    "frame_queue_size": self.config.frame_queue_size,
                    "video_workers": self.config.video_workers,
                    "orchestration_enabled": bool(self.model_orchestration.get("enabled")),
                    "require_two_models": bool(self.model_orchestration.get("require_two_models")),
                    "target_filter_enabled": bool(self.model_orchestration.get("target_filter_enabled")),
                    "target_output_key": str(self.model_orchestration.get("target_output_key") or ""),
                    "target_min_consecutive_frames": int(self.model_orchestration.get("target_min_consecutive_frames") or 1),
                    "target_pre_expand_sec": float(self.model_orchestration.get("target_pre_expand_sec") or 0.0),
                    "target_post_expand_sec": float(self.model_orchestration.get("target_post_expand_sec") or 0.0),
                    "multi_image_before_frames": int(self.model_orchestration.get("multi_image_before_frames") or 0),
                    "multi_image_after_frames": int(self.model_orchestration.get("multi_image_after_frames") or 0),
                    "log": logger.write,
                    "progress": logger.progress,
                }
                memory_infer_parameters = inspect.signature(run_inference_memory_prepared).parameters
                optional_memory_infer_kwargs = {
                    "bounded_streaming": bounded_streaming_enabled,
                    "provider_cache_size": int(self.model_orchestration.get("bounded_frame_provider_cache_size") or 16),
                    # [1#稀疏补推][生产迭代01]
                    # 修改人: Shiver; 修改时间: 2026-06-27;
                    # 修改逻辑: 将1#稀疏扫描/按缺陷补推参数透传到底层；底层不支持时自动忽略，兼容回滚包。
                    "stage1_sparse_enabled": bool(self.model_orchestration.get("stage1_sparse_enabled")),
                    "stage1_sparse_stride": int(self.model_orchestration.get("stage1_sparse_stride") or 1),
                    "stage1_sparse_droplet_refine_radius": int(self.model_orchestration.get("stage1_sparse_droplet_refine_radius") or 0),
                    "stage1_sparse_leak_refine_radius": int(self.model_orchestration.get("stage1_sparse_leak_refine_radius") or 0),
                    "stage1_sparse_spread_refine_radius": int(self.model_orchestration.get("stage1_sparse_spread_refine_radius") or 0),
                    "stage1_sparse_fallback_refine_ratio": float(self.model_orchestration.get("stage1_sparse_fallback_refine_ratio") or 0.0),
                    # [2#稀疏补推][生产迭代01]
                    # 修改人: Shiver; 修改时间: 2026-06-25;
                    # 修改逻辑: 仅在底层函数支持对应参数时透传，兼容现场旧包回滚。
                    "stage2_sparse_enabled": bool(self.model_orchestration.get("stage2_sparse_enabled")),
                    "stage2_sparse_stride": int(self.model_orchestration.get("stage2_sparse_stride") or 1),
                    "stage2_sparse_refine_radius": int(self.model_orchestration.get("stage2_sparse_refine_radius") or 0),
                    "stage2_sparse_boundary_dense_radius": int(self.model_orchestration.get("stage2_sparse_boundary_dense_radius") or 0),
                    "stage2_sparse_trigger_output_key": str(self.model_orchestration.get("stage2_sparse_trigger_output_key") or ""),
                    "stage2_sparse_trigger_mode": str(self.model_orchestration.get("stage2_sparse_trigger_mode") or "model_raw"),
                    "stage2_sparse_index_mode": str(self.model_orchestration.get("stage2_sparse_index_mode") or "target_position"),
                    "stage2_sparse_fallback_hit_rate": float(self.model_orchestration.get("stage2_sparse_fallback_hit_rate") or 0.0),
                    # [1.内存模型预加载整段视频全部帧][通篇审查-日志关联]
                    # 修改人: Shiver; 修改时间: 2026-06-23; 向底层STREAM日志传递任务ID。
                    "diagnostic_run_id": run_id,
                }
                for key, value in optional_memory_infer_kwargs.items():
                    if key in memory_infer_parameters:
                        memory_infer_kwargs[key] = value
                if bounded_streaming_enabled and "bounded_streaming" not in memory_infer_parameters:
                    logger.write(
                        f"{MEMORY_FIX_LOG_PREFIX}[STREAM_UNSUPPORTED] run_id={run_id} "
                        "当前 infer_cache_core.run_inference_memory_prepared 不支持 bounded_streaming 参数，"
                        "本次任务回退为 legacy_full_frames。"
                    )
                memory_infer_results = run_inference_memory_prepared(**memory_infer_kwargs)
                infer_dbs = [item.logical_uri for item in memory_infer_results]
                logger.write(f"内存推理完成，结果数量：{len(memory_infer_results)}")
                # [1.内存模型预加载整段视频全部帧][生产迭代01-日志]
                # 修改人: Shiver; 修改时间: 2026-06-22;
                # 修改逻辑: 同时记录总帧元数据数与实际常驻原图数；有界流式应为resident_raw_frame_count=0。
                total_frame_count = sum(len(item.frames) for item in memory_infer_results)
                resident_raw_frame_count = sum(
                    1 for item in memory_infer_results for frame in item.frames if frame.image is not None
                )
                logger.write(
                    f"{MEMORY_FIX_LOG_PREFIX}[INFERENCE_READY] run_id={run_id} "
                    f"frame_metadata_count={total_frame_count} resident_raw_frame_count={resident_raw_frame_count} "
                    f"{_memory_fix_snapshot_text()}"
                )
            else:
                memory_infer_results = []
                infer_dbs = run_inference_cache_prepared(
                    sources=sources,
                    prepared_context=self.inference_context,
                    output_root=self.config.output_root,
                    target_fps=float(input_info["target_fps"]),
                    start_ms=float(input_info["start_sec"]) * 1000.0,
                    end_ms=end_ms,
                    save_frames=self.config.save_frames,
                    infer_workers=self.config.infer_workers,
                    frame_queue_size=self.config.frame_queue_size,
                    video_workers=self.config.video_workers,
                    orchestration_enabled=bool(self.model_orchestration.get("enabled")),
                    require_two_models=bool(self.model_orchestration.get("require_two_models")),
                    target_filter_enabled=bool(self.model_orchestration.get("target_filter_enabled")),
                    target_output_key=str(self.model_orchestration.get("target_output_key") or ""),
                    target_min_consecutive_frames=int(self.model_orchestration.get("target_min_consecutive_frames") or 1),
                    target_pre_expand_sec=float(self.model_orchestration.get("target_pre_expand_sec") or 0.0),
                    target_post_expand_sec=float(self.model_orchestration.get("target_post_expand_sec") or 0.0),
                    multi_image_before_frames=int(self.model_orchestration.get("multi_image_before_frames") or 0),
                    multi_image_after_frames=int(self.model_orchestration.get("multi_image_after_frames") or 0),
                    save_multi_image_windows=bool(self.model_orchestration.get("save_multi_image_windows")),
                    log=logger.write,
                    progress=logger.progress,
                )
                logger.write(f"推理完成，DB 数量：{len(infer_dbs)}")
            task_stage_ms["infer_total_ms"] = _elapsed_ms(infer_started)
            result["infer_dbs"] = [str(path) for path in infer_dbs]

            rule_dbs: List[Path] = []
            render_dirs: List[Path] = []
            testoutput_original_dirs: List[str] = []
            testoutput_original_images: List[str] = []
            per_db_results: List[Dict[str, object]] = []
            frames: List[Dict[str, object]] = []
            protocol_results = []
            protocol_artifacts_by_video: List[Dict[str, object]] = []
            video_trace_summaries: List[Dict[str, object]] = []
            video_items = [item for item in input_info.get("video_items", []) if isinstance(item, dict)]
            video_post_started = time.monotonic()
            for video_index, infer_db in enumerate(infer_dbs):
                video_service_started = time.monotonic()
                video_stage_ms = _zero_timing(VIDEO_TIMING_STAGES)
                video_item = video_items[video_index] if video_index < len(video_items) else {}
                video_path_for_log = str(video_item.get("raw_video_path") or video_item.get("video_path") or video_item.get("local_video_path") or infer_db)
                video_input_info = _single_video_input_info(input_info, video_item, video_index)
                trace_context = self._video_trace_context(
                    run_id=run_id,
                    request_id=request_id,
                    input_info=input_info,
                    video_input_info=video_input_info,
                    video_item=video_item,
                    video_index=video_index,
                )
                alarm_priority_labels = [str(label) for label in (self.model_orchestration.get("alarm_frame_priority_labels") or [])]
                alarm_gif_before_frames = int(self.model_orchestration.get("alarm_gif_before_frames") or 0)
                alarm_gif_after_frames = int(self.model_orchestration.get("alarm_gif_after_frames") or 0)
                infer_elapsed_ms = 0
                if memory_mode and video_index < len(memory_infer_results):
                    timing = memory_infer_results[video_index].metadata.get("video_timing", {})
                    if isinstance(timing, dict):
                        infer_elapsed_ms = _safe_int(timing.get("infer_elapsed_ms"), 0)
                logger.write(f"视频后处理开始：video_index={video_index}，path={video_path_for_log}")
                video_stage_ms["infer_ms"] = int(infer_elapsed_ms)
                if memory_mode:
                    memory_infer = memory_infer_results[video_index]
                    self._write_inference_trace_stages(trace_context, memory_infer.metadata)
                    logger.write(f"开始执行内存规则：{memory_infer.logical_uri}")
                    stage_started = time.monotonic()
                    memory_rule = run_rules_memory(memory_infer, rule_names=None, log=logger.write, progress=logger.progress)
                    video_stage_ms["rule_execute_ms"] = _elapsed_ms(stage_started)
                    rule_db = memory_rule.logical_uri
                    rule_dbs.append(rule_db)
                    logger.write(f"规则执行完成：{rule_db}")
                    rendered_images_by_sample_index: Dict[int, object] = {}
                    stage_started = time.monotonic()
                    rule_result = read_memory_rule_result(memory_rule)
                    video_stage_ms["rule_result_read_ms"] = _elapsed_ms(stage_started)
                    per_db_results.append(rule_result)
                    self._write_video_trace_stage(
                        trace_context,
                        stage_order=500,
                        stage_key="rule_execute",
                        stage_name="规则执行",
                        duration_ms=_safe_int(video_stage_ms.get("rule_execute_ms"), 0),
                        workload={
                            "frame_count": len(rule_result.get("frames", []) or []),
                            "label_count": sum(len(frame.get("labels", []) or []) for frame in rule_result.get("frames", []) if isinstance(frame, dict)),
                            "ng_frame_count": _safe_int((rule_result.get("summary") or {}).get("ng_frame_count") if isinstance(rule_result.get("summary"), dict) else 0, 0),
                            "ok_frame_count": _safe_int((rule_result.get("summary") or {}).get("ok_frame_count") if isinstance(rule_result.get("summary"), dict) else 0, 0),
                        },
                        detail={"rule_db": str(rule_db), "infer_db": str(infer_db)},
                    )
                    self._write_video_trace_stage(
                        trace_context,
                        stage_order=700,
                        stage_key="rule_result_read",
                        stage_name="规则结果读取",
                        duration_ms=_safe_int(video_stage_ms.get("rule_result_read_ms"), 0),
                        workload={
                            "frame_count": len(rule_result.get("frames", []) or []),
                            "ng_frame_count": _safe_int((rule_result.get("summary") or {}).get("ng_frame_count") if isinstance(rule_result.get("summary"), dict) else 0, 0),
                            "ok_frame_count": _safe_int((rule_result.get("summary") or {}).get("ok_frame_count") if isinstance(rule_result.get("summary"), dict) else 0, 0),
                        },
                    )
                    # [1.内存模型预加载整段视频全部帧][生产迭代02-有界流式]
                    # 修改人: Shiver; 修改时间: 2026-06-22;
                    # 修改逻辑: 流式模式按需取原图；关闭流式时保持原全量字典行为。
                    image_provider = getattr(memory_infer, "image_provider", None)
                    if image_provider is not None:
                        original_images_by_sample_index = _ProviderImageMap(image_provider)
                    else:
                        original_images_by_sample_index = {int(frame.sample_index): frame.image for frame in memory_infer.frames}
                    current_frames: List[Dict[str, object]] = []
                    stage_started = time.monotonic()
                    for frame in rule_result.get("frames", []):
                        frame_item = dict(frame)
                        sample_index = _frame_sample_index(frame_item, 0)
                        frame_item["rule_db"] = str(rule_db)
                        frame_item["infer_db"] = str(infer_db)
                        frame_item["video_index"] = int(video_index)
                        frame_item["raw_video_path"] = str(video_item.get("raw_video_path") or video_item.get("video_path") or "")
                        frame_item["local_video_path"] = str(video_item.get("local_video_path") or "")
                        frame_item["image_path"] = f"memory://video_{video_index}/sample/{sample_index}/original"
                        frame_item["rendered_rule_image_path"] = f"memory://video_{video_index}/sample/{sample_index}/rendered"
                        current_frames.append(frame_item)
                        frames.append(frame_item)
                    video_stage_ms["frame_assembly_ms"] = _elapsed_ms(stage_started)
                    self._write_video_trace_stage(
                        trace_context,
                        stage_order=800,
                        stage_key="frame_assembly",
                        stage_name="帧结果组装",
                        duration_ms=_safe_int(video_stage_ms.get("frame_assembly_ms"), 0),
                        workload={"frame_count": len(current_frames)},
                    )
                    stage_started = time.monotonic()
                    saved_testoutputs = _save_testoutput_original_images_memory(
                        frames=current_frames,
                        images_by_sample_index=original_images_by_sample_index,
                        output_dir=self.config.result_root / "testoutput_originals" / str(run_id) / str(video_index),
                        enabled=bool(self.model_orchestration.get("save_testoutput_original_images")),
                        max_count=int(self.model_orchestration.get("max_testoutput_original_images_per_video") or 0),
                        label_prefix=str(self.model_orchestration.get("testoutput_label_prefix") or "testoutput-"),
                        logger=logger,
                    )
                    video_stage_ms["testoutput_save_ms"] = _elapsed_ms(stage_started)
                    self._write_video_trace_stage(
                        trace_context,
                        stage_order=900,
                        stage_key="testoutput_save",
                        stage_name="testoutput原图保存",
                        status="success" if saved_testoutputs.get("images") else "skipped",
                        duration_ms=_safe_int(video_stage_ms.get("testoutput_save_ms"), 0),
                        workload={
                            "enabled": bool(self.model_orchestration.get("save_testoutput_original_images")),
                            "max_count": int(self.model_orchestration.get("max_testoutput_original_images_per_video") or 0),
                            "saved_count": len(saved_testoutputs.get("images", []) or []),
                        },
                        detail={"output_dir": str(saved_testoutputs.get("dir") or ""), "saved_images": list(saved_testoutputs.get("images", []) or [])},
                    )
                    # [规则渲染按需落盘][生产迭代01-按告警帧渲染]
                    # 修改人: Shiver; 修改时间: 2026-06-24;
                    # 修改逻辑: 内存模式先读取规则结果并判断是否 alarm；normal 视频不再全量渲染。
                    # alarm 视频只渲染协议落盘需要的代表帧与 GIF 窗口帧，避免 2000~4000 帧全量渲染。
                    video_has_ng_for_render = bool(rule_result.get("has_ng"))
                    render_target_sample_indexes: List[int] = []
                    render_selected_info: Dict[str, object] = {}
                    render_gif_sample_indexes: List[int] = []
                    provider_stats: Dict[str, object] = {}
                    render_status = "skipped"
                    render_skip_reason = ""
                    if self.config.render_rule_images and video_has_ng_for_render:
                        render_selected_info = _select_alarm_representative_frame(current_frames, alarm_priority_labels)
                        selected_sample_index = _frame_sample_index(render_selected_info, _safe_int(render_selected_info.get("frame_index"), 0))
                        render_gif_plan = _ng_alarm_gif_frame_plan(
                            frames=current_frames,
                            center_sample_index=selected_sample_index,
                            before=alarm_gif_before_frames,
                            after=alarm_gif_after_frames,
                        )
                        render_gif_frames = list(render_gif_plan.get("frames") or [])
                        render_gif_sample_indexes = [_frame_sample_index(frame, 0) for frame in render_gif_frames]
                        render_target_sample_indexes = sorted({selected_sample_index, *render_gif_sample_indexes})
                        logger.write(
                            f"开始按需内存渲染告警帧：{rule_db}，"
                            f"target_count={len(render_target_sample_indexes)}，"
                            f"selected={selected_sample_index}，gif_frames={render_gif_sample_indexes}"
                        )
                        render_filter = None if self.config.render_all_rules else {"summary/summary": None}
                        stage_started = time.monotonic()
                        rendered_images_by_sample_index = render_rule_images_memory(
                            memory_rule,
                            draw_region_labels=self.config.draw_region_labels,
                            render_filter=render_filter,
                            sample_indexes=render_target_sample_indexes,
                            parallel_render=self.config.parallel_render,
                            max_workers=self.config.render_workers,
                            log=logger.write,
                            progress=logger.progress,
                        )
                        video_stage_ms["rule_render_ms"] = _elapsed_ms(stage_started)
                        render_status = "success" if rendered_images_by_sample_index else "failed"
                        image_provider = getattr(memory_infer, "image_provider", None)
                        provider_stats = getattr(image_provider, "stats", lambda: {})()
                        logger.write(
                            f"{MEMORY_FIX_LOG_PREFIX}[RENDER_ON_DEMAND_READY] run_id={run_id} video_index={video_index} "
                            f"target_frame_count={len(render_target_sample_indexes)} "
                            f"rendered_frame_count={len(rendered_images_by_sample_index)} "
                            f"provider_stats={json.dumps(provider_stats, ensure_ascii=False, separators=(',', ':'))} "
                            f"{_memory_fix_snapshot_text()}"
                        )
                    else:
                        if not self.config.render_rule_images:
                            render_skip_reason = "render_rule_images_disabled"
                        elif not video_has_ng_for_render:
                            render_skip_reason = "normal_video_no_alarm"
                        logger.write(
                            f"{MEMORY_FIX_LOG_PREFIX}[RENDER_ON_DEMAND_SKIPPED] run_id={run_id} video_index={video_index} "
                            f"reason={render_skip_reason} has_ng={video_has_ng_for_render}"
                        )
                    self._write_video_trace_stage(
                        trace_context,
                        stage_order=950,
                        stage_key="rule_render",
                        stage_name="告警规则图按需渲染",
                        status=render_status,
                        duration_ms=_safe_int(video_stage_ms.get("rule_render_ms"), 0),
                        workload={
                            "frame_count": len(current_frames),
                            "render_target_frame_count": len(render_target_sample_indexes),
                            "rendered_frame_count": len(rendered_images_by_sample_index),
                            "gif_frame_count": len(render_gif_sample_indexes),
                        },
                        detail={
                            "render_rule_images": bool(self.config.render_rule_images),
                            "render_all_rules": bool(self.config.render_all_rules),
                            "draw_region_labels": bool(self.config.draw_region_labels),
                            "parallel_render": bool(self.config.parallel_render),
                            "render_workers": int(self.config.render_workers),
                            "render_scope": "alarm_protocol_frames_only",
                            "skip_reason": render_skip_reason,
                            "selected_sample_index": _frame_sample_index(render_selected_info, 0) if render_selected_info else None,
                            "matched_label": str(render_selected_info.get("matched_label") or "") if render_selected_info else "",
                            "render_target_sample_indexes": render_target_sample_indexes,
                            "gif_sample_indexes": render_gif_sample_indexes,
                            "provider_stats": provider_stats,
                        },
                    )
                else:
                    logger.write(f"开始执行规则：{infer_db}")
                    stage_started = time.monotonic()
                    rule_db = run_rules(infer_db, rule_names=None, log=logger.write, progress=logger.progress)
                    video_stage_ms["rule_execute_ms"] = _elapsed_ms(stage_started)
                    rule_dbs.append(rule_db)
                    logger.write(f"规则执行完成：{rule_db}")

                    current_render_dirs: List[Path] = []
                    if self.config.render_rule_images:
                        logger.write(f"开始渲染规则图像：{rule_db}")
                        render_filter = None if self.config.render_all_rules else {"summary/summary": None}
                        stage_started = time.monotonic()
                        current_render_dirs = render_cache_batch(
                            rule_db,
                            draw_region_labels=self.config.draw_region_labels,
                            render_filter=render_filter,
                            compose_video=False,
                            parallel_render=self.config.parallel_render,
                            max_workers=self.config.render_workers,
                            only_rule_dbs=True,
                            log=logger.write,
                            progress=logger.progress,
                        )
                        video_stage_ms["rule_render_ms"] = _elapsed_ms(stage_started)
                        render_dirs.extend(current_render_dirs)
                        logger.write("规则图像渲染完成：" + "；".join(str(path) for path in current_render_dirs))

                    stage_started = time.monotonic()
                    rule_result = read_rule_result(rule_db)
                    video_stage_ms["rule_result_read_ms"] = _elapsed_ms(stage_started)
                    per_db_results.append(rule_result)
                    self._write_video_trace_stage(
                        trace_context,
                        stage_order=500,
                        stage_key="rule_execute",
                        stage_name="规则执行",
                        duration_ms=_safe_int(video_stage_ms.get("rule_execute_ms"), 0),
                        workload={"frame_count": len(rule_result.get("frames", []) or [])},
                        detail={"rule_db": str(rule_db), "infer_db": str(infer_db)},
                    )
                    self._write_video_trace_stage(
                        trace_context,
                        stage_order=600,
                        stage_key="rule_render",
                        stage_name="规则图渲染",
                        status="success" if self.config.render_rule_images else "skipped",
                        duration_ms=_safe_int(video_stage_ms.get("rule_render_ms"), 0),
                        workload={"frame_count": len(rule_result.get("frames", []) or []), "rendered_dir_count": len(current_render_dirs)},
                    )
                    self._write_video_trace_stage(
                        trace_context,
                        stage_order=700,
                        stage_key="rule_result_read",
                        stage_name="规则结果读取",
                        duration_ms=_safe_int(video_stage_ms.get("rule_result_read_ms"), 0),
                        workload={"frame_count": len(rule_result.get("frames", []) or [])},
                    )
                    rendered_dir = current_render_dirs[0] if current_render_dirs else rule_db.parent / "rendered_rules"
                    current_frames: List[Dict[str, object]] = []
                    stage_started = time.monotonic()
                    for frame in rule_result.get("frames", []):
                        frame_item = dict(frame)
                        frame_item["rule_db"] = str(rule_db)
                        frame_item["infer_db"] = str(infer_db)
                        frame_item["video_index"] = int(video_index)
                        frame_item["raw_video_path"] = str(video_item.get("raw_video_path") or video_item.get("video_path") or "")
                        frame_item["local_video_path"] = str(video_item.get("local_video_path") or "")
                        frame_item["rendered_rule_image_path"] = str(rendered_dir / Path(str(frame_item.get("file_name") or "")).name)
                        current_frames.append(frame_item)
                        frames.append(frame_item)
                    video_stage_ms["frame_assembly_ms"] = _elapsed_ms(stage_started)
                    self._write_video_trace_stage(
                        trace_context,
                        stage_order=800,
                        stage_key="frame_assembly",
                        stage_name="帧结果组装",
                        duration_ms=_safe_int(video_stage_ms.get("frame_assembly_ms"), 0),
                        workload={"frame_count": len(current_frames)},
                    )
                    stage_started = time.monotonic()
                    saved_testoutputs = _save_testoutput_original_images(
                        frames=current_frames,
                        cache_dir=rule_db.parent,
                        enabled=bool(self.model_orchestration.get("save_testoutput_original_images")),
                        max_count=int(self.model_orchestration.get("max_testoutput_original_images_per_video") or 0),
                        label_prefix=str(self.model_orchestration.get("testoutput_label_prefix") or "testoutput-"),
                        logger=logger,
                    )
                    video_stage_ms["testoutput_save_ms"] = _elapsed_ms(stage_started)
                    self._write_video_trace_stage(
                        trace_context,
                        stage_order=900,
                        stage_key="testoutput_save",
                        stage_name="testoutput原图保存",
                        status="success" if saved_testoutputs.get("images") else "skipped",
                        duration_ms=_safe_int(video_stage_ms.get("testoutput_save_ms"), 0),
                        workload={
                            "enabled": bool(self.model_orchestration.get("save_testoutput_original_images")),
                            "max_count": int(self.model_orchestration.get("max_testoutput_original_images_per_video") or 0),
                            "saved_count": len(saved_testoutputs.get("images", []) or []),
                        },
                        detail={"output_dir": str(saved_testoutputs.get("dir") or ""), "saved_images": list(saved_testoutputs.get("images", []) or [])},
                    )
                if saved_testoutputs.get("dir"):
                    testoutput_original_dirs.append(str(saved_testoutputs.get("dir")))
                testoutput_original_images.extend([str(path) for path in saved_testoutputs.get("images", [])])

                video_has_ng = bool(rule_result.get("has_ng"))
                video_protocol_result = build_protocol_result(
                    video_input_info,
                    has_ng=video_has_ng,
                    frames=current_frames,
                    processing_time_ms=0,
                    server_ip=self.config.result_server_ip,
                )
                video_protocol_result["video_index"] = int(video_index)
                video_protocol_result["raw_video_path"] = str(video_item.get("raw_video_path") or video_item.get("video_path") or "")
                video_protocol_result["local_video_path"] = str(video_item.get("local_video_path") or "")
                video_protocol_result["infer_db"] = str(infer_db)
                video_protocol_result["rule_db"] = str(rule_db)
                if memory_mode:
                    stage_started = time.monotonic()
                    video_protocol_artifacts = _materialize_protocol_outputs_memory(
                        input_info=video_input_info,
                        frames=current_frames,
                        original_images_by_sample_index=original_images_by_sample_index,
                        rendered_images_by_sample_index=rendered_images_by_sample_index,
                        result_root=self.config.result_root,
                        protocol_result=video_protocol_result,
                        log_path=log_path,
                        json_path=json_path,
                        logger=logger,
                        priority_labels=alarm_priority_labels,
                        gif_before_frames=alarm_gif_before_frames,
                        gif_after_frames=alarm_gif_after_frames,
                    )
                    video_stage_ms["protocol_materialize_ms"] = _elapsed_ms(stage_started)
                    # [视频处理耗时复盘JSONL][NAS读取诊断01]
                    # 修改人: Shiver; 修改时间: 2026-06-24;
                    # 修改逻辑: 协议图片/GIF落盘可能通过 provider 再次读取源 AVI；落盘后读取 provider 统计并写入 metadata summary。
                    image_provider = getattr(memory_infer, "image_provider", None)
                    provider_stats_after_protocol = getattr(image_provider, "stats", lambda: {})()
                    provider_source_io_after_protocol: Dict[str, object] = {}
                    if isinstance(provider_stats_after_protocol, dict):
                        candidate_source_io = provider_stats_after_protocol.get("source_video_io")
                        if isinstance(candidate_source_io, dict):
                            provider_source_io_after_protocol = candidate_source_io
                            memory_infer.metadata["provider_source_video_io"] = dict(candidate_source_io)
                    protocol_trace_stages = video_protocol_artifacts.get("protocol_trace_stages", []) if isinstance(video_protocol_artifacts, dict) else []
                    for trace_stage in protocol_trace_stages:
                        if not isinstance(trace_stage, dict):
                            continue
                        self._write_video_trace_stage(
                            trace_context,
                            stage_order=_safe_int(trace_stage.get("stage_order"), 0),
                            stage_key=str(trace_stage.get("stage_key") or ""),
                            stage_name=str(trace_stage.get("stage_name") or ""),
                            status=str(trace_stage.get("status") or "success"),
                            duration_ms=_safe_int(trace_stage.get("duration_ms"), 0),
                            started_at=str(trace_stage.get("started_at") or ""),
                            ended_at=str(trace_stage.get("ended_at") or ""),
                            workload=trace_stage.get("workload") if isinstance(trace_stage.get("workload"), dict) else {},
                            detail=trace_stage.get("detail") if isinstance(trace_stage.get("detail"), dict) else {},
                            error_message=str(trace_stage.get("error_message") or ""),
                        )
                    if provider_source_io_after_protocol:
                        # [视频处理耗时复盘JSONL][NAS读取诊断01]
                        # 修改人: Shiver; 修改时间: 2026-06-24;
                        # 修改逻辑: 增加诊断型阶段承载 provider 二次读取源AVI的统计；duration_ms=0，避免重复计入真实墙钟耗时。
                        provider_read_call_count = _safe_int(provider_source_io_after_protocol.get("video_read_call_count"), 0)
                        provider_read_decode_ms = _safe_float(provider_source_io_after_protocol.get("video_read_decode_ms_sum"), 0.0)
                        self._write_video_trace_stage(
                            trace_context,
                            stage_order=1060,
                            stage_key="source_video_provider_read",
                            stage_name="源视频按需取原图读取与解码",
                            status="success" if provider_read_call_count > 0 else "skipped",
                            duration_ms=0,
                            workload={
                                "source_video_read_call_count": provider_read_call_count,
                                "source_video_read_frame_count": _safe_int(provider_source_io_after_protocol.get("video_read_frame_count"), 0),
                                "source_video_yield_frame_count": _safe_int(provider_source_io_after_protocol.get("video_yield_frame_count"), 0),
                                "cache_hit_count": _safe_int(provider_stats_after_protocol.get("cache_hit_count"), 0) if isinstance(provider_stats_after_protocol, dict) else 0,
                                "cache_miss_count": _safe_int(provider_stats_after_protocol.get("cache_miss_count"), 0) if isinstance(provider_stats_after_protocol, dict) else 0,
                                "reader_resets": _safe_int(provider_stats_after_protocol.get("reader_resets"), 0) if isinstance(provider_stats_after_protocol, dict) else 0,
                            },
                            timing_detail_ms={
                                "source_is_probable_nas": bool(provider_source_io_after_protocol.get("source_is_probable_nas")),
                                "source_mount_type": str(provider_source_io_after_protocol.get("source_mount_type") or ""),
                                "source_mount_point": str(provider_source_io_after_protocol.get("source_mount_point") or ""),
                                "source_mount_source": str(provider_source_io_after_protocol.get("source_mount_source") or ""),
                                "source_video_safe_path_ms": provider_source_io_after_protocol.get("video_safe_path_ms", 0),
                                "source_video_open_count": provider_source_io_after_protocol.get("video_open_count", 0),
                                "source_video_open_ms": provider_source_io_after_protocol.get("video_open_ms_sum", 0),
                                "source_video_open_max_ms": provider_source_io_after_protocol.get("video_open_ms_max", 0),
                                "source_video_metadata_ms": provider_source_io_after_protocol.get("video_metadata_ms_sum", 0),
                                "source_video_seek_ms": provider_source_io_after_protocol.get("video_seek_ms_sum", 0),
                                "source_video_read_call_count": provider_read_call_count,
                                "source_video_read_frame_count": provider_source_io_after_protocol.get("video_read_frame_count", 0),
                                "source_video_yield_frame_count": provider_source_io_after_protocol.get("video_yield_frame_count", 0),
                                "source_video_read_decode_ms": round(provider_read_decode_ms, 3),
                                "source_video_read_decode_avg_ms": provider_source_io_after_protocol.get("video_read_decode_ms_avg", 0),
                                "source_video_read_decode_max_ms": provider_source_io_after_protocol.get("video_read_decode_ms_max", 0),
                                "source_video_first_frame_read_ms": provider_source_io_after_protocol.get("video_first_frame_read_ms", 0),
                            },
                            detail={
                                "diagnostic_stage": True,
                                "duration_ms_note": "duration_ms固定为0；source_video_read_decode_ms是provider二次读取源AVI的累计子耗时，已包含在rule_render/protocol_materialize真实墙钟耗时内。",
                            },
                        )
                else:
                    stage_started = time.monotonic()
                    video_protocol_artifacts = _materialize_protocol_outputs(
                        input_info=video_input_info,
                        frames=current_frames,
                        result_root=self.config.result_root,
                        protocol_result=video_protocol_result,
                        log_path=log_path,
                        json_path=json_path,
                        logger=logger,
                        priority_labels=alarm_priority_labels,
                        gif_before_frames=alarm_gif_before_frames,
                        gif_after_frames=alarm_gif_after_frames,
                    )
                    video_stage_ms["protocol_materialize_ms"] = _elapsed_ms(stage_started)
                    self._write_video_trace_stage(
                        trace_context,
                        stage_order=990,
                        stage_key="protocol_materialize",
                        stage_name="协议产物落盘",
                        duration_ms=_safe_int(video_stage_ms.get("protocol_materialize_ms"), 0),
                        workload={"frame_count": len(current_frames)},
                        detail={"storage_mode": "disk"},
                    )
                if memory_mode:
                    # [1.内存模型预加载整段视频全部帧][生产迭代02-有界流式]
                    # 修改人: Shiver; 修改时间: 2026-06-22;
                    # 修改逻辑: 协议图片/GIF已落盘后，整段规则渲染图不再被后续逻辑使用；
                    # 立即断开两处字典引用，避免最后一个视频的全量渲染数组保留到任务返回。
                    stage_started = time.monotonic()
                    released_rendered_frame_count = len(rendered_images_by_sample_index)
                    rendered_images_by_sample_index.clear()
                    memory_rule.rendered_images = {}
                    video_stage_ms["video_release_ms"] = _elapsed_ms(stage_started)
                    logger.write(
                        f"{MEMORY_FIX_LOG_PREFIX}[VIDEO_RELEASE] run_id={run_id} video_index={video_index} "
                        f"released_rendered_frames=true rendered_frame_count={released_rendered_frame_count} {_memory_fix_snapshot_text()}"
                    )
                    self._write_video_trace_stage(
                        trace_context,
                        stage_order=1200,
                        stage_key="video_release",
                        stage_name="单视频内存释放",
                        duration_ms=_safe_int(video_stage_ms.get("video_release_ms"), 0),
                        workload={"rendered_frame_count": released_rendered_frame_count},
                        detail={"released_rendered_frames": True},
                    )
                video_stage_ms["post_infer_total_ms"] = int((time.monotonic() - video_service_started) * 1000)
                video_stage_ms["video_total_ms"] = int(infer_elapsed_ms + video_stage_ms["post_infer_total_ms"] if infer_elapsed_ms > 0 else video_stage_ms["post_infer_total_ms"])
                video_protocol_result["processing_time"] = int(video_stage_ms["video_total_ms"])
                video_protocol_result["video_processing_time_ms"] = int(video_stage_ms["video_total_ms"])
                video_protocol_result["infer_elapsed_ms"] = int(infer_elapsed_ms)
                video_protocol_result["post_infer_elapsed_ms"] = int(video_stage_ms["post_infer_total_ms"])
                video_protocol_artifacts["video_processing_time_ms"] = int(video_stage_ms["video_total_ms"])
                video_protocol_artifacts["infer_elapsed_ms"] = int(infer_elapsed_ms)
                video_protocol_artifacts["post_infer_elapsed_ms"] = int(video_stage_ms["post_infer_total_ms"])
                protocol_results.append(video_protocol_result)
                protocol_artifacts_by_video.append(
                    _protocol_artifact_summary(
                        video_index=video_index,
                        video_item=video_item,
                        infer_db=Path(str(infer_db)),
                        rule_db=Path(str(rule_db)),
                        protocol_result=video_protocol_result,
                        protocol_artifacts=video_protocol_artifacts,
                    )
                )
                timing_line = (
                    f"视频完成：run_id={run_id}，task_id={request_id}，"
                    f"video_index={video_index}，path={video_path_for_log}，"
                    f"status=success，{_format_timing_fields(video_stage_ms, VIDEO_TIMING_STAGES)}"
                )
                logger.write(timing_line)
                _append_video_timing_log(self.config.rolling_log_dir, self.config.instance_id, timing_line)
                self._timing_stats.record_video(video_stage_ms)
                self._mark_video_completed_for_stats(input_info, 1)
                video_metadata_for_special = memory_infer_results[video_index].metadata if memory_mode and video_index < len(memory_infer_results) else {}
                self._write_special_video_completed(
                    run_id=run_id,
                    request_id=request_id,
                    video_index=video_index,
                    video_input_info=video_input_info,
                    metadata=video_metadata_for_special if isinstance(video_metadata_for_special, dict) else {},
                    protocol_result=video_protocol_result,
                    video_stage_ms=dict(video_stage_ms),
                )
                video_trace_summaries.append(
                    {
                        "context": trace_context,
                        "video_input_info": video_input_info,
                        "metadata": video_metadata_for_special if isinstance(video_metadata_for_special, dict) else {},
                        "rule_result": rule_result,
                        "video_stage_ms": dict(video_stage_ms),
                        "protocol_result": video_protocol_result,
                        "protocol_artifacts": dict(video_protocol_artifacts),
                    }
                )

            task_stage_ms["video_post_total_ms"] = _elapsed_ms(video_post_started)
            merge_started = time.monotonic()
            original_frame_dirs = []
            if not memory_mode:
                for infer_db in infer_dbs:
                    frames_dir = Path(infer_db).parent / "frames"
                    if frames_dir.exists():
                        original_frame_dirs.append(frames_dir)

            merged_summary = merge_rule_results(per_db_results)
            has_ng = any(bool(item.get("has_ng")) for item in per_db_results)
            artifacts = {
                "intermediate_storage_mode": "memory" if memory_mode else "disk",
                "original_frame_dirs": [str(path) for path in original_frame_dirs],
                "rule_render_dirs": [str(path) for path in render_dirs],
                "infer_dbs": [str(path) for path in infer_dbs],
                "rule_dbs": [str(path) for path in rule_dbs],
                "testoutput_original_dirs": testoutput_original_dirs,
                "testoutput_original_images": testoutput_original_images,
                "alarm_representative_frame": {},
                "alarm_gif_path": "",
                "alarm_video_path": "",
                "alarm_video_written": False,
                "protocol_artifacts_by_video": protocol_artifacts_by_video,
            }
            processing_time_ms = int((time.monotonic() - started) * 1000)
            protocol_result, compatible_artifact = _select_compatible_protocol_result(protocol_results, protocol_artifacts_by_video)
            if protocol_result:
                protocol_result["request_processing_time"] = int(processing_time_ms)
            artifacts["alarm_representative_frame"] = {
                "video_index": compatible_artifact.get("video_index", protocol_result.get("video_index", 0) if protocol_result else 0),
                "raw_video_path": compatible_artifact.get("raw_video_path", ""),
                "sample_index": compatible_artifact.get("sample_index", 0),
                "matched_label": compatible_artifact.get("matched_label", ""),
                "priority_rank": compatible_artifact.get("priority_rank", -1),
                "image_path": compatible_artifact.get("image_path", ""),
                "rendered_rule_image_path": compatible_artifact.get("rendered_rule_image_path", ""),
            }
            artifacts["alarm_gif_path"] = compatible_artifact.get("gif_path", "")
            artifacts["alarm_rendered_gif_path"] = compatible_artifact.get("rendered_gif_path", "")
            artifacts["alarm_original_gif_path"] = compatible_artifact.get("original_gif_path", "")
            artifacts["alarm_video_path"] = compatible_artifact.get("alarm_video_path", "")
            artifacts["alarm_video_written"] = bool(compatible_artifact.get("alarm_video_written"))
            artifacts["alarm_gif_frame_selection"] = {
                "video_index": compatible_artifact.get("video_index", protocol_result.get("video_index", 0) if protocol_result else 0),
                "mode": compatible_artifact.get("gif_selection_mode", ""),
                "ng_center_sample_indexes": compatible_artifact.get("gif_ng_center_sample_indexes", []),
                "segments": compatible_artifact.get("gif_segments", []),
                "frame_count": compatible_artifact.get("gif_frame_count", 0),
            }
            result.update(
                {
                    "status": "success",
                    "overall_result": "NG" if has_ng else "OK",
                    "has_ng": has_ng,
                    "ng_labels": ["综合结果-NG"] if has_ng else [],
                    "rule_dbs": [str(path) for path in rule_dbs],
                    "per_db_results": per_db_results,
                    "frames": frames,
                    "summary": merged_summary,
                    "artifacts": artifacts,
                    "processing_time": processing_time_ms,
                    "protocol_result": protocol_result,
                    "protocol_results": protocol_results,
                }
            )
            task_stage_ms["merge_summary_ms"] = _elapsed_ms(merge_started)

            alarm_callback_url = str(payload.get("alarm_callback_url") or self.config.callback_url or "").strip()
            # ===== 客户现场协议适配点：是否触发告警回调 =====
            # callback_url 已改为任务完成批量回调；alarm_callback_url 只用于真正告警。
            # 单次请求包含多个视频时，每个 status=alarm 的视频都单独上报一次；
            # 告警代表帧优先级只在单个视频内部选择错误结果时生效。
            alarm_protocol_results = [
                item for item in protocol_results
                if isinstance(item, dict) and str(item.get("status") or "") == "alarm"
            ]
            alarm_callback_statuses: List[Dict[str, object]] = []
            video_trace_callback_by_index: Dict[int, Dict[str, object]] = {}
            alarm_callback_started = time.monotonic()
            if alarm_callback_url and alarm_protocol_results:
                for alarm_index, alarm_protocol_result in enumerate(alarm_protocol_results, start=1):
                    current_video_index = _safe_int(alarm_protocol_result.get("video_index"), 0)
                    video_item = video_items[current_video_index] if 0 <= current_video_index < len(video_items) else {}
                    video_input_info = _single_video_input_info(input_info, video_item, current_video_index)
                    trace_context = self._video_trace_context(
                        run_id=run_id,
                        request_id=request_id,
                        input_info=input_info,
                        video_input_info=video_input_info,
                        video_item=video_item,
                        video_index=current_video_index,
                    )
                    callback_payload = build_protocol_payload({"protocol_result": alarm_protocol_result})
                    logger.write(
                        f"开始告警回调外部 HTTP：{alarm_callback_url}，"
                        f"第 {alarm_index}/{len(alarm_protocol_results)} 条，"
                        f"video_index={alarm_protocol_result.get('video_index', '')}"
                    )
                    self._special_log.write(
                        "回调情况",
                        (
                            f"告警回调开始，实例={self.config.instance_id}，任务ID={run_id}，请求ID={request_id}，"
                            f"第{alarm_index}/{len(alarm_protocol_results)}条，视频序号={alarm_protocol_result.get('video_index', '')}，"
                            f"回调地址={alarm_callback_url}"
                        ),
                    )
                    current_callback_started = time.monotonic()
                    current_callback_started_at = _now()
                    current_callback_status = post_json(alarm_callback_url, callback_payload, timeout_sec=self.config.callback_timeout_sec)
                    current_callback_duration_ms = _elapsed_ms(current_callback_started)
                    current_callback_status["duration_ms"] = current_callback_duration_ms
                    alarm_callback_statuses.append(current_callback_status)
                    video_trace_callback_by_index[current_video_index] = dict(current_callback_status)
                    self._write_video_trace_stage(
                        trace_context,
                        stage_order=1100,
                        stage_key="alarm_callback",
                        stage_name="告警回调",
                        status="success" if not str(current_callback_status.get("error") or "") else "failed",
                        started_at=current_callback_started_at,
                        ended_at=_now(),
                        duration_ms=current_callback_duration_ms,
                        workload={"attempted": True},
                        detail={
                            "url": alarm_callback_url,
                            "status_code": current_callback_status.get("status_code"),
                            "error": str(current_callback_status.get("error") or ""),
                            "response_text_preview": str(current_callback_status.get("response_text") or "")[:500],
                        },
                    )
                    logger.write(f"告警回调结果：{json.dumps(current_callback_status, ensure_ascii=False)}")
                    callback_error = str(current_callback_status.get("error") or "")
                    callback_code = current_callback_status.get("status_code")
                    callback_success = not callback_error and 200 <= _safe_int(callback_code, 0) < 300
                    self._special_log.write(
                        "回调情况",
                        (
                            f"告警回调完成，实例={self.config.instance_id}，任务ID={run_id}，请求ID={request_id}，"
                            f"第{alarm_index}/{len(alarm_protocol_results)}条，视频序号={alarm_protocol_result.get('video_index', '')}，"
                            f"状态码={callback_code}，耗时={_format_duration_cn_ms(current_callback_duration_ms)}，"
                            f"结果={'成功' if callback_success else '失败'}，错误={callback_error}"
                        ),
                    )
                callback_status = alarm_callback_statuses[-1]
                result["callback"] = callback_status
                result["alarm_callback"] = callback_status
                result["alarm_callbacks"] = alarm_callback_statuses
            elif not alarm_callback_url:
                result["callback"] = {**callback_status, "attempted": False, "error": "未配置 alarm_callback_url"}
                result["alarm_callback"] = result["callback"]
                result["alarm_callbacks"] = []
                logger.write("未配置 alarm_callback_url，跳过告警回调。")
                self._special_log.write("回调情况", f"告警回调跳过，实例={self.config.instance_id}，任务ID={run_id}，请求ID={request_id}，原因=未配置告警回调地址")
            else:
                result["callback"] = {**callback_status, "attempted": False, "error": "无 status=alarm 的视频，跳过告警回调"}
                result["alarm_callback"] = result["callback"]
                result["alarm_callbacks"] = []
                logger.write("本次请求没有 status=alarm 的视频，跳过告警回调。")
                self._special_log.write("回调情况", f"告警回调跳过，实例={self.config.instance_id}，任务ID={run_id}，请求ID={request_id}，原因=没有告警视频")
            task_stage_ms["alarm_callback_ms"] = _elapsed_ms(alarm_callback_started)
            for summary_item in video_trace_summaries:
                context = summary_item.get("context") if isinstance(summary_item.get("context"), dict) else {}
                try:
                    summary_video_index = int(context.get("video_index", 0) or 0)
                except Exception:
                    summary_video_index = 0
                callback_for_video = video_trace_callback_by_index.get(summary_video_index, {"attempted": False, "duration_ms": 0})
                self._write_video_trace_summary(
                    context,
                    video_input_info=summary_item.get("video_input_info") if isinstance(summary_item.get("video_input_info"), dict) else {},
                    metadata=summary_item.get("metadata") if isinstance(summary_item.get("metadata"), dict) else {},
                    rule_result=summary_item.get("rule_result") if isinstance(summary_item.get("rule_result"), dict) else {},
                    video_stage_ms=summary_item.get("video_stage_ms") if isinstance(summary_item.get("video_stage_ms"), dict) else {},
                    protocol_result=summary_item.get("protocol_result") if isinstance(summary_item.get("protocol_result"), dict) else {},
                    protocol_artifacts=summary_item.get("protocol_artifacts") if isinstance(summary_item.get("protocol_artifacts"), dict) else {},
                    callback_status=callback_for_video,
                    log_path=log_path,
                    json_path=json_path,
                )
            task_status_text = "success"
            task_overall_text = "NG" if has_ng else "OK"
            task_video_count = len(protocol_results)
        except Exception as exc:
            err = traceback.format_exc()
            logger.write(err)
            processing_time_ms = int((time.monotonic() - started) * 1000)
            task_status_text = "failed"
            task_overall_text = str(result.get("overall_result") or "UNKNOWN")
            task_error_text = str(exc)
            protocol_result = build_internal_error_result(
                input_info,
                message=str(exc),
                server_ip=self.config.result_server_ip,
            )
            result.update(
                {
                    "status": "failed",
                    "error": str(exc),
                    "traceback": err,
                    "processing_time": processing_time_ms,
                    "protocol_result": protocol_result,
                }
            )
            alarm_callback_url = str(payload.get("alarm_callback_url") or self.config.callback_url or "").strip()
            alarm_callback_started = time.monotonic()
            if alarm_callback_url and str(protocol_result.get("status") or "") == "alarm":
                self._special_log.write(
                    "回调情况",
                    f"异常告警回调开始，实例={self.config.instance_id}，任务ID={run_id}，请求ID={request_id}，回调地址={alarm_callback_url}",
                )
                exception_callback_started = time.monotonic()
                callback_status = post_json(alarm_callback_url, build_protocol_payload(result), timeout_sec=self.config.callback_timeout_sec)
                result["callback"] = callback_status
                result["alarm_callback"] = callback_status
                result["alarm_callbacks"] = [callback_status]
                logger.write(f"异常告警回调结果：{json.dumps(callback_status, ensure_ascii=False)}")
                exception_callback_ms = _elapsed_ms(exception_callback_started)
                exception_callback_error = str(callback_status.get("error") or "")
                exception_callback_code = callback_status.get("status_code")
                exception_callback_success = not exception_callback_error and 200 <= _safe_int(exception_callback_code, 0) < 300
                self._special_log.write(
                    "回调情况",
                    (
                        f"异常告警回调完成，实例={self.config.instance_id}，任务ID={run_id}，请求ID={request_id}，"
                        f"状态码={exception_callback_code}，耗时={_format_duration_cn_ms(exception_callback_ms)}，"
                        f"结果={'成功' if exception_callback_success else '失败'}，错误={exception_callback_error}"
                    ),
                )
            elif alarm_callback_url:
                result["callback"] = {**callback_status, "attempted": False, "error": "异常结果不是 alarm，跳过告警回调"}
                result["alarm_callback"] = result["callback"]
                result["alarm_callbacks"] = []
                logger.write("异常结果不是 alarm，跳过告警回调。")
                self._special_log.write("回调情况", f"异常告警回调跳过，实例={self.config.instance_id}，任务ID={run_id}，请求ID={request_id}，原因=异常结果不是告警")
            task_stage_ms["alarm_callback_ms"] = _elapsed_ms(alarm_callback_started)
        finally:
            # [1.内存模型预加载整段视频全部帧][生产迭代02-有界流式]
            # 修改人: Shiver; 修改时间: 2026-06-22;
            # 修改逻辑: 释放惰性读取器中的VideoCapture与LRU原图，避免任务间文件句柄/帧缓存累积。
            cleanup_started = time.monotonic()
            closed_provider_count = 0
            for provider_video_index, memory_result in enumerate(memory_infer_results):
                provider = getattr(memory_result, "image_provider", None)
                closer = getattr(provider, "close", None)
                if callable(closer):
                    provider_stage_started = time.monotonic()
                    provider_stage_started_at = _now()
                    provider_stats_before = getattr(provider, "stats", lambda: {})()
                    try:
                        closer()
                        closed_provider_count += 1
                        video_items_for_trace = [item for item in input_info.get("video_items", []) if isinstance(item, dict)]
                        video_item = video_items_for_trace[provider_video_index] if provider_video_index < len(video_items_for_trace) else {}
                        video_input_info = _single_video_input_info(input_info, video_item, provider_video_index)
                        trace_context = self._video_trace_context(
                            run_id=run_id,
                            request_id=request_id,
                            input_info=input_info,
                            video_input_info=video_input_info,
                            video_item=video_item,
                            video_index=provider_video_index,
                        )
                        self._write_video_trace_stage(
                            trace_context,
                            stage_order=1210,
                            stage_key="provider_close",
                            stage_name="视频provider关闭",
                            started_at=provider_stage_started_at,
                            ended_at=_now(),
                            duration_ms=_elapsed_ms(provider_stage_started),
                            workload={"closed_provider_count": 1},
                            detail={"provider_stats_before_close": provider_stats_before},
                        )
                    except Exception as close_exc:
                        logger.write(
                            f"{MEMORY_FIX_LOG_PREFIX}[PROVIDER_CLOSE_ERROR] run_id={run_id} error={close_exc}"
                        )
            logger.write(
                f"{MEMORY_FIX_LOG_PREFIX}[PROVIDER_CLOSE] run_id={run_id} "
                f"closed_provider_count={closed_provider_count} {_memory_fix_snapshot_text()}"
            )
            task_stage_ms["cleanup_ms"] = _elapsed_ms(cleanup_started)
            # [1.内存模型预加载整段视频全部帧][生产迭代01-日志]
            # 修改人: Shiver; 修改时间: 2026-06-22;
            # 修改逻辑: 无论成功或失败都输出任务结束快照，用于判断任务间基线是否持续抬升。
            logger.write(
                f"{MEMORY_FIX_LOG_PREFIX}[TASK_END] run_id={run_id} "
                f"status={result.get('status') or 'unknown'} "
                f"elapsed_ms={int((time.monotonic() - started) * 1000)} {_memory_fix_snapshot_text()}"
            )
            result["processing_time"] = _elapsed_ms(started)
            json_write_started = time.monotonic()
            json_path.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
            task_stage_ms["json_write_ms"] = _elapsed_ms(json_write_started)
            task_stage_ms["task_total_ms"] = _elapsed_ms(started)
            result["processing_time"] = int(task_stage_ms["task_total_ms"])
            task_status_text = str(result.get("status") or task_status_text or "unknown")
            task_overall_text = str(result.get("overall_result") or task_overall_text or "UNKNOWN")
            if not task_error_text:
                task_error_text = str(result.get("error") or "")
            if not task_video_count:
                protocol_results_value = result.get("protocol_results")
                if isinstance(protocol_results_value, list):
                    task_video_count = len(protocol_results_value)
            task_line_parts = [
                f"任务完成：run_id={run_id}",
                f"task_id={request_id}",
                f"status={task_status_text}",
                f"overall_result={task_overall_text}",
                f"video_count={task_video_count}",
            ]
            if task_error_text:
                task_line_parts.append(f"error={task_error_text}")
            task_line_parts.append(_format_timing_fields(task_stage_ms, TASK_TIMING_STAGES))
            task_timing_line = "，".join(task_line_parts)
            logger.write(task_timing_line)
            _append_task_timing_log(self.config.rolling_log_dir, self.config.instance_id, task_timing_line)
            self._timing_stats.record_task(task_stage_ms)
            self._write_special_task_completed(
                run_id=run_id,
                request_id=request_id,
                status=task_status_text,
                overall_result=task_overall_text,
                task_video_count=task_video_count,
                protocol_results=protocol_results,
                task_stage_ms=task_stage_ms,
                error_text=task_error_text,
            )
            self._write_special_summary_log()
            logger.write(f"结果 JSON：{json_path}")
        return result

    def _parse_input(self, payload: Dict[str, object]) -> Dict[str, object]:
        # ===== 客户现场协议适配点：入参字段映射到内部推理参数 =====
        # 仅支持 protocol/协议文档.txt 中的 video_paths[].avi_path + NAS 配置。
        # NAS 环境不可用时可通过挂载路径或后续启用 SMB 下载解决。
        if not is_customer_protocol(payload):
            print("RuntimeError(", f"请求体必须使用协议格式，并包含 video_paths 列表。", ")")
            raise RuntimeError("请求体必须使用协议格式，并包含 video_paths 列表。")
        input_info = parse_protocol_input(payload)
        apply_video_filter(input_info)
        # 抽帧参数只允许通过环境变量配置，避免请求体覆盖服务端部署参数。
        input_info["target_fps"] = self.config.target_fps
        input_info["start_sec"] = self.config.start_sec
        input_info["end_sec"] = self.config.end_sec
        for item in input_info.get("video_items", []):
            item_info = dict(input_info)
            item_info.update(
                {
                    "raw_video_path": item.get("raw_video_path"),
                    "video_path": item.get("video_path"),
                    "local_video_path": item.get("local_video_path"),
                    "wafer_info": item.get("wafer_info", {}),
                }
            )
            local_path = resolve_input_video(item_info, self.config.output_root / "nas_staging")
            item["local_video_path"] = str(local_path)
        first_item = (input_info.get("video_items") or [{}])[0]
        input_info["local_video_path"] = str(first_item.get("local_video_path", ""))
        return input_info

    def _unique_run_id(self, base_run_id: str) -> str:
        base = _safe_run_id(base_run_id)
        candidate = base
        index = 2
        while (_daily_log_dir(self.config.log_dir) / f"{candidate}.json").exists() or (self.config.log_dir / f"{candidate}.json").exists():
            candidate = f"{base}_{index}"
            index += 1
        return candidate


__all__ = ["InferCacheService"]
