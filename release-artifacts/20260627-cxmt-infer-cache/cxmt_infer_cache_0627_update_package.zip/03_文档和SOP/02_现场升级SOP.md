# 0627 现场升级 SOP

修改人：Shiver  
修改时间：2026-06-27  
适用对象：Linux 服务运维小白，按步骤复制执行即可。

## 0. 默认路径假设

现场工程目录假设为：

```bash
/home/app.e05114/aqtmp/infer_cache
```

如果现场实际路径不同，后续命令中的路径按实际目录替换。

进入工程目录：

```bash
cd /home/app.e05114/aqtmp/infer_cache
```

确认容器状态：

```bash
docker compose -f docker-compose-prod.yml ps
```

确认当前代码状态：

```bash
git branch
git log --oneline -5
git status --short
```

## 1. 上传更新包

把 `0627更新包` 上传到现场服务器，例如：

```text
/home/app.e05114/aqtmp/0627更新包
```

确认更新包存在：

```bash
ls -lh /home/app.e05114/aqtmp/0627更新包
find /home/app.e05114/aqtmp/0627更新包/01_更新后文件_直接覆盖现场 -type f
```

## 2. 备份现场原文件

必须先备份现场原文件，不要直接依赖更新包里的回退参考。

```bash
cd /home/app.e05114/aqtmp/infer_cache

backup_dir="backup_0627_$(date +%Y%m%d_%H%M%S)"
mkdir -p "$backup_dir/infer_cache/code_infer_cache/rules"
mkdir -p "$backup_dir/infer_cache/tools"

cp -a infer_cache/code_infer_cache/infer_cache_core.py "$backup_dir/infer_cache/code_infer_cache/infer_cache_core.py"
cp -a infer_cache/code_infer_cache/rules/cxmt_rule_1_motion_analysis.py "$backup_dir/infer_cache/code_infer_cache/rules/cxmt_rule_1_motion_analysis.py"
cp -a infer_cache/model_orchestration_config.py "$backup_dir/infer_cache/model_orchestration_config.py"
cp -a infer_cache/service.py "$backup_dir/infer_cache/service.py"
cp -a infer_cache/tools/aggregate_video_trace.py "$backup_dir/infer_cache/tools/aggregate_video_trace.py"

echo "backup_dir=$backup_dir"
find "$backup_dir" -type f -maxdepth 5
```

## 3. 覆盖更新文件

如果更新包路径为 `/home/app.e05114/aqtmp/0627更新包`：

```bash
cd /home/app.e05114/aqtmp/infer_cache

cp -a /home/app.e05114/aqtmp/0627更新包/01_更新后文件_直接覆盖现场/* ./
```

确认文件时间已更新：

```bash
ls -lh \
  infer_cache/code_infer_cache/infer_cache_core.py \
  infer_cache/code_infer_cache/rules/cxmt_rule_1_motion_analysis.py \
  infer_cache/model_orchestration_config.py \
  infer_cache/service.py \
  infer_cache/tools/aggregate_video_trace.py
```

## 4. 语法检查

优先用现场服务同一个 Python 环境执行。若现场一直使用 `python3`，则执行：

```bash
cd /home/app.e05114/aqtmp/infer_cache

python3 -m py_compile \
  infer_cache/code_infer_cache/infer_cache_core.py \
  infer_cache/code_infer_cache/rules/cxmt_rule_1_motion_analysis.py \
  infer_cache/model_orchestration_config.py \
  infer_cache/service.py \
  infer_cache/tools/aggregate_video_trace.py
```

没有输出报错即通过。

## 5. 确认/设置关键环境变量

先看当前配置：

```bash
grep -n "STAGE1_SPARSE\\|STAGE2_SPARSE\\|SPECIAL_LOG_INTERVAL" docker-compose-prod.yml
```

建议第一轮测试配置：

```yaml
INFER_CACHE_STAGE1_SPARSE_ENABLED: ${INFER_CACHE_STAGE1_SPARSE_ENABLED:-true}
INFER_CACHE_STAGE1_SPARSE_STRIDE: ${INFER_CACHE_STAGE1_SPARSE_STRIDE:-3}
INFER_CACHE_STAGE1_SPARSE_DROPLET_REFINE_RADIUS: ${INFER_CACHE_STAGE1_SPARSE_DROPLET_REFINE_RADIUS:-6}
INFER_CACHE_STAGE1_SPARSE_LEAK_REFINE_RADIUS: ${INFER_CACHE_STAGE1_SPARSE_LEAK_REFINE_RADIUS:-3}
INFER_CACHE_STAGE1_SPARSE_SPREAD_REFINE_RADIUS: ${INFER_CACHE_STAGE1_SPARSE_SPREAD_REFINE_RADIUS:-12}
INFER_CACHE_STAGE1_SPARSE_FALLBACK_REFINE_RATIO: ${INFER_CACHE_STAGE1_SPARSE_FALLBACK_REFINE_RATIO:-0.60}
INFER_CACHE_STAGE2_SPARSE_INDEX_MODE: ${INFER_CACHE_STAGE2_SPARSE_INDEX_MODE:-global_frame_mod}
INFER_CACHE_SPECIAL_LOG_INTERVAL_SEC: ${INFER_CACHE_SPECIAL_LOG_INTERVAL_SEC:-300}
```

如果不想开启 1# 稀疏，只验证专项日志/硬件汇总：

```yaml
INFER_CACHE_STAGE1_SPARSE_ENABLED: ${INFER_CACHE_STAGE1_SPARSE_ENABLED:-false}
```

## 6. 重启服务

```bash
cd /home/app.e05114/aqtmp/infer_cache

docker compose -f docker-compose-prod.yml down
docker compose -f docker-compose-prod.yml up -d
```

查看容器：

```bash
docker compose -f docker-compose-prod.yml ps
```

## 7. 启动后快速检查

看服务启动专项日志：

```bash
docker compose -f docker-compose-prod.yml logs --tail=300 | grep "专项日志-服务启动"
```

看健康状态：

```bash
docker compose -f docker-compose-prod.yml logs --since 10m | grep "专项日志-健康状态"
```

看是否有异常：

```bash
docker compose -f docker-compose-prod.yml logs --tail=300 | grep -iE "error|exception|traceback|failed|失败"
```

## 8. 回退方式

如果更新后服务异常，使用第 2 步生成的现场备份目录回退。

假设备份目录为：

```bash
backup_0627_YYYYMMDD_HHMMSS
```

执行：

```bash
cd /home/app.e05114/aqtmp/infer_cache

cp -a backup_0627_YYYYMMDD_HHMMSS/infer_cache/code_infer_cache/infer_cache_core.py infer_cache/code_infer_cache/infer_cache_core.py
cp -a backup_0627_YYYYMMDD_HHMMSS/infer_cache/code_infer_cache/rules/cxmt_rule_1_motion_analysis.py infer_cache/code_infer_cache/rules/cxmt_rule_1_motion_analysis.py
cp -a backup_0627_YYYYMMDD_HHMMSS/infer_cache/model_orchestration_config.py infer_cache/model_orchestration_config.py
cp -a backup_0627_YYYYMMDD_HHMMSS/infer_cache/service.py infer_cache/service.py
cp -a backup_0627_YYYYMMDD_HHMMSS/infer_cache/tools/aggregate_video_trace.py infer_cache/tools/aggregate_video_trace.py

docker compose -f docker-compose-prod.yml down
docker compose -f docker-compose-prod.yml up -d
```

回退后检查：

```bash
docker compose -f docker-compose-prod.yml ps
docker compose -f docker-compose-prod.yml logs --tail=200
```
