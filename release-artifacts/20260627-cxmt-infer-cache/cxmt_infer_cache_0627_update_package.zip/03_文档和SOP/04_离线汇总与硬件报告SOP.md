# 0627 离线汇总与硬件报告 SOP

修改人：Shiver  
修改时间：2026-06-27

## 1. 脚本位置

现场工程内：

```bash
infer_cache/tools/aggregate_video_trace.py
```

默认输出目录：

```text
infer_cache/tools/output/online/
infer_cache/tools/output/test/
```

## 2. 时间过滤口径

```text
video_summary：优先按单视频 started_at 过滤。
video_stage：优先按阶段 started_at 过滤；没有 started_at 时按 created_at。
health_sample：按 created_at 过滤，也就是健康状态采样写入时间。
```

注意：`04_硬件占用汇总.csv` 和 `05_硬件状态跟踪.csv` 依赖新版 `health_sample`。更新后至少运行满一个健康采样周期，默认 5 分钟，才有数据。

## 3. 生产 online 汇总

只输出 CSV，不打包 alarm 资产：

```bash
cd /home/app.e05114/aqtmp/infer_cache

python3 infer_cache/tools/aggregate_video_trace.py \
  --env online \
  --date 2026-06-27 \
  --start 00:00:00 \
  --end 23:59:59 \
  --csv-only \
  --include-detail
```

默认打 ZIP，包含 CSV、README 和 alarm 资产：

```bash
cd /home/app.e05114/aqtmp/infer_cache

python3 infer_cache/tools/aggregate_video_trace.py \
  --env online \
  --date 2026-06-27 \
  --start 00:00:00 \
  --end 23:59:59 \
  --include-detail
```

## 4. 测试 test 汇总

```bash
cd /home/app.e05114/aqtmp/infer_cache

python3 infer_cache/tools/aggregate_video_trace.py \
  --env test \
  --date 2026-06-27 \
  --start 00:00:00 \
  --end 23:59:59 \
  --csv-only \
  --include-detail
```

## 5. 指定完整时间

如果跨日期或需要精确到秒：

```bash
python3 infer_cache/tools/aggregate_video_trace.py \
  --env online \
  --start "2026-06-27 10:00:00" \
  --end "2026-06-27 11:30:00" \
  --csv-only \
  --include-detail
```

## 6. 输出文件说明

默认输出：

```text
00_总览.csv
01_alarm汇总表.csv
02_阶段耗时统计.csv
03_视频明细.csv
04_硬件占用汇总.csv
05_硬件状态跟踪.csv
README_汇总说明.txt
```

加 `--include-detail` 后额外输出：

```text
06_阶段耗时明细.csv
07_alarm资产清单.csv
08_按机台腔室汇总.csv
```

## 7. 建议查看顺序

### 7.1 第一眼看总览

打开：

```text
00_总览.csv
```

重点字段：

```text
video_count
alarm_video_count
failed_video_count
avg_video_total_time
p90_video_total_time
avg_stage1_model_runtime_ms_per_frame
avg_stage2_model_runtime_ms_per_frame
stage1_model_runtime_bottleneck_video_count
stage2_model_runtime_bottleneck_video_count
total_stage1_sparse_saved_count
stage1_sparse_fallback_full_count
```

### 7.2 看硬件汇总

打开：

```text
04_硬件占用汇总.csv
```

重点字段：

```text
health_sample_count
instance_count
max_container_memory_usage
avg_container_cpu_percent_of_one_core
max_container_cpu_percent_of_one_core
max_container_pids
avg_gpu_cuda_util_percent
max_gpu_cuda_util_percent
avg_gpu_memory_util_percent
max_gpu_memory_used_mib
max_gpu_temperature_c
```

判断方式：

```text
health_sample_count=0：选择时间段内没有新版健康采样。
max_container_pids 很高且持续升高：重点排查线程/PIDS。
GPU CUDA 高且模型调用均值高：GPU 竞争明显。
GPU CUDA 低但耗时高：优先看 CPU、NAS、runtime等待。
```

### 7.3 看硬件时间线

打开：

```text
05_硬件状态跟踪.csv
```

建议按以下字段筛选/排序：

```text
created_at
instance_id
pending_requests_today
pending_videos_today
container_memory_usage_text
container_cpu_percent_of_one_core
container_pids
gpu_index
gpu_cuda_util_percent
gpu_memory_used_text
```

### 7.4 看阶段耗时

打开：

```text
02_阶段耗时统计.csv
```

重点看：

```text
stage1_stream_infer
stage2_stream_infer
avg_runtime_avg_ms_per_frame
avg_runtime_acquire_wait_avg_ms_per_frame
avg_wait_avg_ms_per_frame
avg_source_video_read_decode_ms
top_bottleneck_guess
```

## 8. 常见问题

### 8.1 04/05 文件为空

原因：

```text
1. 使用的是更新前日志，没有 health_sample。
2. 选择时间段太短，没有覆盖健康采样点。
3. INFER_CACHE_VIDEO_TRACE_ENABLED=false。
```

处理：

```bash
docker compose -f docker-compose-prod.yml logs --since 15m | grep "专项日志-健康状态"
```

如果专项健康日志存在，但 CSV 为空，扩大汇总时间范围重跑。

### 8.2 中文文件名显示乱码

CSV 默认 `utf-8-sig`，Excel 通常可直接打开。  
Linux 终端显示乱码通常是终端编码问题，不影响文件内容。

### 8.3 默认 ZIP 太大

只要 CSV：

```bash
python3 infer_cache/tools/aggregate_video_trace.py \
  --env online \
  --start "2026-06-27 10:00:00" \
  --end "2026-06-27 11:00:00" \
  --csv-only
```
