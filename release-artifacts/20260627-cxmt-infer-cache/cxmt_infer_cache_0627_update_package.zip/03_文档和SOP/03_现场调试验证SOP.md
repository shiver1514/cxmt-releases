# 0627 现场调试验证 SOP

修改人：Shiver  
修改时间：2026-06-27

## 1. 调试目标

本 SOP 用于确认三件事：

1. 1# 稀疏补推是否生效。
2. 专项日志是否能同时看到剩余请求数和剩余视频数。
3. 硬件状态是否能被专项日志和离线 CSV 记录。

## 2. 查看专项日志

### 2.1 请求是否进入服务

```bash
docker compose -f docker-compose-prod.yml logs --since 10m | grep "专项日志-请求情况"
```

预期看到：

```text
收到请求
视频数量=...
接收结果=已入队
```

### 2.2 汇总情况是否区分请求和视频

```bash
docker compose -f docker-compose-prod.yml logs --since 10m | grep "专项日志-任务情况-汇总情况"
```

重点字段：

```text
请求总数
已完成请求数
运行中请求数
排队请求数
剩余请求数
视频总数
已完成视频数
剩余视频数
请求完成比例
视频完成比例
按请求预计完成时间
按视频预计完成时间
```

判断方式：

```text
如果客户一次请求多个视频：
  剩余请求数可能长期为 1，但剩余视频数应该随着单视频完成持续下降。

如果客户一次请求一个视频、连续发很多请求：
  剩余请求数和剩余视频数通常接近。
```

### 2.3 单视频任务详情

```bash
docker compose -f docker-compose-prod.yml logs --since 10m | grep "专项日志-任务情况-任务详情"
```

重点字段：

```text
结果
视频时长
源帧数
1#推理帧数
2#推理帧数
总耗时
1#单帧耗时
2#单帧耗时
1#稀疏补推
2#稀疏补推
```

1# 稀疏生效时，预期看到：

```text
1#稀疏补推=已启用
稀疏步长=3
初始扫描帧数=...
补推帧数=...
最终1#帧数=...
节省1#帧数=...
是否回退全量=否
```

如果大量出现：

```text
是否回退全量=是
```

说明该批视频触发补推过多，节省效果会下降，需要看 seed/补推半径或先关闭 1# 稀疏。

### 2.4 瓶颈拆分日志

```bash
docker compose -f docker-compose-prod.yml logs --since 10m | grep "专项日志-任务情况-瓶颈拆分"
```

重点看：

```text
1#阶段均值
1#模型调用均值
1#runtime池等待均值
1#视频读取解码均值
1#疑似卡点
2#阶段均值
2#模型调用均值
2#runtime池等待均值
2#视频读取解码均值
2#疑似卡点
```

判断方式：

```text
模型调用均值高：优先看 GPU CUDA 利用率和实例并发。
runtime池等待高：单实例内 runtime 不够或并发抢占明显。
视频读取解码均值高：优先看 NAS/挂载/解码。
Future等待高：综合等待，需要结合模型调用和 runtime 等待判断。
```

### 2.5 健康状态

```bash
docker compose -f docker-compose-prod.yml logs --since 15m | grep "专项日志-健康状态"
```

重点字段：

```text
内存
进程线程数
Python线程数
CPU占用
GPUx：CUDA利用率
显存
运行中请求数
排队请求数
剩余请求数
已接收视频数
已完成视频数
剩余视频数
```

判断方式：

```text
PIDS 持续上涨不回落：重点排查线程/子进程泄漏。
内存持续上涨不回落：重点排查缓存或对象生命周期。
GPU CUDA 长期低但任务慢：可能不是 GPU 瓶颈，优先看 CPU/NAS/runtime等待。
GPU CUDA 长期接近满且模型调用均值变高：GPU 竞争可能成为瓶颈。
```

## 3. 容器内确认环境变量

随机进一个实例：

```bash
docker exec -it infer-cache-ic1 bash
```

容器内执行：

```bash
env | grep "INFER_CACHE_STAGE1_SPARSE"
env | grep "INFER_CACHE_STAGE2_SPARSE_INDEX_MODE"
env | grep "INFER_CACHE_SPECIAL_LOG_INTERVAL_SEC"
exit
```

## 4. 快速判断是否可继续扩大流量

满足以下条件，再扩大压测：

```text
1. 没有 traceback/exception。
2. alarm 数和对照组无明显异常差异。
3. 剩余视频数会持续下降。
4. PIDS 不持续异常上涨。
5. 内存没有持续不可回收上涨。
6. GPU CUDA 和模型调用均值变化符合预期。
7. 04/05 硬件 CSV 能看到采样记录。
```

## 5. 建议现场记录

每轮测试记录：

```text
测试开始时间：
测试结束时间：
实例数量：
是否开启1#稀疏：
1#稀疏步长：
2#稀疏索引模式：
总视频数：
alarm视频数：
平均单视频耗时：
P90单视频耗时：
1#总推理帧数：
1#节省帧数：
2#总推理帧数：
GPU CUDA平均/最大：
容器内存最大：
PIDS最大：
是否发现异常：
```
